
export interface User {
  id: string;
  name: string;
  role: 'bike_carrier' | '4x4_carrier' | 'shopkeeper' | 'shop_owner';
  status: 'Active' | 'Pending' | 'Accepted' | 'Rejected' | 'Expired';
  phone: string;
  vehicleType: string;
  vehicleNumber: string;
  licenseFileName?: string;
  rcFileName?: string;
  livePhoto?: string;
  approvalTimestamp?: number;
  assignedHub?: string;
  rejectionReason?: string;
  bankDetails?: BankDetails;
  availableBalance?: number;
}

export interface BankDetails {
    accountNumber: string;
    ifsc: string;
    branch: string;
    bank: string;
}

export interface Order {
  id: string;
  customer: { name: string; address: string; };
  items: string;
  assignedShopName: string;
  payout: number;
  status: 'packing' | 'ready' | 'accepted_by_carrier' | 'picked_up' | 'delivered';
  carrierId?: string;
}

export interface Job {
  id: string;
  date: string;
  orderId: string;
  payout: number;
  status: 'Completed' | 'Cancelled';
  carrierId: string;
}

export interface RegistrationData {
    phone?: string;
    phoneVerified?: boolean;
    fullName?: string;
    vehicleType?: string;
    vehicleNumber?: string;
    licenseFileName?: string;
    licenseFileDataUrl?: string;
    rcFileName?: string;
    rcFileDataUrl?: string;
    experience?: string;
    emergencyContact?: string;
    livePhoto?: string;
}