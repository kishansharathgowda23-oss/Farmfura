
import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useToast } from '../../contexts/ToastContext';
import * as api from '../../services/mockApi';

interface RegisterPhoneViewProps {
  onPhoneSubmitted: (phone: string) => void;
  onCancel: () => void;
}

const RegisterPhoneView: React.FC<RegisterPhoneViewProps> = ({ onPhoneSubmitted, onCancel }) => {
  const [phone, setPhone] = useState('');
  const { t } = useLanguage();
  const { showToast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{10}$/.test(phone)) {
      showToast('Invalid phone number.');
      return;
    }
    const userExists = api.findEmployeeByPhone(phone);
    if (userExists) {
      showToast('This phone number is already registered. Please login.');
      return;
    }
    showToast('OTP Sent! (It\'s 1234)');
    onPhoneSubmitted(phone);
  };

  return (
    <div className="bg-white p-8 shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{t('register_step_1')}</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="reg-phone" className="block text-sm font-medium text-gray-700">{t('phone_placeholder')}</label>
          <input
            type="tel"
            id="reg-phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full p-3 border rounded-md mt-1"
            placeholder={t('phone_placeholder')}
            required
          />
        </div>
        <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{t('send_otp')}</button>
        <button type="button" onClick={onCancel} className="w-full bg-gray-200 text-gray-800 font-bold py-3 rounded-md hover:bg-gray-300 mt-2">{t('cancel')}</button>
      </form>
    </div>
  );
};

export default RegisterPhoneView;
