
import React, { useState, useContext, useEffect, useRef } from 'react';
import { AuthContext, LanguageContext, ToastContext } from '../App';
import { api } from '../services/api';
import { RegistrationData, User } from '../types';
import { useCamera } from '../hooks/useCamera';

type AuthView = 'login' | 'register';
type LoginStep = 'phone' | 'otp' | 'status' | 'onboarding' | 'qrScanner';
type RegisterStep = 'phone' | 'otp' | 'details';

const Auth: React.FC = () => {
    const { login } = useContext(AuthContext);
    const { language, setLanguage, translate } = useContext(LanguageContext);
    const showToast = useContext(ToastContext);

    const [authView, setAuthView] = useState<AuthView>('login');
    const [loginStep, setLoginStep] = useState<LoginStep>('phone');
    const [registerStep, setRegisterStep] = useState<RegisterStep>('phone');

    const [phone, setPhone] = useState('');
    const [otp, setOtp] = useState('');
    const [tempUser, setTempUser] = useState<User | null>(null);
    const [statusInfo, setStatusInfo] = useState({ message: '', type: '' });
    
    const [regData, setRegData] = useState<RegistrationData>({});
    const { videoRef, canvasRef, status: cameraStatus, startCamera, stopCamera, captureFrame } = useCamera();
    const [livePhotoPreview, setLivePhotoPreview] = useState<string | null>(null);

    // Load registration progress on mount
    useEffect(() => {
        const savedProgress = api.loadRegProgress();
        if (savedProgress) {
            setRegData(savedProgress);
            showToast(translate('progress_restored'));
            if (savedProgress.fullName) setRegisterStep('details');
            else if (savedProgress.phoneVerified) setRegisterStep('details');
            else if (savedProgress.phone) setRegisterStep('otp');
            else setRegisterStep('phone');
        }
    }, [showToast, translate]);

    const handleLoginPhoneSubmit = () => {
        if (!/^\d{10}$/.test(phone)) return showToast(translate('phone_placeholder'), true);
        
        let user = api.getEmployeeByPhone(phone);
        if (!user) return showToast('No carrier account found.', true);
        
        // Check for expired onboarding
        if (user.status === 'Accepted' && user.approvalTimestamp && (Date.now() - user.approvalTimestamp > 48 * 60 * 60 * 1000)) {
            user.status = 'Expired';
            api.updateEmployee(user);
        }
        
        setTempUser(user);
        
        switch (user.status) {
            case 'Active':
                showToast('OTP Sent! (Demo: 1234)');
                setLoginStep('otp');
                break;
            case 'Accepted':
                setLoginStep('onboarding');
                break;
            case 'Pending':
            case 'Rejected':
            case 'Expired':
                setStatusInfo({
                    message: translate(`application_${user.status.toLowerCase()}` as any, { reason: user.rejectionReason || translate('not_specified') }),
                    type: user.status
                });
                setLoginStep('status');
                break;
        }
    };

    const handleLoginOtpSubmit = () => {
        if (otp !== '1234') return showToast('Invalid OTP.', true);
        if (tempUser) login(tempUser);
    };

    const handleRegisterPhoneSubmit = () => {
        if (!/^\d{10}$/.test(phone)) return showToast(translate('phone_placeholder'), true);
        const existingUser = api.getEmployeeByPhone(phone);
        if (existingUser && existingUser.status !== 'Rejected' && existingUser.status !== 'Expired') {
            return showToast('Phone number already registered.', true);
        }
        const newRegData = { phone };
        setRegData(newRegData);
        api.saveRegProgress(newRegData);
        showToast('OTP Sent! (Demo: 123456)');
        setRegisterStep('otp');
    };

    const handleRegisterOtpSubmit = () => {
        if (otp !== '123456') return showToast('Invalid OTP.', true);
        const newRegData = { ...regData, phoneVerified: true };
        setRegData(newRegData);
        api.saveRegProgress(newRegData);
        setRegisterStep('details');
        startCamera('user');
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'license' | 'rc') => {
        const file = e.target.files?.[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            const dataUrl = event.target?.result as string;
            if(field === 'license') {
                setRegData(prev => ({ ...prev, licenseFileName: file.name, licenseFileDataUrl: dataUrl }));
            } else {
                setRegData(prev => ({ ...prev, rcFileName: file.name, rcFileDataUrl: dataUrl }));
            }
        };
        reader.readAsDataURL(file);
    };

    const handleCapturePhoto = () => {
        if (livePhotoPreview) {
            setLivePhotoPreview(null);
            startCamera('user');
        } else {
            const dataUrl = captureFrame();
            if (dataUrl) {
                setLivePhotoPreview(dataUrl);
                setRegData(prev => ({...prev, livePhoto: dataUrl}));
                stopCamera();
            }
        }
    };
    
    const handleRegistrationSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const formData = new FormData(e.target as HTMLFormElement);
        const finalData: RegistrationData = {
            ...regData,
            fullName: formData.get('fullName') as string,
            vehicleType: formData.get('vehicleType') as string,
            vehicleNumber: formData.get('vehicleNumber') as string,
            experience: formData.get('experience') as string,
            emergencyContact: formData.get('emergencyContact') as string,
        };

        if (!finalData.fullName || !finalData.vehicleType || !finalData.vehicleNumber || !finalData.licenseFileDataUrl || !finalData.rcFileDataUrl || !finalData.livePhoto) {
            return showToast('Please fill all required fields.', true);
        }
        
        api.createEmployee(finalData);
        showToast('Registration complete! Application under review.');
        api.clearRegProgress();
        setAuthView('login');
        setLoginStep('phone');
        setPhone('');
        setOtp('');
    };

    const { videoRef: qrVideoRef, startCamera: startQrCamera, stopCamera: stopQrCamera } = useCamera();

    const openQrScanner = () => {
        setLoginStep('qrScanner');
        startQrCamera('environment');
    };

    const closeQrScanner = () => {
        stopQrCamera();
        setLoginStep('onboarding');
    };

    const simulateQrScan = () => {
        if(tempUser?.status === 'Accepted') {
            const updatedUser = { ...tempUser, status: 'Active' as 'Active' };
            api.updateEmployee(updatedUser);
            stopQrCamera();
            showToast(translate('qr_success'));
            setTimeout(() => login(updatedUser), 1500);
        }
    };

    const Header = () => (
        <header className="bg-white shadow-sm">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center py-4">
                    <div className="text-3xl font-bold text-green-700 italic">🌱 Farmfura</div>
                    <div className="flex items-center space-x-4">
                        <select
                            id="login-language-switcher"
                            className="block appearance-none bg-white border border-gray-300 hover:border-gray-500 px-4 py-2 pr-8 rounded-md shadow-sm text-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                            value={language}
                            onChange={(e) => setLanguage(e.target.value)}
                        >
                            <option value="en">English</option>
                            <option value="kn">ಕನ್ನಡ</option>
                            <option value="hi">हिन्दी</option>
                        </select>
                        <a href="#" className="font-semibold text-gray-600 hover:text-green-700">{translate('back_to_portal')}</a>
                    </div>
                </div>
            </div>
        </header>
    );

    const renderLogin = () => {
        switch (loginStep) {
            case 'phone':
                return (
                    <div>
                        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{translate('carrier_login')}</h2>
                        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handleLoginPhoneSubmit(); }}>
                            <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full p-3 border rounded-md" placeholder={translate('phone_placeholder')} required />
                            <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{translate('send_otp_btn')}</button>
                        </form>
                    </div>
                );
            case 'otp':
                return (
                     <div>
                         <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">{translate('verify_phone_title')}</h2>
                         <p className="text-center text-sm text-gray-600 mb-4">
                            {translate('otp_sent_to')} <span className="font-bold">{phone}</span>.
                        </p>
                        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handleLoginOtpSubmit(); }}>
                            <input type="text" value={otp} onChange={(e) => setOtp(e.target.value)} className="w-full p-3 border rounded-md text-center tracking-widest" placeholder={translate('otp_placeholder')} />
                            <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{translate('verify_login')}</button>
                        </form>
                         <div className="text-center mt-4">
                            <button onClick={() => { setLoginStep('phone'); setOtp(''); }} className="text-sm text-blue-600 hover:underline">{translate('change_number')}</button>
                        </div>
                    </div>
                );
            case 'status':
                return (
                    <div className={`text-center p-4 rounded-md ${
                        statusInfo.type === 'Pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                    }`}>
                        <p>{statusInfo.message}</p>
                        {(statusInfo.type === 'Rejected' || statusInfo.type === 'Expired') && (
                            <button onClick={() => { setAuthView('register'); setRegisterStep('phone'); }} className="mt-4 w-full bg-blue-600 text-white font-bold py-2 rounded-md hover:bg-blue-700">{translate('register_again')}</button>
                        )}
                    </div>
                );
            case 'onboarding':
                return (
                    <div className="text-center">
                         <h3 className="text-xl font-bold text-gray-800 mb-4">{translate('onboarding_title')}</h3>
                         <div className="bg-green-50 border-l-4 border-green-500 text-green-800 p-4 rounded-r-lg">
                             <p className="mb-2">{translate('visit_hub_message')}</p>
                             <div className="font-semibold">
                                 <p className="text-sm">{tempUser?.assignedHub}</p>
                             </div>
                         </div>
                         <div className="mt-6">
                             <p className="mt-2 text-gray-600 mb-4">{translate('scan_qr_prompt')}</p>
                             <button onClick={openQrScanner} type="button" className="w-full bg-blue-600 text-white font-bold py-3 rounded-md hover:bg-blue-700 flex items-center justify-center space-x-2">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v1m6 11h-1m-1-6v1m-1-1h1m-1 6h1m-1-1v1M4 12h1m11 6v-1m-1 1h-1m6-1v-1m-1 1h-1M9 4v1M4 9h1M4 4l1 1m14 14l-1-1M4 15l1-1m14-1l-1 1M9 20v-1m6 1v-1m-1-16l-1 1M8 4l-1 1" /></svg>
                                 <span>{translate('scan_qr_btn')}</span>
                             </button>
                         </div>
                    </div>
                );
            case 'qrScanner':
                return (
                    <div>
                         <h3 className="text-xl font-bold text-center text-gray-800 mb-4">{translate('scan_qr_title')}</h3>
                         <div className="relative w-full aspect-square bg-gray-800 rounded-lg overflow-hidden flex items-center justify-center cursor-pointer" onClick={simulateQrScan}>
                             <video ref={qrVideoRef} className="w-full h-full object-cover" autoPlay playsInline></video>
                            <div className="absolute inset-0 flex items-center justify-center text-white opacity-50 text-sm">{translate('click_to_scan')}</div>
                         </div>
                         <button onClick={closeQrScanner} type="button" className="w-full mt-4 bg-gray-500 text-white font-bold py-3 rounded-md hover:bg-gray-600">{translate('cancel_scan')}</button>
                    </div>
                );
        }
    };
    
    const renderRegister = () => {
        const handleBack = () => {
            if (registerStep === 'otp') setRegisterStep('phone');
            if (registerStep === 'details') {
                stopCamera();
                setRegisterStep('otp');
            }
        };

        return (
            <div>
                 <div className="relative">
                    {registerStep !== 'phone' && (
                        <button onClick={handleBack} className="absolute top-0 left-0 text-gray-500 hover:text-gray-800">&larr; {translate('back_btn')}</button>
                    )}
                     <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{translate('carrier_registration')}</h2>
                </div>
                {registerStep === 'phone' && (
                    <div className="pt-6">
                        <p className="text-center text-sm text-gray-600 mb-4">{translate('reg_step1_prompt')}</p>
                        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handleRegisterPhoneSubmit(); }}>
                            <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full p-3 border rounded-md" placeholder={translate('phone_placeholder')} required />
                            <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{translate('send_otp_btn')}</button>
                        </form>
                    </div>
                )}
                {registerStep === 'otp' && (
                     <div className="pt-6">
                        <p className="text-center text-sm text-gray-600 mb-4">
                           {translate('otp_sent_to')} <span className="font-bold">{phone}</span>.
                        </p>
                        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handleRegisterOtpSubmit(); }}>
                            <input type="text" value={otp} onChange={(e) => setOtp(e.target.value)} className="w-full p-3 border rounded-md text-center tracking-[0.5em]" placeholder={translate('otp_placeholder_6')} required />
                            <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{translate('verify_otp_btn')}</button>
                        </form>
                    </div>
                )}
                {registerStep === 'details' && (
                     <div className="pt-6">
                        <form className="space-y-4" onSubmit={handleRegistrationSubmit}>
                            <input type="text" name="fullName" className="w-full p-3 border rounded-md" placeholder={translate('name_as_per_license')} required />
                            <input type="tel" value={regData.phone} className="w-full p-3 border bg-gray-100 rounded-md" readOnly />
                            <input type="text" name="vehicleType" className="w-full p-3 border rounded-md" placeholder={translate('vehicle_type')} required />
                            <input type="text" name="vehicleNumber" className="w-full p-3 border rounded-md" placeholder={translate('vehicle_number')} required />
                            <div>
                                <label className="text-sm font-medium text-gray-700">{translate('upload_license')}</label>
                                <div className="flex items-center space-x-2">
                                    <input type="file" onChange={e => handleFileChange(e, 'license')} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100" accept="image/*,.pdf" />
                                    <div className="file-preview rounded-md flex items-center justify-center text-xs text-gray-500" style={{backgroundImage: regData.licenseFileDataUrl ? `url(${regData.licenseFileDataUrl})` : 'none'}}>{regData.licenseFileDataUrl ? '' : 'Preview'}</div>
                                </div>
                            </div>
                            <div>
                                <label className="text-sm font-medium text-gray-700">{translate('upload_rc')}</label>
                                <div className="flex items-center space-x-2">
                                    <input type="file" onChange={e => handleFileChange(e, 'rc')} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100" accept="image/*,.pdf" />
                                    <div className="file-preview rounded-md flex items-center justify-center text-xs text-gray-500" style={{backgroundImage: regData.rcFileDataUrl ? `url(${regData.rcFileDataUrl})` : 'none'}}>{regData.rcFileDataUrl ? '' : 'Preview'}</div>
                                </div>
                            </div>
                            <div>
                                <label className="text-sm font-medium text-gray-700">{translate('prev_experience')}</label>
                                <textarea name="experience" className="w-full p-2 border rounded-md" rows={3} placeholder={translate('experience_placeholder_delivery')}></textarea>
                            </div>
                             <div>
                                <label className="text-sm font-medium text-gray-700">{translate('emergency_contact')}</label>
                                <input type="tel" name="emergencyContact" className="w-full p-3 border rounded-md" placeholder={translate('phone_placeholder')} />
                            </div>
                             <div>
                                <label className="text-sm font-medium text-gray-700">{translate('live_photo')}</label>
                                <div className="mt-1 bg-gray-200 rounded-md flex items-center justify-center h-48 relative">
                                    <video ref={videoRef} className={`w-full h-full rounded-md object-cover ${!livePhotoPreview && cameraStatus === 'running' ? '' : 'hidden'}`} autoPlay playsInline></video>
                                    <canvas ref={canvasRef} className="hidden"></canvas>
                                    {livePhotoPreview && <img src={livePhotoPreview} className="w-full h-full rounded-md object-cover" alt="Live" />}
                                    {cameraStatus === 'permission' && (
                                        <div className="text-gray-500 text-center p-4">
                                            <p>{translate('allow_camera_access')}</p>
                                            <button type="button" onClick={() => startCamera('user')} className="mt-2 bg-yellow-500 text-white text-sm font-bold py-2 px-3 rounded-md hover:bg-yellow-600">{translate('retry_camera')}</button>
                                        </div>
                                    )}
                                </div>
                                <button type="button" onClick={handleCapturePhoto} className="w-full mt-2 bg-blue-500 text-white text-sm font-bold py-2 px-3 rounded-md hover:bg-blue-600">{translate(livePhotoPreview ? 'retake_photo_btn' : 'capture_photo_btn')}</button>
                            </div>
                            <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{translate('register_btn')}</button>
                        </form>
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            <Header />
            <main className="flex-grow flex items-center justify-center p-4">
                <div className="w-full max-w-sm">
                    {authView === 'login' ? (
                        <div className="bg-white p-8 shadow-lg rounded-lg">
                            {renderLogin()}
                            <p className="text-center text-sm text-gray-600 mt-4">
                                {translate('no_account')}{' '}
                                <button onClick={() => { setAuthView('register'); setRegisterStep('phone'); }} className="font-semibold text-green-600 hover:text-green-800">{translate('register_link')}</button>
                            </p>
                        </div>
                    ) : (
                        <div className="bg-white p-8 shadow-lg rounded-lg">
                            {renderRegister()}
                            <p className="text-center text-sm text-gray-600 mt-4">
                                {translate('has_account')}{' '}
                                <button onClick={() => { setAuthView('login'); setLoginStep('phone'); stopCamera(); }} className="font-semibold text-green-600 hover:text-green-800">{translate('login_link')}</button>
                            </p>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default Auth;
