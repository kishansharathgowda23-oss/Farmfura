
import React from 'react';
import { User, Address } from '../types';

interface MePageProps {
    user: User;
    addresses: Address[];
    translations: Record<string, string>;
}

const MePage: React.FC<MePageProps> = ({ user, addresses, translations }) => {
    return (
        <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-md">
            <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">{translations.me_page_title}</h1>
            <div className="space-y-4">
                <div className="flex items-center p-4 border rounded-lg mb-4">
                    <span className="text-xl mr-4">👤</span>
                    <div>
                        <p className="text-sm text-gray-500">{translations.me_name_label}</p>
                        <p className="font-semibold">{user.name}</p>
                    </div>
                </div>
                <div className="flex items-center p-4 border rounded-lg mb-6">
                     <span className="text-xl mr-4">📞</span>
                    <div>
                        <p className="text-sm text-gray-500">{translations.me_phone_label}</p>
                        <p className="font-semibold">{user.loginCredential}</p>
                    </div>
                </div>
                
                <h2 className="text-xl font-semibold text-gray-800 mb-4">{translations.me_saved_addresses_title}</h2>
                <div className="space-y-3">
                    {addresses.length > 0 ? (
                        addresses.map(addr => (
                            <div key={addr.id} className="p-4 border rounded-lg bg-gray-50">
                                <p className="font-semibold">{addr.name}</p>
                                <p className="text-sm text-gray-600">{addr.address}</p>
                                <p className="text-sm text-gray-600">{addr.city}, {addr.pin}</p>
                            </div>
                        ))
                    ) : (
                        <p className="text-gray-500 text-center">{translations.me_no_saved_addresses}</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default MePage;
