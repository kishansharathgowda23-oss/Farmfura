import React, { useState, useEffect } from 'react';
import { CartItem, Address, Order } from '../types';

interface CheckoutPageProps {
    cart: CartItem[];
    addresses: Address[];
    onPlaceOrder: (order: Omit<Order, 'id' | 'timestamp' | 'status'>) => void;
    openAddressModal: () => void;
    translations: Record<string, string>;
    showToast: (message: string, isError?: boolean) => void;
    isSubscriptionCheckout: boolean;
    subscriptionSelection: CartItem[];
}

const CheckoutPage: React.FC<CheckoutPageProps> = ({ cart, addresses, onPlaceOrder, openAddressModal, translations, showToast, isSubscriptionCheckout, subscriptionSelection }) => {
    const [selectedAddress, setSelectedAddress] = useState<string>(addresses[0]?.id.toString() || '');
    const [paymentMethod, setPaymentMethod] = useState(isSubscriptionCheckout ? 'card' : 'cod');
    const [deliveryDay, setDeliveryDay] = useState('sunday');

    useEffect(() => {
        if (!selectedAddress && addresses.length > 0) {
            setSelectedAddress(addresses[0].id.toString());
        }
    }, [addresses, selectedAddress]);

    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const deliveryFee = isSubscriptionCheckout ? 0 : 15; // Free delivery for subscriptions
    const total = subtotal + deliveryFee;

    const handlePlaceOrderClick = () => {
        if (!selectedAddress) {
            showToast(translations.checkout_no_address_toast, true);
            return;
        }
        onPlaceOrder({
            items: isSubscriptionCheckout ? subscriptionSelection : cart,
            total: total,
            deliveryDay: isSubscriptionCheckout ? deliveryDay : undefined
        });
    };

    const weekDays = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    
    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-6">{translations.checkout_title}</h1>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
                    <form className="space-y-6">
                        <div>
                            <div className="flex justify-between items-center mb-4">
                                <h2 className="text-xl font-semibold">{translations.shipping_address}</h2>
                                <button type="button" onClick={openAddressModal} className="text-sm text-green-600 hover:underline">{translations.checkout_add_address_btn}</button>
                            </div>
                            <select 
                                value={selectedAddress} 
                                onChange={(e) => setSelectedAddress(e.target.value)} 
                                className="w-full p-3 border rounded-md" 
                                required
                                disabled={addresses.length === 0}
                            >
                                {addresses.length === 0 ? (
                                    <option value="">{translations.checkout_no_address}</option>
                                ) : (
                                    addresses.map(addr => (
                                        <option key={addr.id} value={addr.id}>
                                            {`${addr.name} - ${addr.address}, ${addr.city}`}
                                        </option>
                                    ))
                                )}
                            </select>
                        </div>

                        {isSubscriptionCheckout ? (
                             <div>
                                <h2 className="text-xl font-semibold pt-4 mb-4">{translations.select_delivery_day}</h2>
                                <div className="flex flex-wrap gap-4">
                                    {weekDays.map(day => (
                                        <label key={day} className="flex items-center p-3 border rounded-md cursor-pointer has-[:checked]:bg-green-100 has-[:checked]:border-green-500">
                                            <input type="radio" name="delivery-day" value={day} checked={deliveryDay === day} onChange={(e) => setDeliveryDay(e.target.value)} className="mr-2" /> 
                                            {translations[`day_${day}`]}
                                        </label>
                                    ))}
                                </div>
                            </div>
                        ) : (
                            <div>
                                <h2 className="text-xl font-semibold pt-4 mb-4">{translations.delivery_slot}</h2>
                                <div className="flex flex-wrap gap-4">
                                    <label className="flex items-center p-3 border rounded-md cursor-pointer has-[:checked]:bg-green-100 has-[:checked]:border-green-500">
                                        <input type="radio" name="delivery-slot" value="15min" className="mr-2" /> {translations.slot_15min}
                                    </label>
                                    <label className="flex items-center p-3 border rounded-md cursor-pointer has-[:checked]:bg-green-100 has-[:checked]:border-green-500">
                                        <input type="radio" name="delivery-slot" value="morning" className="mr-2" defaultChecked /> {translations.slot_morning}
                                    </label>
                                    <label className="flex items-center p-3 border rounded-md cursor-pointer has-[:checked]:bg-green-100 has-[:checked]:border-green-500">
                                        <input type="radio" name="delivery-slot" value="afternoon" className="mr-2" /> {translations.slot_afternoon}
                                    </label>
                                    <label className="flex items-center p-3 border rounded-md cursor-pointer has-[:checked]:bg-green-100 has-[:checked]:border-green-500">
                                        <input type="radio" name="delivery-slot" value="evening" className="mr-2" /> {translations.slot_evening}
                                    </label>
                                </div>
                            </div>
                        )}

                        <div>
                            <h2 className="text-xl font-semibold pt-4 mb-4">{translations.payment_method}</h2>
                            <div className="space-y-3">
                                {!isSubscriptionCheckout && (
                                    <label className="flex items-center p-3 border rounded-md cursor-pointer has-[:checked]:bg-green-100 has-[:checked]:border-green-500">
                                        <input type="radio" name="payment-method" value="cod" className="mr-2" checked={paymentMethod === 'cod'} onChange={e => setPaymentMethod(e.target.value)} /> {translations.payment_cod}
                                    </label>
                                )}
                                <label className="flex items-center p-3 border rounded-md cursor-pointer has-[:checked]:bg-green-100 has-[:checked]:border-green-500">
                                    <input type="radio" name="payment-method" value="upi" className="mr-2" checked={paymentMethod === 'upi'} onChange={e => setPaymentMethod(e.target.value)} /> {translations.payment_upi}
                                </label>
                                <label className="flex items-center p-3 border rounded-md cursor-pointer has-[:checked]:bg-green-100 has-[:checked]:border-green-500">
                                    <input type="radio" name="payment-method" value="card" className="mr-2" checked={paymentMethod === 'card'} onChange={e => setPaymentMethod(e.target.value)} /> {translations.payment_card}
                                </label>
                            </div>
                            <div className={`mt-4 space-y-2 ${paymentMethod === 'upi' ? 'block' : 'hidden'}`}>
                                <input type="text" placeholder={translations.payment_upi_placeholder} className="w-full p-3 border rounded-md" />
                            </div>
                            <div className={`mt-4 space-y-2 ${paymentMethod === 'card' ? 'block' : 'hidden'}`}>
                                <input type="text" placeholder={translations.payment_card_number_placeholder} className="w-full p-3 border rounded-md" />
                                <div className="grid grid-cols-2 gap-4">
                                    <input type="text" placeholder={translations.payment_card_expiry_placeholder} className="w-full p-3 border rounded-md" />
                                    <input type="text" placeholder={translations.payment_card_cvv_placeholder} className="w-full p-3 border rounded-md" />
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div className="lg:col-span-1 bg-white p-6 rounded-lg shadow-md h-fit">
                    <h2 className="text-xl font-semibold mb-4">{translations.order_summary}</h2>
                    {isSubscriptionCheckout ? (
                         <>
                            <div className="flex justify-between text-sm font-semibold">
                                <span>{cart[0]?.name}</span>
                                <span>₹{subtotal.toFixed(2)}</span>
                            </div>
                            <div className="mt-2 pt-2 border-t">
                                <h3 className="text-sm font-semibold mb-1">{translations.your_custom_selections}:</h3>
                                <div className="space-y-1 text-xs text-gray-600">
                                     {subscriptionSelection.map(item => (
                                        <div key={item.id} className="flex justify-between">
                                            <span>{item.names[translations.lang_code as keyof typeof item.names] || item.name}</span>
                                            <span>x{item.quantity} {item.unit === 'kg' ? 'kg' : ''}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                         </>
                    ) : (
                        <div className="space-y-2 mb-4">
                            {cart.map(item => (
                                <div key={item.id} className="flex justify-between text-sm">
                                    <span>{item.names[translations.lang_code as keyof typeof item.names] || item.name} (x{item.quantity})</span>
                                    <span>₹{(item.price * item.quantity).toFixed(2)}</span>
                                </div>
                            ))}
                        </div>
                    )}
                    <div className="border-t pt-4 space-y-2 mt-4">
                         <div className="flex justify-between font-semibold">
                            <span>{translations.summary_subtotal}</span>
                            <span>₹{subtotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-gray-600">
                            <span>{translations.summary_delivery}</span>
                            <span>{deliveryFee > 0 ? `₹${deliveryFee.toFixed(2)}` : 'FREE'}</span>
                        </div>
                        <div className="flex justify-between text-xl font-bold mt-2">
                            <span>{translations.summary_total}</span>
                            <span>₹{total.toFixed(2)}</span>
                        </div>
                    </div>
                    <button onClick={handlePlaceOrderClick} className="w-full mt-6 bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">
                        {translations.place_order_btn}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CheckoutPage;