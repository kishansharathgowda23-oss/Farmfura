
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import { OnboardingModal } from '../components/Modals';

const AuthPage: React.FC = () => {
    const { t, language, setLanguage } = useAppContext();
    const [page, setPage] = useState<'login' | 'otp'>('login');
    const [phone, setPhone] = useState('');
    const [otp, setOtp] = useState('');
    const { login, currentUser } = useAppContext();
    const [showOnboarding, setShowOnboarding] = useState(false);

    const handleSendOtp = (e: React.FormEvent) => {
        e.preventDefault();
        if (/^\d{10}$/.test(phone)) {
            setPage('otp');
            setTimeout(() => {
                setOtp('1234'); // Mock auto-fill
            }, 1000);
        }
    };
    
    const handleVerifyOtp = (e: React.FormEvent) => {
        e.preventDefault();
        if (otp === '1234') { // Mock OTP check
            login(phone);
        } else {
            alert('Invalid OTP');
        }
    };

    useEffect(() => {
        if (currentUser && !currentUser.hasOnboarded) {
            setShowOnboarding(true);
        }
    }, [currentUser]);

    const LanguageSwitcher = () => (
        <select value={language} onChange={e => setLanguage(e.target.value)} className="block appearance-none bg-white border border-gray-300 px-4 py-2 pr-8 rounded-md shadow-sm text-sm">
            <option value="en">English</option>
            <option value="kn">ಕನ್ನಡ</option>
            <option value="hi">हिन्दी</option>
        </select>
    );

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 relative">
            <div className="absolute top-6 right-6">
                <LanguageSwitcher />
            </div>
            <div className="w-full max-w-sm">
                <div className="text-center mb-8">
                     <div className="text-5xl font-bold text-green-700 italic mb-4">🌱 Farmfura</div>
                    <p className="text-gray-600 italic h-12">{t('login_quote')}</p>
                </div>

                {page === 'login' && (
                    <div className="bg-white p-8 shadow-lg rounded-lg animate-fade-in">
                        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{t('farmer_login_title')}</h2>
                        <form onSubmit={handleSendOtp} className="space-y-4">
                            <div>
                                <label htmlFor="login-credential" className="block text-gray-700 text-sm font-bold mb-2">{t('phone_number_label')}</label>
                                <input type="tel" id="login-credential" value={phone} onChange={e => setPhone(e.target.value)} className="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-gray-700" placeholder={t('phone_placeholder')} required autoComplete="tel" pattern="\d{10}" />
                            </div>
                            <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">{t('send_otp_btn')}</button>
                        </form>
                    </div>
                )}
                
                {page === 'otp' && (
                     <div className="bg-white p-8 shadow-lg rounded-lg animate-fade-in">
                        <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">{t('otp_label')}</h2>
                        <p className="text-center text-gray-600 mb-6">{t('otp_sent_toast', { phone })}</p>
                        <form onSubmit={handleVerifyOtp} className="space-y-4">
                            <div>
                                <input type="text" id="login-otp" value={otp} onChange={e => setOtp(e.target.value)} className="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-gray-700 text-center text-2xl tracking-[1em]" placeholder="----" maxLength={4} required autoComplete="one-time-code" />
                            </div>
                            <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">{t('verify_login_btn')}</button>
                        </form>
                    </div>
                )}
                <OnboardingModal isOpen={showOnboarding} onClose={() => setShowOnboarding(false)} />
            </div>
        </div>
    );
};

export default AuthPage;
