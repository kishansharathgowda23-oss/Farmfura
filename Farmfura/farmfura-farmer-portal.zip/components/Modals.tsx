import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import { Modal, Spinner } from './Common';
import { Product, StagedItemDetails } from '../types';
import { analyzeRecipeWithGemini } from '../services/geminiService';

interface OnboardingModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ isOpen, onClose }) => {
    const { farmerId, updateUserState, t } = useAppContext();
    const [name, setName] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (name.trim() && farmerId) {
            updateUserState(farmerId, { name: name.trim(), hasOnboarded: true });
            onClose();
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={() => {}}>
            <h2 className="text-2xl font-bold mb-4">{t('welcome_title')}</h2>
            <p className="mb-6 text-gray-600">{t('enter_name_prompt')}</p>
            <form onSubmit={handleSubmit}>
                <label htmlFor="farmer-name" className="block text-gray-700 text-sm font-bold mb-2">{t('name_label')}</label>
                <input
                    type="text"
                    id="farmer-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="shadow-sm border rounded-md w-full py-3 px-4 text-gray-700 mb-6"
                    required
                    autoComplete="name"
                />
                <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">
                    {t('complete_registration_btn')}
                </button>
            </form>
        </Modal>
    );
};

interface QuantityModalProps {
    isOpen: boolean;
    onClose: () => void;
    product: Product | null;
}

export const QuantityModal: React.FC<QuantityModalProps> = ({ isOpen, onClose, product }) => {
    const { appMode, t, stagedItems, setStagedItems, showToast, language } = useAppContext();
    const [quantity, setQuantity] = useState<string>('1');
    const [description, setDescription] = useState('');
    const [analysisResult, setAnalysisResult] = useState('');
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    useEffect(() => {
        if (product) {
            const existingItem = stagedItems[product.id];
            if (typeof existingItem === 'number') {
                setQuantity(String(existingItem));
            } else if (typeof existingItem === 'object') {
                setQuantity(String(existingItem.quantity));
                setDescription(existingItem.description || '');
                setAnalysisResult(existingItem.analysisResult || '');
            } else {
                setQuantity('1');
                setDescription('');
                setAnalysisResult('');
            }
        }
    }, [product, stagedItems]);

    if (!product) return null;

    const price = appMode === 'sell' ? (product.sellPrice ?? product.farmerPrice ?? 0) : (product.buyPrice ?? 0);
    const total = (parseFloat(quantity) || 0) * price;

    const handleSubmit = () => {
        const numQuantity = parseFloat(quantity);
        if (isNaN(numQuantity) || numQuantity <= 0) {
            const newItems = { ...stagedItems };
            delete newItems[product.id];
            setStagedItems(newItems);
        } else {
            let newItem: number | StagedItemDetails = numQuantity;
            if (product.type === 'home-products') {
                newItem = {
                    quantity: numQuantity,
                    description: description,
                    fileName: 'mock_file.jpg',
                    verificationStatus: 'Pending',
                    analysisResult: analysisResult,
                };
            }
            setStagedItems(prev => ({ ...prev, [product.id]: newItem }));
        }
        showToast(t('added_to_submission', {quantity: numQuantity, unit: t(`unit_${product.unit}`), productName: product.names[language] || product.name}));
        onClose();
    };
    
    const handleAnalyze = async () => {
        if (!description) {
            showToast('Please describe how the product was made.');
            return;
        }
        setIsAnalyzing(true);
        setAnalysisResult('');
        try {
            const result = await analyzeRecipeWithGemini(description);
            setAnalysisResult(result);
        } catch (error) {
            console.error("Gemini API error:", error);
            setAnalysisResult("Sorry, could not analyze the recipe at this time.");
            showToast("Error analyzing recipe.");
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose}>
            <h2 className="text-2xl font-bold mb-2">{t('enter_quantity')}</h2>
            <p className="mb-4 text-gray-600">{product.names[language] || product.name}</p>
            <div className="flex items-center space-x-4">
                <input type="number" value={quantity} onChange={e => setQuantity(e.target.value)} min="0" className="w-full text-center p-2 border rounded-md text-lg" />
                <span className="font-semibold text-gray-700">{t(`unit_${product.unit}`)}</span>
            </div>
            
            {product.type === 'home-products' && (
                <div className="mt-4 pt-4 border-t">
                    <label className="block text-sm font-medium text-gray-700 mb-1">{t('how_it_was_made')}</label>
                    <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} className="w-full p-2 border rounded-md" placeholder={t('making_placeholder')}></textarea>
                    <button onClick={handleAnalyze} disabled={isAnalyzing} className="mt-2 w-full text-sm bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 disabled:bg-blue-300">
                        {isAnalyzing ? t('analyzing') : t('analyze_recipe')}
                    </button>
                    {isAnalyzing && <div className="flex justify-center mt-2"><Spinner /></div>}
                    {analysisResult && (
                        <div className="mt-4 p-3 bg-gray-100 rounded-md">
                            <h4 className="font-semibold text-sm">{t('analysis_result')}</h4>
                            <p className="text-sm text-gray-700 whitespace-pre-wrap">{analysisResult}</p>
                        </div>
                    )}
                </div>
            )}

            <p className="text-center font-bold text-xl mt-4">{t('total_amount')}: <span>₹{total.toFixed(2)}</span></p>
            <div className="grid grid-cols-2 gap-4 mt-6">
                <button onClick={onClose} className="w-full bg-gray-200 py-3 rounded-md hover:bg-gray-300">{t('cancel')}</button>
                <button onClick={handleSubmit} className={`w-full text-white py-3 rounded-md transition ${appMode === 'sell' ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'}`}>{t('add_to_submission_btn')}</button>
            </div>
        </Modal>
    );
};

export const LocationPermissionModal: React.FC<{isOpen: boolean, onClose: () => void}> = ({ isOpen, onClose }) => {
    const { t, permissionStatus, fetchCoordinates } = useAppContext();

    const handleAllow = () => {
        fetchCoordinates();
        onClose();
    };

    const isDenied = permissionStatus === 'denied';

    return (
        <Modal isOpen={isOpen} onClose={onClose}>
            <h2 className="text-2xl font-bold mb-4">{t('location_permission_title')}</h2>
            <p className="mb-6 text-gray-600">
                {isDenied ? t('location_permission_denied_desc') : t('location_permission_prompt_desc')}
            </p>
            <div className="flex justify-end space-x-4">
                <button onClick={onClose} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-md hover:bg-gray-300">
                    {t('close')}
                </button>
                {!isDenied && (
                    <button onClick={handleAllow} className="bg-green-600 text-white font-bold py-2 px-4 rounded-md hover:bg-green-700">
                        {t('location_allow_access')}
                    </button>
                )}
            </div>
        </Modal>
    );
};