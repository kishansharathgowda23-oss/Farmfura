import React, { useState, useEffect, useRef } from 'react';
import { useTheme } from '../App';
import { LanguageProvider, useLanguage } from './LanguageContext';
import { getBookedSlots, saveBookedSlots, getEmployees, saveEmployees, getWithdrawals, saveWithdrawals } from '../services/storageService';
import { Modal } from './Modal';
import type { User, TabName, TimeSlot, BankDetails, Withdrawal, TimeSlotTemplate } from '../types';

interface MainAppProps {
    user: User;
    onLogout: () => void;
    showToast: (message: string, isError?: boolean) => void;
}

type ScanAction = {
    type: 'clock-in',
    slotId: string,
} | null;


export const MainApp: React.FC<MainAppProps> = (props) => (
    <LanguageProvider>
        <MainAppContent {...props} />
    </LanguageProvider>
);

const MainAppContent: React.FC<MainAppProps> = ({ user, onLogout, showToast }) => {
    const [activeTab, setActiveTab] = useState<TabName>('home');
    const [currentUser, setCurrentUser] = useState<User>(user);
    const [scanAction, setScanAction] = useState<ScanAction>(null);


    const switchTab = (tab: TabName, action: ScanAction = null) => {
        setScanAction(action);
        setActiveTab(tab);
    };

    const handleUpdateUser = (updatedUser: User) => {
        setCurrentUser(updatedUser);
        const employees = getEmployees();
        const userIndex = employees.findIndex(e => e.id === updatedUser.id);
        if (userIndex > -1) {
            employees[userIndex] = updatedUser;
            saveEmployees(employees);
        }
    };
    
    return (
        <div className="flex flex-col min-h-screen">
            <Header onLogout={onLogout} name={currentUser.name} />
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow pb-20">
                {activeTab === 'home' && <HomeTab user={currentUser} showToast={showToast} onClockIn={(slotId) => switchTab('scan', { type: 'clock-in', slotId })} onUpdateUser={handleUpdateUser} />}
                {activeTab === 'me' && <MeTab user={currentUser} onUpdateUser={handleUpdateUser} showToast={showToast} />}
                {activeTab === 'scan' && <ScanTab scanAction={scanAction} onScanComplete={() => switchTab('home')} showToast={showToast} />}
                {activeTab === 'transactions' && <TransactionsTab />}
                {activeTab === 'rewards' && <RewardsTab user={currentUser} />}
            </main>
            <BottomNav activeTab={activeTab} switchTab={switchTab} />
        </div>
    );
};

const Header: React.FC<{ onLogout: () => void; name: string }> = ({ onLogout, name }) => {
    const { lang, setLang, t } = useLanguage();
    return (
        <header className="bg-white shadow-sm sticky top-0 z-50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center py-4">
                    <div className="text-3xl font-bold text-green-700 italic">🌱 Farmfura</div>
                    <nav className="flex items-center space-x-2 md:space-x-6">
                        <span className="font-semibold text-gray-700 hidden md:block">{t('welcome_user', { name })}</span>
                        <div className="relative ml-2 pl-2 md:ml-4 md:pl-4 border-l">
                            <select value={lang} onChange={e => setLang(e.target.value as any)} className="block appearance-none bg-white border border-gray-300 hover:border-gray-500 px-2 py-2 pr-6 md:px-4 md:pr-8 rounded-md shadow-sm text-sm focus:outline-none focus:ring-green-500 focus:border-green-500">
                                <option value="en">EN</option>
                                <option value="kn">KN</option>
                                <option value="hi">HI</option>
                            </select>
                        </div>
                        <a href="#" onClick={onLogout} className="font-semibold text-red-600 hover:text-red-800">{t('nav_logout')}</a>
                    </nav>
                </div>
            </div>
        </header>
    );
};

const BottomNav: React.FC<{ activeTab: TabName; switchTab: (tab: TabName) => void }> = ({ activeTab, switchTab }) => {
    const { t } = useLanguage();
    const navItems = [
        { id: 'home', icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path> },
        { id: 'rewards', icon: <><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm0 0v12"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.36 6.64A9 9 0 016.64 18.36"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.36 18.36A9 9 0 016.64 6.64"></path></> },
        { id: 'scan', icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v1m6 11h-1m-1-6v1m-1-1h1m-1 6h1m-1-1v1M4 12h1m11 6v-1m-1 1h-1m6-1v-1m-1 1h-1M9 4v1M4 9h1M4 4l1 1m14 14l-1-1M4 15l1-1m14-1l-1 1M9 20v-1m6 1v-1m-1-16l-1 1M8 4l-1 1"></path> },
        { id: 'transactions', icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path> },
        { id: 'me', icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path> },
    ];

    const renderNavItem = (item: any) => {
        if (item.id === 'scan') {
            return (
                <button key={item.id} onClick={() => switchTab(item.id)} className="flex flex-col items-center justify-center w-1/5 -mt-8" aria-label={t('scan_title')}>
                    <div className="w-16 h-16 bg-yellow-400 rounded-2xl flex items-center justify-center text-black shadow-lg">
                        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">{item.icon}</svg>
                    </div>
                </button>
            );
        }
        return (
            <button key={item.id} onClick={() => switchTab(item.id)} className={`flex flex-col items-center justify-center w-1/5 ${activeTab === item.id ? 'text-green-600' : 'text-gray-500'}`} aria-label={t(`nav_${item.id}` as any)}>
                <svg className="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">{item.icon}</svg>
                <span className="text-xs">{t(`nav_${item.id}` as any)}</span>
            </button>
        );
    };

    return (
        <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center h-16 z-40">
            {navItems.map(renderNavItem)}
        </footer>
    );
};

// --- TABS ---

const HomeTab: React.FC<{ user: User; showToast: (msg: string, isError?: boolean) => void; onClockIn: (slotId: string) => void; onUpdateUser: (user: User) => void; }> = ({ user, showToast, onClockIn, onUpdateUser }) => {
    const [selectedDate, setSelectedDate] = useState<string | null>(null);
    const { lang, t } = useLanguage();
    const [bookedSlots, setBookedSlots] = useState<TimeSlot[]>(getBookedSlots);
    const [selectedSlots, setSelectedSlots] = useState<Record<string, boolean>>({});
    const [isBookingModalOpen, setBookingModalOpen] = useState(false);
    const [isCancelModalOpen, setCancelModalOpen] = useState(false);
    const [slotToCancel, setSlotToCancel] = useState<TimeSlot | null>(null);

    const refreshSlots = () => setBookedSlots(getBookedSlots());

    const dates = Array.from({ length: 7 }).map((_, i) => {
        const d = new Date();
        d.setDate(d.getDate() + i);
        return d;
    });
    
    const handleSimulateCompletion = () => {
        const now = new Date();
        const slots = getBookedSlots();
        const employees = getEmployees();
        const currentUserIndex = employees.findIndex(e => e.id === user.id);
        if (currentUserIndex === -1) return;

        let payout_total = 0;
        let points_total = 0;
        let slots_updated = 0;

        const updatedSlots = slots.map(slot => {
            if (slot.status === 'Booked' && new Date(slot.date) < now) {
                const payout = Math.floor(Math.random() * (370 - 60 + 1)) + 60; // Random payout
                payout_total += payout;
                points_total += slot.isBonus ? 50 : 25; // More points for bonus slots
                slots_updated++;
                return { ...slot, status: 'Completed' as const, payout };
            }
            return slot;
        });
        
        if (slots_updated > 0) {
            employees[currentUserIndex].balance = (employees[currentUserIndex].balance || 0) + payout_total;
            employees[currentUserIndex].rewardPoints = (employees[currentUserIndex].rewardPoints || 0) + points_total;

            saveBookedSlots(updatedSlots);
            saveEmployees(employees);
            onUpdateUser(employees[currentUserIndex]); // Update parent state
            refreshSlots();
            showToast(t('simulation_success'));
        } else {
            showToast("No past slots to complete.", true);
        }
    };

    const handleProceedToBook = () => {
        const slotsToBook = Object.keys(selectedSlots).filter(key => selectedSlots[key]);
        if (slotsToBook.length === 0) return;
        
        const currentBookedCount = bookedSlots.filter(s => s.status === 'Booked').length;
        if (currentBookedCount + slotsToBook.length > 5) {
            showToast(t('booking_limit_reached'), true);
            return;
        }
        setBookingModalOpen(true);
    };

    const confirmBooking = () => {
        const timeSlotTemplates = getTimeSlotTemplates();
        const slotsToBook = Object.keys(selectedSlots).filter(key => selectedSlots[key]);
        const newSlots: TimeSlot[] = slotsToBook.map(time => {
            const template = timeSlotTemplates.find(t => t.time === time);
            return {
                id: 'slot' + Date.now() + Math.random(),
                date: selectedDate!,
                time,
                shop: user.shopName,
                status: 'Booked',
                isBonus: template?.isBonus || false,
            };
        });
        const updatedSlots = [...bookedSlots, ...newSlots];
        saveBookedSlots(updatedSlots);
        refreshSlots();
        showToast(t('booking_success'));
        setBookingModalOpen(false);
        setSelectedSlots({});
    };

    const confirmCancellation = () => {
        if (!slotToCancel) return;
        const updatedSlots = bookedSlots.filter(s => s.id !== slotToCancel.id);
        saveBookedSlots(updatedSlots);
        refreshSlots();
        showToast(t('cancellation_success'));
        setCancelModalOpen(false);
        setSlotToCancel(null);
    };
    
    const getTimeSlotTemplates = (): TimeSlotTemplate[] => [
        { time: "08:00 AM - 11:00 AM", payoutRange: "₹60 - ₹370", isBonus: false },
        { time: "11:00 AM - 02:00 PM", payoutRange: "₹60 - ₹370", isBonus: false },
        { time: "02:00 PM - 05:00 PM", payoutRange: "₹100 - ₹500", isBonus: true }, // Bonus slot
        { time: "05:00 PM - 08:00 PM", payoutRange: "₹60 - ₹370", isBonus: false }
    ];

    if (!selectedDate) {
        return (
            <div>
                <div className="text-center font-bold text-gray-500 mb-4">{t('this_week')}</div>
                {dates.map((date, i) => (
                    <div key={date.toISOString()} onClick={() => setSelectedDate(date.toISOString())} className={`p-4 rounded-xl flex items-center space-x-4 mb-3 shadow-sm cursor-pointer ${i === 0 ? 'bg-blue-500' : 'bg-green-500'} text-white`}>
                        <div className="text-center">
                            <p className="text-2xl font-bold">{date.getDate()}</p>
                            <p className="text-sm">{date.toLocaleDateString(lang, { weekday: 'short' })}</p>
                        </div>
                        <div className="flex-grow">
                           <p className="font-semibold">{t('time_blocks_available')}</p>
                        </div>
                        <div className="text-2xl font-light">&gt;</div>
                    </div>
                ))}
                <button onClick={handleSimulateCompletion} className="w-full mt-4 bg-purple-600 text-white font-bold py-3 rounded-md hover:bg-purple-700">{t('mark_past_slots_complete')}</button>
            </div>
        );
    }
    
    const timeSlotTemplates = getTimeSlotTemplates();
    const formattedDate = `${new Date(selectedDate).getDate()} ${new Date(selectedDate).toLocaleString(lang, { month: 'short' }).toUpperCase()}`;
    const dateBookedSlots = bookedSlots.filter(s => new Date(s.date).toDateString() === new Date(selectedDate).toDateString());
    
    return (
        <div>
            <button onClick={() => setSelectedDate(null)} className="text-lg mb-4">&larr; {t('time_block_title')}, {formattedDate}</button>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
                <p className="font-bold text-blue-800">{user.shopName}</p>
            </div>
            
            <div className="space-y-3 mb-6">
                <h3 className="font-bold">{t('open_time_blocks')}</h3>
                {timeSlotTemplates.map(slot => {
                    const isBooked = dateBookedSlots.some(bs => bs.time === slot.time);
                    if (isBooked) return null;
                    return (
                        <div key={slot.time} className="bg-white p-4 rounded-lg flex justify-between items-center shadow-sm">
                            <div>
                                <p className="font-semibold flex items-center">{slot.time} {slot.isBonus && <span className="ml-2 text-yellow-500">⚡️</span>}</p>
                                <p className="text-sm text-gray-500">{t('payout')} {slot.payoutRange}</p>
                            </div>
                            <input type="checkbox" checked={!!selectedSlots[slot.time]} onChange={e => setSelectedSlots({...selectedSlots, [slot.time]: e.target.checked})} className="h-6 w-6 rounded-md border-gray-300 text-green-600 focus:ring-green-500"/>
                        </div>
                    );
                })}
            </div>

            <div className="space-y-3">
                <h3 className="font-bold">{t('booked_time_blocks')}</h3>
                {dateBookedSlots.length > 0 ? dateBookedSlots.map(slot => {
                    const isToday = new Date(slot.date).toDateString() === new Date().toDateString();
                    return (
                    <div key={slot.id} className="bg-white p-4 rounded-lg flex justify-between items-center shadow-sm">
                        <div>
                            <p className="font-semibold">{slot.time}</p>
                            {/* FIX: Use correct translation keys for all slot statuses and handle 'Completed' status */}
                            <p className={`text-sm font-bold ${slot.status === 'On Duty' ? 'text-green-600' : 'text-gray-500'}`}>{t(slot.status === 'On Duty' ? 'on_duty' : slot.status === 'Completed' ? 'completed' : 'booked')}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                            {isToday && slot.status === 'Booked' &&
                                <button onClick={() => onClockIn(slot.id)} className="text-sm bg-blue-100 text-blue-700 px-3 py-1 rounded-full">{t('clock_in')}</button>
                            }
                            {new Date(slot.date) > new Date() && slot.status === 'Booked' && 
                              <button onClick={() => {setSlotToCancel(slot); setCancelModalOpen(true)}} className="text-sm bg-red-100 text-red-700 px-3 py-1 rounded-full">{t('cancel')}</button>
                            }
                        </div>
                    </div>
                )}) : <p className="text-center text-gray-500">{t('no_booked_slots')}</p>}
            </div>
            
            <button onClick={handleProceedToBook} disabled={Object.values(selectedSlots).every(v => !v)} className="w-full mt-6 bg-green-600 text-white font-bold py-3 rounded-md disabled:bg-gray-300 disabled:text-gray-500">{t('proceed_to_book')}</button>

            <Modal isOpen={isBookingModalOpen} onClose={() => setBookingModalOpen(false)}>
                <h3 className="text-xl font-bold mb-4">{t('confirm_booking_title')}</h3>
                <div className="mb-4">
                    <p>{t('booking_summary')}</p>
                    <ul className="list-disc pl-5 mt-2">
                        {Object.keys(selectedSlots).filter(s => selectedSlots[s]).map(s => <li key={s}>{s}</li>)}
                    </ul>
                </div>
                <div className="flex justify-end space-x-3">
                    <button onClick={() => setBookingModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300">{t('cancel')}</button>
                    <button onClick={confirmBooking} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">{t('confirm')}</button>
                </div>
            </Modal>
            
            <Modal isOpen={isCancelModalOpen} onClose={() => setCancelModalOpen(false)}>
                <h3 className="text-xl font-bold mb-4">{t('confirm_cancellation_title')}</h3>
                <p className="mb-4">{t('confirm_cancellation_body', { penalty: '' })}</p>
                <div className="flex justify-end space-x-3">
                    <button onClick={() => setCancelModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300">{t('no')}</button>
                    <button onClick={confirmCancellation} className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">{t('yes_cancel')}</button>
                </div>
            </Modal>
        </div>
    );
};

const MeTab: React.FC<{ user: User; onUpdateUser: (user: User) => void; showToast: (msg: string, isError?: boolean) => void }> = ({ user, onUpdateUser, showToast }) => {
    const { t } = useLanguage();
    const { isHighContrast, toggleHighContrast } = useTheme();
    const [view, setView] = useState<'main' | 'bank' | 'withdraw'>('main');
    const [isSupportModalOpen, setSupportModalOpen] = useState(false);
    const [bankDetails, setBankDetails] = useState<BankDetails>(user.bankDetails || { accountNumber: '', ifsc: '', branch: '', bank: '' });
    const [bankDetailsErrors, setBankDetailsErrors] = useState<{ accountNumber?: string; ifsc?: string; bank?: string }>({});
    const [withdrawAmount, setWithdrawAmount] = useState('');
    const [withdrawals, setWithdrawals] = useState<Withdrawal[]>(getWithdrawals);
    const [isConfirmWithdrawalModalOpen, setConfirmWithdrawalModalOpen] = useState(false);
    
    const userRoles = Array.isArray(user.role) ? user.role.join(', ') : user.role;

    const validateBankDetails = (): boolean => {
        const errors: { accountNumber?: string; ifsc?: string; bank?: string } = {};
        const { accountNumber, ifsc, bank } = bankDetails;

        if (!accountNumber) {
            errors.accountNumber = t('field_required', { field: t('bank_account_number') });
        } else if (!/^\d{9,18}$/.test(accountNumber)) {
            errors.accountNumber = t('account_number_invalid');
        }

        if (!ifsc) {
            errors.ifsc = t('field_required', { field: t('ifsc_code') });
        } else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc.toUpperCase())) {
            errors.ifsc = t('ifsc_invalid');
        }

        if (!bank) {
            errors.bank = t('field_required', { field: t('bank_name') });
        } else if (!/^[a-zA-Z\s]+$/.test(bank)) {
            errors.bank = t('bank_name_invalid');
        }

        setBankDetailsErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const handleSaveBankDetails = () => {
        if (validateBankDetails()) {
            const updatedUser = { ...user, bankDetails };
            onUpdateUser(updatedUser);
            showToast(t('bank_details_saved'));
            setView('main');
        }
    };
    
    const handleToggleAutoPayout = () => {
        const updatedUser = { ...user, autoPayoutEnabled: !user.autoPayoutEnabled };
        onUpdateUser(updatedUser);
    };

    const handleWithdraw = () => {
        if (!user.bankDetails?.accountNumber || !user.bankDetails?.ifsc) {
            showToast(t('bank_details_required'), true);
            return;
        }
        setView('withdraw');
    };

    const handleInitiateWithdrawal = () => {
        const amount = parseFloat(withdrawAmount);
        if (isNaN(amount) || amount <= 0) {
            showToast('Please enter a valid amount.', true);
            return;
        }
        if (amount > (user.balance || 0)) {
            showToast(t('insufficient_balance'), true);
            return;
        }
        setConfirmWithdrawalModalOpen(true);
    };

    const executeWithdrawal = () => {
        const amount = parseFloat(withdrawAmount);
        const newBalance = (user.balance || 0) - amount;
        const updatedUser = { ...user, balance: newBalance };
        onUpdateUser(updatedUser);

        const newWithdrawal: Withdrawal = {
            id: 'W' + Date.now(),
            amount,
            date: new Date().toISOString(),
            status: 'Pending',
        };
        const updatedWithdrawals = [newWithdrawal, ...withdrawals];
        saveWithdrawals(updatedWithdrawals);
        setWithdrawals(updatedWithdrawals);
        
        showToast(t('withdrawal_success'));
        setWithdrawAmount('');
        setConfirmWithdrawalModalOpen(false);
        setView('main');
    };

    if (view === 'bank') {
        return (
            <div>
                <button onClick={() => setView('main')} className="text-lg mb-4">&larr; {t('bank_details')}</button>
                <div className="bg-white p-6 rounded-lg shadow-sm space-y-4">
                    <div>
                        <input 
                            type="text" 
                            placeholder={t('bank_account_number')} 
                            value={bankDetails.accountNumber} 
                            onChange={e => {
                                setBankDetails({...bankDetails, accountNumber: e.target.value});
                                if (bankDetailsErrors.accountNumber) setBankDetailsErrors(prev => ({...prev, accountNumber: undefined}));
                            }} 
                            className="w-full mt-1 p-3 border rounded-md" />
                        {bankDetailsErrors.accountNumber && <p className="text-red-500 text-xs mt-1">{bankDetailsErrors.accountNumber}</p>}
                    </div>
                    <div>
                        <input 
                            type="text" 
                            placeholder={t('ifsc_code')} 
                            value={bankDetails.ifsc} 
                            onChange={e => {
                                setBankDetails({...bankDetails, ifsc: e.target.value.toUpperCase()});
                                if (bankDetailsErrors.ifsc) setBankDetailsErrors(prev => ({...prev, ifsc: undefined}));
                            }} 
                            className="w-full mt-1 p-3 border rounded-md" />
                        {bankDetailsErrors.ifsc && <p className="text-red-500 text-xs mt-1">{bankDetailsErrors.ifsc}</p>}
                    </div>
                    <div>
                        <input type="text" placeholder={t('branch_name')} value={bankDetails.branch} onChange={e => setBankDetails({...bankDetails, branch: e.target.value})} className="w-full mt-1 p-3 border rounded-md" />
                    </div>
                    <div>
                        <input 
                            type="text" 
                            placeholder={t('bank_name')} 
                            value={bankDetails.bank} 
                            onChange={e => {
                                setBankDetails({...bankDetails, bank: e.target.value});
                                if (bankDetailsErrors.bank) setBankDetailsErrors(prev => ({...prev, bank: undefined}));
                            }} 
                            className="w-full mt-1 p-3 border rounded-md" />
                        {bankDetailsErrors.bank && <p className="text-red-500 text-xs mt-1">{bankDetailsErrors.bank}</p>}
                    </div>
                    <button onClick={handleSaveBankDetails} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{t('save_details')}</button>
                </div>
            </div>
        );
    }

    if (view === 'withdraw') {
        return (
            <div>
                <button onClick={() => setView('main')} className="text-lg mb-4">&larr; {t('withdraw_funds_title')}</button>
                <div className="bg-white p-6 rounded-lg shadow-sm space-y-4">
                    <p className="text-sm text-gray-600">{t('available_balance')}: <span className="font-bold">₹{user.balance?.toFixed(2) || '0.00'}</span></p>
                    <div>
                        <label htmlFor="withdraw-amount" className="text-sm font-medium text-gray-700">{t('amount_to_withdraw')}</label>
                        <div className="relative mt-1">
                            <input id="withdraw-amount" type="number" placeholder={t('enter_amount')} value={withdrawAmount} onChange={e => setWithdrawAmount(e.target.value)} className="w-full p-3 border rounded-md" />
                            <button onClick={() => setWithdrawAmount(String(user.balance || 0))} className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-green-600">{t('withdraw_all')}</button>
                        </div>
                    </div>
                    <button onClick={handleInitiateWithdrawal} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{t('confirm_withdrawal')}</button>
                </div>

                <div className="bg-white p-4 rounded-lg shadow-sm mt-6">
                    <h3 className="font-bold mb-4">{t('withdrawal_history')}</h3>
                    <div className="space-y-3 max-h-48 overflow-y-auto">
                        {withdrawals.length > 0 ? withdrawals.map(w => (
                             <div key={w.id} className="flex justify-between items-center">
                                <div>
                                    <p className="font-semibold">₹{w.amount.toFixed(2)}</p>
                                    <p className="text-xs text-gray-500">{new Date(w.date).toLocaleDateString()}</p>
                                </div>
                                <p className={`text-sm font-bold ${w.status === 'Completed' ? 'text-green-600' : w.status === 'Failed' ? 'text-red-600' : 'text-yellow-600'}`}>{t(`status_${w.status.toLowerCase()}` as any)}</p>
                             </div>
                        )) : <p className="text-center text-gray-500">{t('no_withdrawals')}</p>}
                    </div>
                </div>
            </div>
        );
    }
    
    return (
        <div>
            <h2 className="text-xl font-bold mb-4">{t('me_title')}</h2>
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6 space-y-4">
                <div><p className="text-sm font-medium text-gray-500">Name</p><p className="font-semibold text-lg">{user.name}</p></div>
                <div><p className="text-sm font-medium text-gray-500">Phone</p><p className="font-semibold text-lg">{user.phone}</p></div>
                <div><p className="text-sm font-medium text-gray-500">{t('roles')}</p><p className="font-semibold text-lg capitalize">{userRoles}</p></div>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
                <p className="font-bold">{t('earnings_and_withdrawal')}</p>
                <p className="text-sm text-gray-500 mb-4">{t('manage_earnings')}</p>
                <div className="flex justify-between items-center bg-gray-50 p-3 rounded-md">
                    <div>
                        <p className="text-sm text-gray-600">{t('available_balance')}</p>
                        <p className="text-2xl font-bold">₹{user.balance?.toFixed(2) || '0.00'}</p>
                    </div>
                    <button onClick={handleWithdraw} className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 font-semibold">{t('withdraw_button')}</button>
                </div>
            </div>

            <div onClick={() => setView('bank')} className="bg-white p-4 rounded-lg shadow-sm mb-6 cursor-pointer flex justify-between items-center">
                <div><p className="font-bold">{t('bank_details')}</p><p className="text-sm text-gray-500">{t('manage_bank_details')}</p></div>
                <div className="text-2xl font-light text-gray-400">&gt;</div>
            </div>

             <h2 className="text-xl font-bold mb-4 mt-6">{t('payout_settings')}</h2>
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
                <div className="flex justify-between items-center">
                    <div>
                        <p className="font-bold">{t('auto_payout_weekly')}</p>
                        <p className="text-sm text-gray-500">{t('auto_payout_desc')}</p>
                    </div>
                    <label htmlFor="auto-payout-toggle" className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="auto-payout-toggle" className="sr-only peer" checked={!!user.autoPayoutEnabled} onChange={handleToggleAutoPayout} />
                        <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-green-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                    </label>
                </div>
            </div>

            <h2 className="text-xl font-bold mb-4 mt-6">{t('accessibility')}</h2>
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
                <div className="flex justify-between items-center">
                    <div>
                        <p className="font-bold">{t('high_contrast_mode')}</p>
                        <p className="text-sm text-gray-500">{t('high_contrast_desc')}</p>
                    </div>
                    <label htmlFor="high-contrast-toggle" className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="high-contrast-toggle" className="sr-only peer" checked={isHighContrast} onChange={toggleHighContrast} />
                        <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                </div>
            </div>

            <h2 className="text-xl font-bold mb-4 mt-6">{t('help_support')}</h2>
            <div className="bg-white p-4 rounded-lg shadow-sm space-y-4">
                <div><p className="font-semibold">{t('faq1_q')}</p><p className="text-sm text-gray-600">{t('faq1_a')}</p></div>
                <div className="border-t pt-4"><p className="font-semibold">{t('faq2_q')}</p><p className="text-sm text-gray-600">{t('faq2_a')}</p></div>
                <div className="border-t pt-4"><button onClick={() => setSupportModalOpen(true)} className="text-blue-600 hover:underline font-semibold">{t('contact_support')}</button></div>
            </div>

            <Modal isOpen={isConfirmWithdrawalModalOpen} onClose={() => setConfirmWithdrawalModalOpen(false)}>
                <h3 className="text-xl font-bold mb-4">{t('confirm_withdrawal_title')}</h3>
                {parseFloat(withdrawAmount) > 0 && (
                    <p className="mb-4">
                        {t('confirm_withdrawal_summary', { 
                            amount: parseFloat(withdrawAmount).toFixed(2), 
                            newBalance: ((user.balance || 0) - parseFloat(withdrawAmount)).toFixed(2) 
                        })}
                    </p>
                )}
                <div className="flex justify-end space-x-3">
                    <button onClick={() => setConfirmWithdrawalModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300">{t('cancel')}</button>
                    <button onClick={executeWithdrawal} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">{t('confirm_and_withdraw')}</button>
                </div>
            </Modal>
            
            <Modal isOpen={isSupportModalOpen} onClose={() => setSupportModalOpen(false)}>
                <h3 className="text-xl font-bold mb-4">{t('contact_support_title')}</h3>
                <textarea className="w-full p-2 border rounded-md" rows={4} placeholder={t('message')}></textarea>
                <div className="flex justify-end mt-4">
                    <button onClick={() => { setSupportModalOpen(false); showToast(t('support_request_sent')); }} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">{t('send_message')}</button>
                </div>
            </Modal>
        </div>
    );
};

const ScanTab: React.FC<{ scanAction: ScanAction; onScanComplete: () => void; showToast: (msg: string, isError?: boolean) => void; }> = ({ scanAction, onScanComplete, showToast }) => {
    const { t } = useLanguage();
    const videoRef = useRef<HTMLVideoElement>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
    const [error, setError] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const startCamera = async (mode: 'environment' | 'user') => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        setLoading(true);
        setError(null);
        try {
            const newStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: mode } });
            if (videoRef.current) {
                videoRef.current.srcObject = newStream;
            }
            setStream(newStream);
        } catch (err) {
            console.error(err);
            setError(t('camera_error'));
        } finally {
            setLoading(false);
        }
    };
    
    useEffect(() => {
        startCamera(facingMode);
        return () => {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [facingMode]);

    const switchCamera = () => {
        setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
    };
    
    const handleScan = () => {
        if (scanAction?.type === 'clock-in') {
            const slots = getBookedSlots();
            const slotIndex = slots.findIndex(s => s.id === scanAction.slotId);
            if (slotIndex > -1) {
                slots[slotIndex].status = 'On Duty';
                saveBookedSlots(slots);
                showToast(t('clock_in_success'));
                onScanComplete();
            }
        } else {
            showToast("Scan successful (no action).");
        }
    };

    return (
        <div>
            <h2 className="text-xl font-bold mb-4">{scanAction?.type === 'clock-in' ? t('clock_in') : t('scan_title')}</h2>
            {scanAction?.type === 'clock-in' && <p className="text-center mb-4">{t('scan_store_qr_clock_in')}</p>}
             <div onClick={handleScan} className="relative w-full bg-gray-800 rounded-lg overflow-hidden flex items-center justify-center min-h-[300px] md:min-h-[500px] cursor-pointer">
                 <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline muted />
                 {loading && <p className="absolute text-white">{t('starting_camera')}</p>}
                 {error && <div className="absolute text-white text-center p-4">
                    <p>{error}</p>
                    <button onClick={() => startCamera(facingMode)} className="mt-2 bg-yellow-500 text-white text-sm font-bold py-2 px-3 rounded-md hover:bg-yellow-600">{t('retry_camera')}</button>
                 </div>}
            </div>
            <button onClick={switchCamera} className="w-full mt-4 bg-blue-500 text-white font-bold py-3 rounded-md hover:bg-blue-600">{t('switch_camera')}</button>
        </div>
    );
};

const TransactionsTab: React.FC = () => {
    const { lang, t } = useLanguage();
    const completedSlots = getBookedSlots().filter(s => s.status === 'Completed').sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    // Process data for chart
    const earningsByDay: Record<string, number> = {};
    for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const key = d.toISOString().split('T')[0];
        earningsByDay[key] = 0;
    }
    completedSlots.forEach(slot => {
        const key = new Date(slot.date).toISOString().split('T')[0];
        if (key in earningsByDay) {
            earningsByDay[key] += slot.payout || 0;
        }
    });
    
    const chartData = Object.entries(earningsByDay);
    const maxEarning = Math.max(...chartData.map(([, amount]) => amount), 1); // Avoid division by zero
    
    return (
        <div>
            <h2 className="text-xl font-bold mb-4">{t('last_7_days_earnings')}</h2>
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
                {chartData.every(([, amount]) => amount === 0) ? (
                    <p className="text-center text-gray-500">{t('no_earnings_yet')}</p>
                ) : (
                    <div className="flex justify-around items-end h-48 space-x-2">
                        {chartData.map(([date, amount]) => (
                            <div key={date} className="flex flex-col items-center flex-grow">
                                <div className="text-xs font-bold">₹{amount}</div>
                                <div className="w-full bg-green-500 rounded-t-md" style={{ height: `${(amount / maxEarning) * 100}%` }}></div>
                                <div className="text-xs mt-1">{new Date(date).getDate()}</div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            <h2 className="text-xl font-bold mb-4">{t('transaction_history')}</h2>
            <div className="space-y-3">
            {completedSlots.length > 0 ? completedSlots.map(slot => (
                <div key={slot.id} className="bg-white p-4 rounded-lg shadow-sm">
                    <div className="flex justify-between items-center">
                        <div>
                            <p className="font-semibold">{new Date(slot.date).toLocaleDateString(lang, { year: 'numeric', month: 'short', day: 'numeric' })}</p>
                            <p className="text-sm text-gray-500">{slot.time}</p>
                        </div>
                        <p className="font-bold text-green-600">+ ₹{slot.payout}</p>
                    </div>
                </div>
            )) : <p className="text-center text-gray-500">{t('no_transactions')}</p>}
            </div>
        </div>
    );
};

const RewardsTab: React.FC<{user: User}> = ({ user }) => {
    const { t } = useLanguage();
    const points = user.rewardPoints || 0;
    const tiers = { silver: 1000, gold: 5000 };
    const nextTier = points < tiers.silver ? 'silver' : 'gold';
    const nextTierPoints = tiers[nextTier];
    const progress = Math.min((points / nextTierPoints) * 100, 100);

    return (
        <div>
            <h2 className="text-xl font-bold mb-4">{t('rewards_title')}</h2>
            <div className="bg-white p-6 rounded-lg shadow-sm text-center mb-6">
                <p className="text-lg text-gray-500">{t('rewards_points')}</p>
                <p className="text-5xl font-bold text-yellow-500">{points}</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
                <p className="text-sm font-semibold mb-2">{t('progress_to_next_tier')}: {t(`tier_${nextTier}` as any)}</p>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-yellow-400 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                </div>
            </div>

            <h3 className="text-lg font-semibold mb-4">{t('reward_tiers')}</h3>
            <div className="space-y-3">
                <div className="bg-white p-4 rounded-lg shadow-sm"><p className="font-bold text-yellow-800">{t('tier_bronze')}</p></div>
                <div className={`bg-white p-4 rounded-lg shadow-sm ${points < tiers.silver && 'opacity-50'}`}><p className="font-bold text-gray-500">{t('tier_silver')}</p></div>
                <div className={`bg-white p-4 rounded-lg shadow-sm ${points < tiers.gold && 'opacity-50'}`}><p className="font-bold text-gray-500">{t('tier_gold')}</p></div>
            </div>
        </div>
    );
};