
import React, { useState, useCallback, useRef, useEffect } from 'react';

type CameraStatus = 'idle' | 'starting' | 'running' | 'error' | 'permission';

interface UseCameraResult {
  stream: MediaStream | null;
  status: CameraStatus;
  startCamera: (facingMode?: 'user' | 'environment') => Promise<void>;
  stopCamera: () => void;
  captureFrame: () => string | null;
  videoRef: React.RefObject<HTMLVideoElement>;
  canvasRef: React.RefObject<HTMLCanvasElement>;
}

export const useCamera = (): UseCameraResult => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [status, setStatus] = useState<CameraStatus>('idle');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setStatus('idle');
      if (videoRef.current) {
          videoRef.current.srcObject = null;
      }
    }
  }, [stream]);

  const startCamera = useCallback(async (facingMode: 'user' | 'environment' = 'user') => {
    stopCamera();
    setStatus('starting');
    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode },
        audio: false,
      });
      setStream(newStream);
      setStatus('running');
      if (videoRef.current) {
        videoRef.current.srcObject = newStream;
      }
    } catch (err) {
      console.error("Camera access error:", err);
      if (err instanceof DOMException && (err.name === "NotAllowedError" || err.name === "PermissionDeniedError")) {
          setStatus('permission');
      } else {
          setStatus('error');
      }
    }
  }, [stopCamera]);

  const captureFrame = useCallback((): string | null => {
    if (videoRef.current && canvasRef.current && stream) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        // Flip horizontally for user-facing camera
        const isUserFacing = stream.getVideoTracks()[0]?.getSettings().facingMode === 'user';
        if (isUserFacing) {
            context.translate(canvas.width, 0);
            context.scale(-1, 1);
        }
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL('image/jpeg');
      }
    }
    return null;
  }, [stream]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  return { stream, status, startCamera, stopCamera, captureFrame, videoRef, canvasRef };
};