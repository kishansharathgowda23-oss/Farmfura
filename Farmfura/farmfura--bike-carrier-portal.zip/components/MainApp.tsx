import React, { useState, useContext, useCallback } from 'react';
import { AuthContext, LanguageContext } from '../App';
import DeliveriesTab from './HomeTab';
import ProfileTab from './ProfileTab';
import ScanTab from './ScanTab';
import TransactionsTab from './TransactionsTab';
import RewardsTab from './RewardsTab';

type TabName = 'deliveries' | 'profile' | 'scan' | 'transactions' | 'rewards';

const Header = () => {
    const { currentUser, logout } = useContext(AuthContext);
    const { language, setLanguage, translate } = useContext(LanguageContext);

    return (
         <header className="bg-white shadow-sm sticky top-0 z-50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center py-4">
                    <div className="text-3xl font-bold text-green-700 italic">🌱 Farmfura</div>
                    <nav className="flex items-center space-x-2 md:space-x-6">
                        <span className="font-semibold text-gray-700 hidden sm:block">{translate('welcome_user', { name: currentUser!.name.split(' ')[0] })}</span>
                         <div className="relative pl-2 md:pl-4 md:border-l">
                             <select 
                                id="language-switcher"
                                value={language}
                                onChange={(e) => setLanguage(e.target.value)}
                                className="block appearance-none w-full bg-white border border-gray-300 hover:border-gray-500 px-4 py-2 pr-8 rounded-md shadow-sm text-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                              >
                                <option value="en">English</option>
                                <option value="kn">ಕನ್ನಡ</option>
                                <option value="hi">हिन्दी</option>
                            </select>
                        </div>
                        <button onClick={logout} className="font-semibold text-red-600 hover:text-red-800">{translate('nav_logout')}</button>
                    </nav>
                </div>
            </div>
        </header>
    );
};

const BottomNav: React.FC<{ activeTab: TabName; onTabChange: (tab: TabName) => void }> = ({ activeTab, onTabChange }) => {
    const { translate } = useContext(LanguageContext);

    // FIX: Changed icon type from JSX.Element to React.ReactNode to resolve namespace error.
    const NavButton: React.FC<{ tab: TabName; icon: React.ReactNode; label: string }> = ({ tab, icon, label }) => (
         <button onClick={() => onTabChange(tab)} className={`flex flex-col items-center justify-center w-1/5 ${activeTab === tab ? 'text-green-600' : 'text-gray-500'}`}>
            {icon}
            <span className="text-xs">{label}</span>
        </button>
    );
    
    return (
        <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center h-16 z-40">
            <NavButton tab="deliveries" label={translate('nav_deliveries')} icon={<svg className="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.125-.504 1.125-1.125V14.25m-17.25 4.5h10.5a1.125 1.125 0 001.125-1.125V6.75a1.125 1.125 0 00-1.125-1.125H3.375A1.125 1.125 0 002.25 6.75v10.5a1.125 1.125 0 001.125 1.125z" /></svg>} />
            <NavButton tab="rewards" label={translate('nav_rewards')} icon={<svg className="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm0 0v12"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.36 6.64A9 9 0 016.64 18.36"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.36 18.36A9 9 0 016.64 6.64"></path></svg>} />
            <button onClick={() => onTabChange('scan')} className="flex flex-col items-center justify-center w-1/5 -mt-8">
                <div className="w-16 h-16 bg-yellow-400 rounded-2xl flex items-center justify-center text-black shadow-lg">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v1m6 11h-1m-1-6v1m-1-1h1m-1 6h1m-1-1v1M4 12h1m11 6v-1m-1 1h-1m6-1v-1m-1 1h-1M9 4v1M4 9h1M4 4l1 1m14 14l-1-1M4 15l1-1m14-1l-1 1M9 20v-1m6 1v-1m-1-16l-1 1M8 4l-1 1"></path></svg>
                </div>
            </button>
            <NavButton tab="transactions" label={translate('nav_transactions')} icon={<svg className="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>} />
            <NavButton tab="profile" label={translate('nav_profile')} icon={<svg className="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>} />
        </footer>
    );
};


const MainApp: React.FC = () => {
    const [activeTab, setActiveTab] = useState<TabName>('deliveries');

    const handleTabChange = useCallback((tab: TabName) => {
        setActiveTab(tab);
    }, []);

    const renderContent = () => {
        switch (activeTab) {
            case 'deliveries': return <DeliveriesTab />;
            case 'profile': return <ProfileTab />;
            case 'scan': return <ScanTab />;
            case 'transactions': return <TransactionsTab />;
            case 'rewards': return <RewardsTab />;
            default: return <DeliveriesTab />;
        }
    }

    return (
        <div className="flex flex-col min-h-screen">
            <Header />
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow pb-24">
                {renderContent()}
            </main>
            <BottomNav activeTab={activeTab} onTabChange={handleTabChange} />
        </div>
    );
};

export default MainApp;