import React, { useState, useEffect, useRef } from 'react';
import { LanguageProvider, useLanguage } from './LanguageContext';
import { getEmployees, saveEmployees, getOutlets, getSupplyGrids } from '../services/storageService';
import type { User, Location } from '../types';

enum AuthView {
    Login,
    Register,
    Status,
    Onboarding
}

enum RegStep {
    Phone = 1,
    Otp,
    Preference,
    Location,
    Details
}

const LanguageSwitcher: React.FC<{ inHeader?: boolean }> = ({ inHeader = false }) => {
    const { lang, setLang } = useLanguage();
    return (
        <div className="relative">
            <select
                value={lang}
                onChange={(e) => setLang(e.target.value as 'en' | 'kn' | 'hi')}
                className="block appearance-none w-full bg-white border border-gray-300 hover:border-gray-500 px-4 py-2 pr-8 rounded-md shadow-sm text-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
            >
                <option value="en">English</option>
                <option value="kn">ಕನ್ನಡ</option>
                <option value="hi">हिन्दी</option>
            </select>
        </div>
    );
};

interface AuthProps {
    onLogin: (user: User) => void;
    showToast: (message: string, isError?: boolean) => void;
}

export const Auth: React.FC<AuthProps> = (props) => {
    return (
        <LanguageProvider>
            <AuthContent {...props} />
        </LanguageProvider>
    );
};


const AuthContent: React.FC<AuthProps> = ({ onLogin, showToast }) => {
    const { t } = useLanguage();
    const [view, setView] = useState<AuthView>(AuthView.Login);
    const [regStep, setRegStep] = useState<RegStep>(RegStep.Phone);
    const [registrationData, setRegistrationData] = useState<any>({});
    const [statusInfo, setStatusInfo] = useState<{ message: string, type: 'Pending' | 'Rejected' | 'Expired', phone?: string }>({ message: '', type: 'Pending' });

    const [phone, setPhone] = useState('');
    const [otp, setOtp] = useState('');
    const [tempUser, setTempUser] = useState<User | null>(null);
    const [otpLockout, setOtpLockout] = useState(0);

    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const qrVideoRef = useRef<HTMLVideoElement>(null);
    const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
    const [qrStream, setQrStream] = useState<MediaStream | null>(null);
    const [cameraPermissionError, setCameraPermissionError] = useState(false);
    const [qrCameraPermissionError, setQrCameraPermissionError] = useState(false);


    const startCamera = async (constraints: MediaStreamConstraints) => {
        stopCamera(); // Stop any existing streams first
        setCameraPermissionError(false);
        try {
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
            }
            setCameraStream(stream);
            return stream;
        } catch (err) {
            console.error("Camera access denied:", err);
            setCameraPermissionError(true);
            return null;
        }
    };
    
    const stopCamera = () => {
        if (cameraStream) {
            cameraStream.getTracks().forEach(track => track.stop());
            setCameraStream(null);
        }
    };
    
    const stopQrCamera = () => {
        if (qrStream) {
            qrStream.getTracks().forEach(track => track.stop());
            setQrStream(null);
        }
    };
    
    useEffect(() => {
        return () => { // Cleanup on component unmount
            stopCamera();
            stopQrCamera();
        };
    }, []);

    const handleLoginContinue = () => {
        if (!/^\d{10}$/.test(phone)) return showToast(t('phone_placeholder'), true);

        const employees = getEmployees();
        const user = employees.find(emp => emp.phone === phone && (
            (Array.isArray(emp.role) && (emp.role.includes('shopkeeper') || emp.role.includes('shop_owner'))) ||
            (typeof emp.role === 'string' && (emp.role === 'shopkeeper' || emp.role === 'shop_owner'))
        ));

        if (user) {
            setTempUser(user);
            const now = Date.now();
            const expiryTime = 48 * 60 * 60 * 1000;
            
            if (user.status === 'Accepted' && user.approvalTimestamp && (now - user.approvalTimestamp > expiryTime)) {
                user.status = 'Expired';
                const userIndex = employees.findIndex(e => e.id === user.id);
                if (userIndex > -1) {
                    employees[userIndex] = user;
                    saveEmployees(employees);
                }
            }
            
            switch (user.status) {
                case 'Active':
                    setView(AuthView.Login);
                    setRegStep(RegStep.Otp); // Use regStep for login otp view too
                    showToast('OTP Sent! (Demo: 1234)');
                    break;
                case 'Accepted':
                     setView(AuthView.Onboarding);
                    break;
                case 'Pending':
                    setStatusInfo({ message: t('application_pending'), type: 'Pending' });
                    setView(AuthView.Status);
                    break;
                case 'Rejected':
                    setStatusInfo({ message: t('application_rejected', { reason: user.rejectionReason || t('not_specified') }), type: 'Rejected', phone: user.phone });
                    setView(AuthView.Status);
                    break;
                case 'Expired':
                    setStatusInfo({ message: t('application_expired'), type: 'Expired' });
                    setView(AuthView.Status);
                    break;
                default:
                    showToast("Account status unclear. Contact support.", true);
            }
        } else {
            showToast("No shopkeeper account found.", true);
        }
    };

    const handleVerifyLoginOtp = () => {
        if (otpLockout > 0) return;

        if (otp !== '1234') {
             const attempts = parseInt(sessionStorage.getItem(`otp_attempts_${phone}`) || '0') + 1;
             sessionStorage.setItem(`otp_attempts_${phone}`, String(attempts));
            showToast("Invalid OTP.", true);
            if (attempts >= 3) {
                sessionStorage.removeItem(`otp_attempts_${phone}`);
                setOtpLockout(30);
                const timer = setInterval(() => {
                    setOtpLockout(prev => {
                        if (prev <= 1) {
                            clearInterval(timer);
                            return 0;
                        }
                        return prev - 1;
                    });
                }, 1000);
            }
            return;
        }
        
        sessionStorage.removeItem(`otp_attempts_${phone}`);
        if (tempUser && tempUser.status === 'Active') {
            onLogin(tempUser);
        } else {
            showToast("Login failed. Check account status.", true);
            setRegStep(RegStep.Phone);
        }
    };
    
    const handleRegisterSendOtp = () => {
        const phone = registrationData.phone;
        if (!/^\d{10}$/.test(phone)) return showToast(t('phone_placeholder'), true);

        const employees = getEmployees();
        if (employees.some(e => e.phone === phone && e.status !== 'Rejected' && e.status !== 'Expired')) {
            return showToast('Phone number already registered or pending.', true);
        }

        showToast('OTP Sent! (Demo: 123456)');
        setRegStep(RegStep.Otp);
    }
    
    const handleRegisterVerifyOtp = () => {
        if (registrationData.otp !== '123456') return showToast('Invalid OTP.', true);
        setRegistrationData({ ...registrationData, phoneVerified: true });
        setRegStep(RegStep.Preference);
    }

    const handlePhotoCapture = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            if (context) {
                context.translate(canvas.width, 0);
                context.scale(-1, 1);
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                const dataUrl = canvas.toDataURL('image/jpeg');
                setRegistrationData({ ...registrationData, livePhoto: dataUrl });
                stopCamera();
            }
        }
    };
    
    const handleCompleteRegistration = () => {
        const { aadhaarName, gender, workType, aadhaarFile, panFile, livePhoto } = registrationData;
        if (!aadhaarName || !gender || !workType) return showToast('Please fill Name, Gender, Work Type.', true);
        if (!aadhaarFile) return showToast('Please upload Aadhaar.', true);
        if (!panFile) return showToast('Please upload PAN.', true);
        if (!livePhoto) return showToast('Please capture live photo.', true);

        const newUser: User = {
            id: 'SHK' + Date.now(),
            name: aadhaarName,
            role: 'shopkeeper',
            status: 'Pending',
            phone: registrationData.phone,
            shopName: registrationData.shopName,
            ...registrationData
        };

        let employees = getEmployees();
        employees = employees.filter(emp => !(emp.phone === newUser.phone && (emp.status === 'Rejected' || emp.status === 'Expired')));
        employees.push(newUser);
        saveEmployees(employees);
        showToast('Registration complete! Application under review.');
        
        setRegistrationData({});
        setPhone('');
        setOtp('');
        setView(AuthView.Login);
        setRegStep(RegStep.Phone);
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, fieldName: string, previewField: string) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                setRegistrationData({ ...registrationData, [fieldName]: file, [previewField]: event.target?.result });
            };
            reader.readAsDataURL(file);
        }
    };
    
    const startQrScanner = async () => {
        stopQrCamera();
        setQrCameraPermissionError(false);
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
            if (qrVideoRef.current) {
                qrVideoRef.current.srcObject = stream;
                await qrVideoRef.current.play();
            }
            setQrStream(stream);
        } catch (err) {
            console.error("QR Camera access denied:", err);
            setQrCameraPermissionError(true);
        }
    };

    const handleQrScanClick = () => { // Simulate scan on click
        if (tempUser && tempUser.phone) {
            const employees = getEmployees();
            const userIndex = employees.findIndex(emp => emp.phone === tempUser.phone && emp.status === 'Accepted');
            if (userIndex > -1) {
                employees[userIndex].status = 'Active';
                saveEmployees(employees);
                stopQrCamera();
                showToast(t('qr_success'));
                setTimeout(() => onLogin(employees[userIndex]), 1500);
            } else {
                showToast("Invalid QR or user status not 'Accepted'.", true);
                stopQrCamera();
                setView(AuthView.Onboarding);
            }
        }
    };

    const renderLogin = () => (
      <div id="login-form-container" className="bg-white p-8 shadow-lg rounded-lg">
          {regStep === RegStep.Phone && (
              <div id="phone-entry-view">
                  <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{t('shopkeeper_login')}</h2>
                  <div className="space-y-4">
                      <input aria-label="Phone number" type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full p-3 border rounded-md" placeholder={t('phone_placeholder')} required />
                      <button onClick={handleLoginContinue} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{t('send_otp_btn')}</button>
                  </div>
              </div>
          )}
          {regStep === RegStep.Otp && (
              <div id="otp-entry-view">
                  <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">{t('verify_phone_title')}</h2>
                  <p className="text-center text-sm text-gray-600 mb-4">
                      <span>{t('otp_sent_to')} </span>
                      <span className="font-bold">{phone}</span>.
                  </p>
                  <div className="space-y-4">
                      <input aria-label="One-time password" type="text" value={otp} onChange={e => setOtp(e.target.value)} className="w-full p-3 border rounded-md text-center tracking-widest" placeholder={t('otp_placeholder')} />
                      {otpLockout > 0 && <p className="text-xs text-red-500 text-center mt-1" role="alert">{t('otp_lockout', { seconds: otpLockout })}</p>}
                      <button onClick={handleVerifyLoginOtp} disabled={otpLockout > 0} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 disabled:bg-gray-400">{t('verify_login')}</button>
                  </div>
                  <div className="text-center mt-4">
                      <a href="#" onClick={(e) => { e.preventDefault(); setRegStep(RegStep.Phone); setOtp(''); }} className="text-sm text-blue-600 hover:underline">{t('change_number')}</a>
                  </div>
              </div>
          )}

          <p className="text-center text-sm text-gray-600 mt-4">
              <span>{t('no_account')} </span>
              <a href="#" onClick={(e) => { e.preventDefault(); setView(AuthView.Register); setRegStep(RegStep.Phone); }} className="font-semibold text-green-600 hover:text-green-800">{t('register_link')}</a>
          </p>
      </div>
    );
    
    const renderRegister = () => {
        const locations = registrationData.preference === 'supply_grid' ? getSupplyGrids() : getOutlets();

        return (
            <div id="register-form-container" className="bg-white p-8 shadow-lg rounded-lg">
                <div className="relative">
                    {regStep > RegStep.Phone && 
                        <button onClick={() => {
                            if (regStep === RegStep.Details) stopCamera();
                            setRegStep(prev => prev - 1);
                        }} className="absolute top-0 left-0 text-gray-500 hover:text-gray-800">&larr; <span>{t('back_btn')}</span></button>
                    }
                    <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{t('shopkeeper_registration')}</h2>
                </div>

                {regStep === RegStep.Phone && (
                    <div className="pt-6">
                        <p className="text-center text-sm text-gray-600 mb-4">{t('reg_step1_prompt')}</p>
                        <div className="space-y-4">
                            <input type="tel" value={registrationData.phone || ''} onChange={e => setRegistrationData({...registrationData, phone: e.target.value})} className="w-full p-3 border rounded-md" placeholder={t('phone_placeholder')} required aria-required="true" />
                            <button onClick={handleRegisterSendOtp} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{t('send_otp_btn')}</button>
                        </div>
                    </div>
                )}
                
                {regStep === RegStep.Otp && (
                     <div className="pt-6">
                        <p className="text-center text-sm text-gray-600 mb-4">
                            <span>{t('otp_sent_to')} </span>
                            <span className="font-bold">{registrationData.phone}</span>.
                        </p>
                        <div className="space-y-4">
                            <input type="text" value={registrationData.otp || ''} onChange={e => setRegistrationData({...registrationData, otp: e.target.value})} className="w-full p-3 border rounded-md text-center tracking-[0.5em]" placeholder={t('otp_placeholder_6')} required aria-required="true"/>
                            <button onClick={handleRegisterVerifyOtp} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{t('verify_otp_btn')}</button>
                        </div>
                    </div>
                )}
                
                {regStep === RegStep.Preference && (
                    <div className="pt-6 space-y-4">
                        <button onClick={() => { setRegistrationData({...registrationData, preference: 'supply_grid'}); setRegStep(RegStep.Location); }} className="w-full text-left p-4 border rounded-lg hover:bg-gray-50 flex items-center space-x-4">
                            <div>📦</div>
                            <div>
                                <p className="font-bold">{t('supply_grid_title')}</p>
                                <p className="text-sm text-gray-500">{t('supply_grid_desc')}</p>
                            </div>
                        </button>
                        <button onClick={() => { setRegistrationData({...registrationData, preference: 'farmfura_outlet'}); setRegStep(RegStep.Location); }} className="w-full text-left p-4 border rounded-lg hover:bg-gray-50 flex items-center space-x-4">
                            <div>🛒</div>
                            <div>
                                <p className="font-bold">{t('farmfura_outlet_title')}</p>
                                <p className="text-sm text-gray-500">{t('farmfura_outlet_desc')}</p>
                            </div>
                        </button>
                    </div>
                )}
                
                {regStep === RegStep.Location && (
                    <div className="pt-6">
                        <div className="space-y-2 max-h-60 overflow-y-auto">
                            {locations.map(loc => (
                                <div key={loc.name} onClick={() => { setRegistrationData({...registrationData, shopName: loc.name}); setRegStep(RegStep.Details); }} className="location-item p-3 border rounded-lg cursor-pointer hover:bg-gray-100" role="button" tabIndex={0}>
                                    <p className="font-semibold">{loc.name}</p>
                                    <p className="text-sm text-gray-500">{loc.location}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {regStep === RegStep.Details && (
                    <div className="pt-6">
                        <div className="space-y-4">
                            <input type="text" value={registrationData.aadhaarName || ''} onChange={e => setRegistrationData({...registrationData, aadhaarName: e.target.value})} className="w-full p-3 border rounded-md" placeholder={t('name_as_per_aadhaar')} required />
                            <input type="tel" value={registrationData.phone || ''} className="w-full p-3 border bg-gray-100 rounded-md" placeholder="Phone Number" readOnly />
                            <div role="radiogroup" aria-labelledby="gender-label">
                                <label id="gender-label" className="text-sm font-medium text-gray-700">{t('gender')}</label>
                                <div className="flex items-center space-x-4 mt-1">
                                    {(['male', 'female', 'other'] as const).map(g => (
                                        <label key={g} className="flex items-center">
                                            <input type="radio" name="gender" value={g} checked={registrationData.gender === g} onChange={e => setRegistrationData({...registrationData, gender: e.target.value})} className="mr-2" />
                                            <span>{t(g)}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                            <div role="radiogroup" aria-labelledby="work-type-label">
                                <label id="work-type-label" className="text-sm font-medium text-gray-700">{t('work_type')}</label>
                                <div className="flex items-center space-x-4 mt-1">
                                    {(['part-time', 'full-time'] as const).map(wt => (
                                        <label key={wt} className="flex items-center">
                                            <input type="radio" name="work_type" value={wt} checked={registrationData.workType === wt} onChange={e => setRegistrationData({...registrationData, workType: e.target.value})} className="mr-2" />
                                            <span>{t(wt.replace('-', '_') as any)}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                            
                             <div>
                                <label htmlFor="register-aadhaar-file" className="text-sm font-medium text-gray-700">{t('upload_aadhaar')}</label>
                                <div className="flex items-center space-x-2">
                                    <input type="file" onChange={e => handleFileChange(e, 'aadhaarFile', 'aadhaarPreview')} id="register-aadhaar-file" className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100" accept="image/*,.pdf"/>
                                    <div className="file-preview w-20 h-12 bg-gray-200 rounded-md flex items-center justify-center text-xs text-gray-500 bg-cover bg-center" style={{backgroundImage: `url(${registrationData.aadhaarPreview || ''})`}}>
                                        {!registrationData.aadhaarPreview && "Preview"}
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <label htmlFor="register-pan-file" className="text-sm font-medium text-gray-700">{t('upload_pan')}</label>
                                <div className="flex items-center space-x-2">
                                    <input type="file" onChange={e => handleFileChange(e, 'panFile', 'panPreview')} id="register-pan-file" className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100" accept="image/*,.pdf"/>
                                     <div className="file-preview w-20 h-12 bg-gray-200 rounded-md flex items-center justify-center text-xs text-gray-500 bg-cover bg-center" style={{backgroundImage: `url(${registrationData.panPreview || ''})`}}>
                                        {!registrationData.panPreview && "Preview"}
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <label className="text-sm font-medium text-gray-700">{t('live_photo')}</label>
                                <div className="mt-1 bg-gray-200 rounded-md flex items-center justify-center h-48 relative">
                                    <video ref={videoRef} className="w-full h-full rounded-md object-cover" autoPlay playsInline style={{ display: registrationData.livePhoto ? 'none' : 'block' }}></video>
                                    <canvas ref={canvasRef} className="hidden"></canvas>
                                    {registrationData.livePhoto && <img src={registrationData.livePhoto} className="w-full h-full rounded-md object-cover" alt="Live photo preview" />}
                                    {cameraPermissionError && <div className="text-gray-500 text-center p-4">
                                        <p>{t('allow_camera_access')}</p>
                                        <button type="button" onClick={() => startCamera({ video: { facingMode: 'user' }})} className="mt-2 bg-yellow-500 text-white text-sm font-bold py-2 px-3 rounded-md hover:bg-yellow-600">{t('retry_camera')}</button>
                                    </div>}
                                </div>
                                <button type="button" onClick={() => {
                                    if(registrationData.livePhoto) {
                                        setRegistrationData({...registrationData, livePhoto: null});
                                        startCamera({ video: { facingMode: 'user' }});
                                    } else {
                                        handlePhotoCapture();
                                    }
                                }} className="w-full mt-2 bg-blue-500 text-white text-sm font-bold py-2 px-3 rounded-md hover:bg-blue-600">
                                    {registrationData.livePhoto ? t('retake_photo_btn') : t('capture_photo_btn')}
                                </button>
                            </div>
                            <button onClick={handleCompleteRegistration} type="button" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{t('register_btn')}</button>
                        </div>
                    </div>
                )}

                <p className="text-center text-sm text-gray-600 mt-4">
                    <span>{t('has_account')} </span>
                    <a href="#" onClick={(e) => { e.preventDefault(); setView(AuthView.Login); setRegStep(RegStep.Phone); stopCamera(); }} className="font-semibold text-green-600 hover:text-green-800">{t('login_link')}</a>
                </p>
            </div>
        )
    };
    
    useEffect(() => {
        if (view === AuthView.Register && regStep === RegStep.Details && !registrationData.livePhoto) {
            startCamera({ video: { facingMode: 'user' } });
        } else {
            stopCamera();
        }
    }, [view, regStep, registrationData.livePhoto]);
    
    useEffect(() => {
        if (view === AuthView.Onboarding) {
            startQrScanner();
        } else {
            stopQrCamera();
        }
    }, [view]);

    const renderStatus = () => (
        <div className="w-full max-w-sm">
            <div className="bg-white p-8 shadow-lg rounded-lg text-center">
                <div className={`p-4 rounded-md ${
                    statusInfo.type === 'Pending' ? 'bg-yellow-100 text-yellow-800' : 
                    statusInfo.type === 'Rejected' ? 'bg-red-100 text-red-800' : 'bg-orange-100 text-orange-800'
                }`}>
                    <p>{statusInfo.message}</p>
                    {statusInfo.type === 'Rejected' && (
                        <button onClick={() => {
                            let employees = getEmployees();
                            employees = employees.filter(emp => emp.phone !== statusInfo.phone);
                            saveEmployees(employees);
                            setView(AuthView.Register);
                            setRegStep(RegStep.Phone);
                        }} className="mt-4 w-full bg-blue-600 text-white font-bold py-2 rounded-md hover:bg-blue-700">{t('register_again')}</button>
                    )}
                </div>
                 <button onClick={() => { setView(AuthView.Login); setRegStep(RegStep.Phone); }} className="mt-4 text-sm text-blue-600 hover:underline">{t('back_btn')}</button>
            </div>
        </div>
    );
    
    const renderOnboarding = () => {
        const shopDetails = (getOutlets()).concat(getSupplyGrids()).find(s => s.name === tempUser?.shopName);
      
        return (
            <div className="w-full max-w-sm">
                <div className="bg-white p-8 shadow-lg rounded-lg text-center">
                     <h3 className="text-xl font-bold text-gray-800 mb-4">{t('onboarding_title')}</h3>
                     <div className="bg-green-50 border-l-4 border-green-500 text-green-800 p-4 rounded-r-lg text-left mb-4">
                         <p className="mb-2">{t('visit_store_message')}</p>
                         <div className="font-semibold">
                             <p>{tempUser?.shopName}</p>
                             <p className="text-sm">{shopDetails?.location}</p>
                         </div>
                     </div>
                     <div className="mt-2">
                         <p className="text-gray-600 mb-4 text-sm">{t('scan_qr_prompt')}</p>
                         <div className="relative w-full aspect-square bg-gray-800 rounded-lg overflow-hidden flex items-center justify-center cursor-pointer mb-4" onClick={handleQrScanClick} role="button" aria-label={t('click_to_scan')}>
                             <video ref={qrVideoRef} className="w-full h-full object-cover" autoPlay playsInline></video>
                             {qrCameraPermissionError && <div className="text-white text-center p-4">
                                <p>{t('allow_camera_access_qr')}</p>
                                <button type="button" onClick={startQrScanner} className="mt-2 bg-yellow-500 text-white text-sm font-bold py-2 px-3 rounded-md hover:bg-yellow-600">{t('retry_camera')}</button>
                             </div>}
                            <div className="absolute inset-0 flex items-center justify-center text-white opacity-50 text-sm">{t('click_to_scan')}</div>
                         </div>
                     </div>
                </div>
            </div>
        );
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            <header className="bg-white shadow-sm">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between items-center py-4">
                        <div className="text-3xl font-bold text-green-700 italic">🌱 Farmfura</div>
                        <div className="flex items-center space-x-4">
                            <LanguageSwitcher />
                            <a href="#" className="font-semibold text-gray-600 hover:text-green-700">{t('back_to_portal')}</a>
                        </div>
                    </div>
                </div>
            </header>
            <main className="flex-grow flex items-center justify-center p-4">
                <div className="w-full max-w-sm">
                    {view === AuthView.Login && renderLogin()}
                    {view === AuthView.Register && renderRegister()}
                    {view === AuthView.Status && renderStatus()}
                    {view === AuthView.Onboarding && renderOnboarding()}
                </div>
            </main>
        </div>
    );
};