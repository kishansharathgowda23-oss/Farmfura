
import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useToast } from '../../contexts/ToastContext';
import * as api from '../../services/mockApi';
import { Employee } from '../../types';
import CameraCapture from './CameraCapture';

interface RegisterFormViewProps {
  phone: string;
  onBack: () => void;
  onComplete: () => void;
}

const RegisterFormView: React.FC<RegisterFormViewProps> = ({ phone, onBack, onComplete }) => {
  const { t } = useLanguage();
  const { showToast } = useToast();
  const [fullName, setFullName] = useState('');
  const [vehicleType, setVehicleType] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [files, setFiles] = useState<{ aadhaar?: File, pan?: File, dl?: File }>({});

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, files: fileList } = e.target;
    if (fileList && fileList.length > 0) {
      setFiles(prev => ({ ...prev, [id]: fileList[0] }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!capturedPhoto) {
      showToast('Please capture your photo.');
      return;
    }
    if (!files.aadhaar || !files.pan || !files.dl) {
      showToast('Please upload all required documents.');
      return;
    }

    const newEmployeeData: Omit<Employee, 'id'> = {
      name: fullName,
      phone: phone,
      role: '4x4_carrier',
      status: 'Pending Approval',
      applicationDate: new Date().toISOString().split('T')[0],
      vehicleType: vehicleType,
      vehicleNumber: vehicleNumber,
      photoBase64: capturedPhoto,
      documents: {
        aadhaar: files.aadhaar.name,
        pan: files.pan.name,
        dl: files.dl.name
      }
    };

    api.addEmployee(newEmployeeData);
    showToast('Application submitted! You will be notified on approval.');
    onComplete();
  };

  return (
    <div className="bg-white p-8 shadow-lg rounded-lg max-w-lg mx-auto">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{t('register_step_3')}</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium">{t('full_name')}</label>
          <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} className="w-full p-2 border rounded-md" required />
        </div>
        <div>
          <label className="block text-sm font-medium">{t('phone_placeholder')}</label>
          <input type="tel" value={phone} className="w-full p-2 border rounded-md bg-gray-100" required readOnly />
        </div>
        <div>
          <label className="block text-sm font-medium">{t('vehicle_type')}</label>
          <input type="text" value={vehicleType} onChange={e => setVehicleType(e.target.value)} className="w-full p-2 border rounded-md" placeholder={t('vehicle_type_placeholder')} required />
        </div>
        <div>
          <label className="block text-sm font-medium">{t('vehicle_number')}</label>
          <input type="text" value={vehicleNumber} onChange={e => setVehicleNumber(e.target.value)} className="w-full p-2 border rounded-md" placeholder={t('vehicle_number_placeholder')} required />
        </div>

        <h3 className="text-lg font-semibold pt-4 border-t mt-4">{t('live_photo')}</h3>
        <CameraCapture onCapture={setCapturedPhoto} />

        <h3 className="text-lg font-semibold pt-4 border-t mt-4">{t('document_upload')}</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium">{t('aadhaar_card')}</label>
            <input type="file" id="aadhaar" onChange={handleFileChange} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" accept=".pdf" required />
          </div>
          <div>
            <label className="block text-sm font-medium">{t('pan_card')}</label>
            <input type="file" id="pan" onChange={handleFileChange} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" accept=".pdf" required />
          </div>
          <div>
            <label className="block text-sm font-medium">{t('driving_licence')}</label>
            <input type="file" id="dl" onChange={handleFileChange} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" accept=".pdf" required />
          </div>
        </div>

        <div className="flex justify-end space-x-3 pt-4">
          <button type="button" onClick={onBack} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-md">{t('back')}</button>
          <button type="submit" className="bg-green-600 text-white font-bold py-2 px-4 rounded-md">{t('submit_application')}</button>
        </div>
      </form>
    </div>
  );
};

export default RegisterFormView;
