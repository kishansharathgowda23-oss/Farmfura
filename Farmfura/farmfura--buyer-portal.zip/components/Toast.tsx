
import React, { useEffect, useState } from 'react';

interface ToastProps {
    message: string;
    isError?: boolean;
}

const Toast: React.FC<ToastProps> = ({ message, isError = false }) => {
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        if (message) {
            setVisible(true);
            const timer = setTimeout(() => {
                setVisible(false);
            }, 2700); // A bit shorter than the timeout in App.tsx to allow for fade-out
            return () => clearTimeout(timer);
        }
    }, [message]);

    if (!message) return null;

    return (
        <div 
            className={`fixed bottom-20 left-1/2 -translate-x-1/2 p-4 rounded-lg shadow-xl text-white transition-opacity duration-300 z-[101] ${isError ? 'bg-red-600' : 'bg-green-600'} ${visible ? 'opacity-100' : 'opacity-0'}`}
        >
            {message}
        </div>
    );
};

export default Toast;
