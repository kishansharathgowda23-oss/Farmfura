
import React, { useState } from 'react';
import { Product } from '../types';

interface ProductCardProps {
    product: Product;
    onAddToCart: (product: Product, quantity: number) => void;
    translations: Record<string, string>;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, translations }) => {
    const isSpecialUnit = ['bundle', 'piece', 'pack'].includes(product.unit);
    const quantityStep = isSpecialUnit ? 1 : 0.25;
    const minQuantity = isSpecialUnit ? 1 : 0.25;

    const [quantity, setQuantity] = useState<number | string>(minQuantity);

    const handleAddToCart = () => {
        const numQuantity = Number(quantity);
        if (!isNaN(numQuantity) && numQuantity >= minQuantity) {
            onAddToCart(product, numQuantity);
        }
    };
    
    const productName = product.names[translations.lang_code as keyof typeof product.names] || product.name;
    const unitText = translations[`unit_${product.unit}`] || product.unit;
    const stockStatusText = product.inStock ? translations.in_stock : translations.out_of_stock;
    const stockStatusColor = product.inStock ? 'text-green-500' : 'text-red-500';

    return (
        <div className={`bg-white rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300 relative ${!product.inStock ? 'opacity-60 pointer-events-none' : ''}`}>
            {!product.inStock && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white/80 px-4 py-2 rounded-lg text-red-500 font-bold text-lg z-10 whitespace-nowrap">
                    {translations.out_of_stock}
                </div>
            )}
            <div className="relative">
                <img src={product.image} alt={product.name} className="w-full h-32 object-cover" onError={(e) => { e.currentTarget.src = 'https://picsum.photos/400/300'; }} />
                <span className={`absolute top-2 right-2 bg-white px-2 py-1 rounded-full text-xs font-semibold ${stockStatusColor}`}>
                    {stockStatusText}
                </span>
            </div>
            <div className="p-4">
                <h3 className="text-md font-semibold text-gray-800 h-12">{productName}</h3>
                <div className="mt-2 mb-4">
                    <span className="text-xl font-bold text-green-700">₹{product.price}/{unitText}</span>
                </div>
                <div className="flex items-center border border-gray-300 rounded-md">
                    <input 
                        type="number" 
                        min={minQuantity} 
                        step={quantityStep} 
                        value={quantity}
                        onChange={(e) => setQuantity(e.target.value)}
                        className="w-16 text-center p-1 border-r border-gray-300 focus:outline-none"
                        disabled={!product.inStock}
                    />
                    <button 
                        onClick={handleAddToCart}
                        className="flex-grow bg-green-100 text-green-800 text-sm font-bold py-1 px-2 hover:bg-green-200"
                        disabled={!product.inStock}
                    >
                        {translations.add_to_cart_btn}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ProductCard;
