
import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import LanguageSwitcher from '../shared/LanguageSwitcher';
import LoginView from './LoginView';
import RegisterPhoneView from './RegisterPhoneView';
import RegisterOtpView from './RegisterOtpView';
import RegisterFormView from './RegisterFormView';

type AuthStep = 'login' | 'regPhone' | 'regOtp' | 'regForm';

const AuthScreen: React.FC = () => {
  const [step, setStep] = useState<AuthStep>('login');
  const [registrationData, setRegistrationData] = useState<{ phone?: string }>({});

  const { t } = useLanguage();

  const handleGoToRegister = () => {
    setRegistrationData({});
    setStep('regPhone');
  };
  
  const handlePhoneSubmitted = (phone: string) => {
    setRegistrationData({ phone });
    setStep('regOtp');
  };
  
  const handleOtpVerified = () => {
    setStep('regForm');
  };
  
  const handleRegistrationComplete = () => {
    setRegistrationData({});
    setStep('login');
  };

  const renderStep = () => {
    switch (step) {
      case 'login':
        return <LoginView onGoToRegister={handleGoToRegister} />;
      case 'regPhone':
        return <RegisterPhoneView onPhoneSubmitted={handlePhoneSubmitted} onCancel={() => setStep('login')} />;
      case 'regOtp':
        return <RegisterOtpView phone={registrationData.phone || ''} onOtpVerified={handleOtpVerified} onBack={() => setStep('regPhone')} />;
      case 'regForm':
        return <RegisterFormView phone={registrationData.phone || ''} onBack={() => setStep('regOtp')} onComplete={handleRegistrationComplete} />;
      default:
        return <LoginView onGoToRegister={handleGoToRegister} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="text-3xl font-bold text-green-700 italic">🌱 Farmfura</div>
            <div className="flex items-center space-x-4">
              <LanguageSwitcher />
            </div>
          </div>
        </div>
      </header>
      <main className="flex-grow flex items-center justify-center p-4">
        <div className="w-full max-w-sm">
          {renderStep()}
        </div>
      </main>
    </div>
  );
};

export default AuthScreen;
