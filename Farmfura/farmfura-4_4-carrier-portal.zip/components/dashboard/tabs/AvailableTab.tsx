import React, { useState, useEffect } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import { useLanguage } from '../../../contexts/LanguageContext';
import { useToast } from '../../../contexts/ToastContext';
import * as api from '../../../services/mockApi';
import { PickupJob } from '../../../types';

// Modal Management
type ModalType = 'cancel' | 'report' | 'rate' | null;

const AvailableTab: React.FC = () => {
  const { currentUser } = useAuth();
  const [jobs, setJobs] = useState<PickupJob[]>([]);
  const [modal, setModal] = useState<{ type: ModalType, job: PickupJob | null }>({ type: null, job: null });

  const refreshJobs = () => {
    setJobs(api.getPickupRequests());
  };

  useEffect(() => {
    refreshJobs();
  }, []);
  
  const handleModalClose = () => setModal({ type: null, job: null });

  const myActiveJobs = jobs.filter(p => p.carrierId === currentUser?.id && (p.status === 'in_progress' || p.status === 'picked_up'));
  const availableJobs = jobs.filter(p => p.status === 'pending');

  return (
    <div>
      {myActiveJobs.length > 0 && <ActiveJobsSection jobs={myActiveJobs} onUpdate={refreshJobs} openModal={(type, job) => setModal({ type, job })} />}
      <AvailableJobsList jobs={availableJobs} activeJobCount={myActiveJobs.length} onUpdate={refreshJobs} />
      
      {/* Modals */}
      {modal.type === 'cancel' && modal.job && <CancelJobModal job={modal.job} onClose={handleModalClose} onUpdate={refreshJobs} />}
      {modal.type === 'report' && modal.job && <ReportIssueModal job={modal.job} onClose={handleModalClose} onUpdate={refreshJobs} />}
      {modal.type === 'rate' && modal.job && <RateJobModal job={modal.job} onClose={handleModalClose} />}
    </div>
  );
};

const ActiveJobsSection: React.FC<{ jobs: PickupJob[], onUpdate: () => void, openModal: (type: ModalType, job: PickupJob) => void }> = ({ jobs, onUpdate, openModal }) => {
    const { t } = useLanguage();
    return (
        <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">{jobs.length > 1 ? t('my_active_jobs') : t('my_active_job')}</h2>
            <div className="space-y-4">
                {jobs.map(job => <ActiveJobCard key={job.id} job={job} onUpdate={onUpdate} openModal={openModal} />)}
            </div>
        </div>
    );
};

const ActiveJobCard: React.FC<{ job: PickupJob, onUpdate: () => void, openModal: (type: ModalType, job: PickupJob) => void }> = ({ job, onUpdate, openModal }) => {
  const { t } = useLanguage();
  const { showToast } = useToast();
  
  const isPickedUp = job.status === 'picked_up';
  const locationUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(isPickedUp ? job.destinationShop : job.location)}`;

  const handleUpdateStatus = (status: 'picked_up' | 'delivered') => {
      if (status === 'delivered') {
          const completed = api.completeJob(job.id);
          if (completed) {
            showToast(`Job Completed! Payout added to balance.`);
            onUpdate();
            openModal('rate', completed);
          }
      } else {
        const updatedJob = api.updatePickupRequest(job.id, { status });
        if (updatedJob) {
          showToast('Status updated: Picked Up!');
          onUpdate();
        }
      }
  };

  return (
    <div className="bg-white rounded-lg shadow p-4 border-l-4 border-blue-500">
      <JobDetails job={job} />
      <div className="mt-4 p-3 bg-gray-50 rounded-md">
        <p className="font-semibold text-sm">Next Step:</p>
        {!isPickedUp ? (
          <>
            <p className="text-gray-700">Drive to <strong className="text-blue-600">{job.location}</strong> to pick up the items.</p>
            <a href={locationUrl} target="_blank" rel="noopener noreferrer" className="block w-full text-center bg-blue-600 text-white font-bold py-2 px-4 rounded-md mt-3 hover:bg-blue-700">{t('open_pickup_nav')}</a>
            <button onClick={() => handleUpdateStatus('picked_up')} className="w-full bg-yellow-500 text-white font-bold py-2 px-4 rounded-md mt-3 hover:bg-yellow-600">{t('mark_picked_up')}</button>
          </>
        ) : (
          <>
            <p className="text-gray-700">Drive to <strong className="text-blue-600">{job.destinationShop}</strong> to deliver the items.</p>
            <a href={locationUrl} target="_blank" rel="noopener noreferrer" className="block w-full text-center bg-blue-600 text-white font-bold py-2 px-4 rounded-md mt-3 hover:bg-blue-700">{t('open_delivery_nav')}</a>
            <button onClick={() => handleUpdateStatus('delivered')} className="w-full bg-green-600 text-white font-bold py-2 px-4 rounded-md mt-3 hover:bg-green-700">{t('mark_delivered')}</button>
          </>
        )}
      </div>
      <div className="flex justify-end space-x-2 mt-3">
          <button onClick={() => openModal('report', job)} className="text-xs text-gray-500 hover:text-gray-800 font-semibold">{t('report_issue')}</button>
          <button onClick={() => openModal('cancel', job)} className="text-xs text-red-500 hover:text-red-800 font-semibold">{t('cancel_job')}</button>
      </div>
    </div>
  );
};

const AvailableJobsList: React.FC<{ jobs: PickupJob[], activeJobCount: number, onUpdate: () => void }> = ({ jobs, activeJobCount, onUpdate }) => {
  const { t } = useLanguage();
  const { showToast } = useToast();
  const { currentUser } = useAuth();
  const MAX_JOBS = 2;
  
  const handleAcceptJob = (jobId: string) => {
    if (activeJobCount >= MAX_JOBS || !currentUser) return;
    
    const updatedJob = api.updatePickupRequest(jobId, { status: 'in_progress', carrierId: currentUser.id });
    
    if (updatedJob) {
        showToast('Job Accepted!');
        onUpdate();
    } else {
        showToast('Failed to accept job. It might no longer be available.');
        onUpdate();
    }
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">{t('available_pickups')}</h2>
      <div className="space-y-4">
        {jobs.length > 0 ? jobs.map(job => (
          <div key={job.id} className="bg-white rounded-lg shadow p-4 transition hover:shadow-md">
            <JobDetails job={job} />
            <button onClick={() => handleAcceptJob(job.id)} disabled={activeJobCount >= MAX_JOBS} className="w-full bg-green-600 text-white font-bold py-2 px-4 rounded-md mt-4 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed">
              {t('accept_job')}
            </button>
          </div>
        )) : (
          <div className="bg-white rounded-lg shadow p-6 text-center">
            <p className="text-gray-500">{t('no_pickups_available')}</p>
          </div>
        )}
        {activeJobCount >= MAX_JOBS && <p className="text-center text-sm font-semibold text-yellow-700 mt-4">{t('max_jobs_prompt')}</p>}
      </div>
    </div>
  );
};

const JobDetails: React.FC<{ job: PickupJob }> = ({ job }) => {
    const { t } = useLanguage();
    const distanceBonus = (job.distanceKms ?? 10) * 20;
    const totalPayout = job.payout + distanceBonus;

    return (
        <>
            <div className="flex justify-between items-start">
            <div>
                <h3 className="font-bold text-lg text-gray-900">{job.farmerName}</h3>
                <p className="text-sm text-gray-600">{job.location}</p>
            </div>
            <div className="text-right">
                <span className="text-xl font-bold text-green-600">₹{totalPayout}</span>
                {distanceBonus > 0 && <p className="text-xs text-green-600">+ ₹{distanceBonus} {t('distance_bonus')}</p>}
            </div>
            </div>
            <ul className="list-disc list-inside mt-2 text-sm text-gray-700">
            {job.items.map((item, index) => <li key={index}>{item.quantity} {item.unit} {item.name}</li>)}
            </ul>
            <p className="text-sm font-semibold mt-2">Destination: <span className="font-normal">{job.destinationShop}</span></p>
        </>
    );
};

// --- Modals ---

const ModalWrapper: React.FC<{ title: string, children: React.ReactNode, onClose: () => void }> = ({ title, children, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4" onClick={onClose}>
        <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <h3 className="text-xl font-bold text-gray-800">{title}</h3>
            <div className="my-4">{children}</div>
        </div>
    </div>
);

const CancelJobModal: React.FC<{ job: PickupJob, onClose: () => void, onUpdate: () => void }> = ({ job, onClose, onUpdate }) => {
    const { t } = useLanguage();
    const { showToast } = useToast();

    const handleConfirm = () => {
        // This function handles the logic after the user confirms the cancellation.
        
        // 1. Call the API to update the job status to 'pending' and clear the carrierId.
        api.cancelJob(job.id);
        
        // 2. Show a success message to the user.
        showToast(t('job_cancelled_success'));
        
        // 3. Refresh the job list in the UI to reflect the change.
        onUpdate();
        
        // 4. Close the confirmation dialog.
        onClose();
    };

    return (
        <ModalWrapper title={t('cancel_job_confirm_title')} onClose={onClose}>
            <p className="text-gray-700">{t('cancel_job_confirm_message')}</p>
            <div className="flex justify-end space-x-3 mt-4">
                <button onClick={onClose} className="bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-md hover:bg-gray-400">{t('back')}</button>
                <button onClick={handleConfirm} className="bg-red-600 text-white font-bold py-2 px-4 rounded-md hover:bg-red-700">{t('confirm')}</button>
            </div>
        </ModalWrapper>
    );
}

const ReportIssueModal: React.FC<{ job: PickupJob, onClose: () => void, onUpdate: () => void }> = ({ job, onClose, onUpdate }) => {
    const [description, setDescription] = useState('');
    const { t } = useLanguage();
    const { showToast } = useToast();

    const handleSubmit = () => {
        if (!description) {
            showToast("Please describe the issue.");
            return;
        }
        api.updatePickupRequest(job.id, { discrepancyReport: description });
        showToast("Issue reported successfully.");
        onUpdate();
        onClose();
    };

    return (
        <ModalWrapper title={t('report_issue_title')} onClose={onClose}>
            <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                className="w-full p-2 border rounded-md h-32"
                placeholder={t('issue_description_placeholder')}
            ></textarea>
            <div className="flex justify-end space-x-3 mt-4">
                <button onClick={onClose} className="bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-md hover:bg-gray-400">{t('cancel')}</button>
                <button onClick={handleSubmit} className="bg-blue-600 text-white font-bold py-2 px-4 rounded-md hover:bg-blue-700">{t('submit_report')}</button>
            </div>
        </ModalWrapper>
    );
};

const RateJobModal: React.FC<{ job: PickupJob, onClose: () => void }> = ({ job, onClose }) => {
    const [rating, setRating] = useState(0);
    const { t } = useLanguage();
    const { showToast } = useToast();

    const handleSubmit = () => {
        if (rating === 0) {
            showToast("Please select a rating.");
            return;
        }
        api.rateCompletedJob(job.id, rating);
        showToast("Thank you for your feedback!");
        onClose();
    };

    return (
        <ModalWrapper title={t('rate_pickup')} onClose={onClose}>
            <div className="flex justify-center items-center text-4xl text-gray-300">
                {[1, 2, 3, 4, 5].map(star => (
                    <button key={star} onClick={() => setRating(star)} className={`transition-colors ${rating >= star ? 'text-yellow-400' : ''}`}>
                        ★
                    </button>
                ))}
            </div>
            <div className="flex justify-end mt-6">
                <button onClick={handleSubmit} className="bg-green-600 text-white font-bold py-2 px-4 rounded-md hover:bg-green-700">{t('submit_rating')}</button>
            </div>
        </ModalWrapper>
    );
};

export default AvailableTab;