
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { Product } from '../types';
import { Modal } from './Common';

interface ProductCardProps {
    product: Product;
    onAddQuantity: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddQuantity }) => {
    const { appMode, t } = useAppContext();
    const navigate = useNavigate();
    const [isPriceModalOpen, setPriceModalOpen] = useState(false);
    
    const isSellMode = appMode === 'sell';
    const price = isSellMode ? (product.sellPrice ?? product.farmerPrice ?? 0) : (product.buyPrice ?? 0);
    const productName = product.names[t('language')] || product.name;

    return (
        <div className="bg-white p-4 rounded-lg shadow-sm flex flex-col justify-between transition-shadow hover:shadow-lg">
            <div>
                <img src={product.image} alt={product.name} className="w-full h-32 object-cover rounded-md mb-4" onError={(e) => (e.currentTarget.src = 'https://picsum.photos/200/150')} />
                <h3 className="font-bold text-gray-800 truncate">{product.name}</h3>
                <p className="text-sm text-gray-500 truncate">{productName}</p>
                <p className="text-sm font-medium text-gray-500 mt-1">{t(isSellMode ? 'sell_price' : 'buy_price')}:</p>
                <p className={`font-semibold ${isSellMode ? 'text-green-700' : 'text-blue-700'} text-lg`}>
                    ₹{price.toFixed(2)} / {t(`unit_${product.unit}`)}
                </p>
            </div>
            <div className={`mt-4 grid gap-2 ${isSellMode ? 'grid-cols-2' : 'grid-cols-1'}`}>
                <button
                    onClick={() => isSellMode ? onAddQuantity(product) : navigate(`/purchase/${product.id}`)}
                    className={`text-sm text-white py-2 rounded-md transition ${isSellMode ? 'bg-green-500 hover:bg-green-600' : 'bg-blue-500 hover:bg-blue-600'}`}
                >
                    {t(isSellMode ? 'add_quantity_btn' : 'buy_now_btn')}
                </button>
                {isSellMode && (
                    <button onClick={() => setPriceModalOpen(true)} className="text-sm bg-gray-200 text-gray-700 py-2 rounded-md hover:bg-gray-300">
                        {t('request_price_change')}
                    </button>
                )}
            </div>
            <PriceRequestModal isOpen={isPriceModalOpen} onClose={() => setPriceModalOpen(false)} product={product} />
        </div>
    );
};


interface PriceRequestModalProps {
    isOpen: boolean;
    onClose: () => void;
    product: Product | null;
}

const PriceRequestModal: React.FC<PriceRequestModalProps> = ({ isOpen, onClose, product }) => {
    const { t, showToast } = useAppContext();
    
    if (!product) return null;

    const price = product.sellPrice ?? product.farmerPrice ?? 0;
    const suggestedPrice = price * (1 + (Math.random() * 0.2 - 0.1));

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const newPrice = parseFloat(e.currentTarget.newPrice.value);
        if (newPrice > price) {
            showToast(t('request_sent', { productName: product.names[t('language')] || product.name }));
            onClose();
        } else {
            showToast(t('invalid_price'));
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose}>
            <h2 className="text-2xl font-bold mb-4">{t('request_price_change')}</h2>
            <p className="mb-4 text-gray-600">{product.names[t('language')] || product.name}</p>
            <div className="mb-4 bg-green-50 p-3 rounded-lg text-center">
                <label className="block text-sm font-bold mb-1 text-green-800">Suggested Market Price</label>
                <p className="text-lg font-semibold text-green-700">≈ ₹{suggestedPrice.toFixed(2)}</p>
            </div>
            <form onSubmit={handleSubmit}>
                <div className="mb-4">
                    <label className="block text-sm font-bold mb-2">{t('current_price')}</label>
                    <p className="text-lg font-semibold">₹{price.toFixed(2)}</p>
                </div>
                <div className="mb-6">
                    <label htmlFor="new-price" className="block text-sm font-bold mb-2">{t('new_requested_price')}</label>
                    <input type="number" name="newPrice" min={(price + 0.01).toFixed(2)} step="0.01" className="border rounded-md w-full py-3 px-4" required />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <button type="button" onClick={onClose} className="w-full bg-gray-200 py-3 rounded-md">{t('cancel')}</button>
                    <button type="submit" className="w-full bg-green-600 text-white py-3 rounded-md">{t('submit_request')}</button>
                </div>
            </form>
        </Modal>
    );
};


export default ProductCard;
