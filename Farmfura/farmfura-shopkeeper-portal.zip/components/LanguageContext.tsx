
import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';
import { getTranslator, translations } from '../services/translationService';
import type { translations as TTranslations } from '../services/translationService';

type Language = keyof typeof translations;
type Translator = (key: keyof typeof TTranslations['en'], params?: Record<string, string | number>) => string;

interface LanguageContextType {
    lang: Language;
    setLang: (lang: Language) => void;
    t: Translator;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [lang, setLangState] = useState<Language>(() => {
        return (localStorage.getItem('farmfura_preferred_lang') as Language) || 'en';
    });

    const setLang = (newLang: Language) => {
        localStorage.setItem('farmfura_preferred_lang', newLang);
        setLangState(newLang);
    };
    
    useEffect(() => {
        const portalTitleKey: keyof typeof translations.en = 'portal_title';
        document.title = getTranslator(lang)(portalTitleKey);
    }, [lang]);

    const t = useCallback(getTranslator(lang), [lang]);

    return (
        <LanguageContext.Provider value={{ lang, setLang, t }}>
            {children}
        </LanguageContext.Provider>
    );
};

export const useLanguage = (): LanguageContextType => {
    const context = useContext(LanguageContext);
    if (!context) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
};
