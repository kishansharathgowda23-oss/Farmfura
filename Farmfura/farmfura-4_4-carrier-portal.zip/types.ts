export interface Employee {
  id: string;
  name: string;
  phone: string;
  role: '4x4_carrier';
  status: 'Active' | 'Pending Approval' | 'Inactive';
  vehicleType: string | null;
  vehicleNumber: string | null;
  applicationDate?: string;
  photoBase64?: string;
  documents?: {
    aadhaar: string;
    pan: string;
    dl: string;
  };
  withdrawableBalance?: number;
}

export interface PickupJob {
  id: string;
  farmerName: string;
  location: string;
  destinationShop: string;
  items: { name: string; quantity: number; unit: string }[];
  payout: number;
  status: 'pending' | 'in_progress' | 'picked_up' | 'delivered';
  carrierId: string | null;
  completedAt?: string;
  distanceKms?: number;
  discrepancyReport?: string;
  carrierRating?: number;
}

export interface BankDetails {
  accountNumber: string;
  ifsc: string;
  branchName: string;
  bankName: string;
}

export interface Withdrawal {
  id: string;
  amount: number;
  type: 'Instant' | 'Standard';
  date: string;
  status: 'Completed';
}
