
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import Auth from './components/Auth';
import MainApp from './components/MainApp';
import Toast from './components/Toast';
import { User } from './types';
import { api } from './services/api';
import { translations } from './constants';

export const AuthContext = React.createContext<{
  currentUser: User | null;
  login: (user: User) => void;
  logout: () => void;
  updateUser: (user: User) => void;
}>({
  currentUser: null,
  login: () => {},
  logout: () => {},
  updateUser: () => {},
});

export const LanguageContext = React.createContext<{
  language: string;
  setLanguage: (lang: string) => void;
  translate: (key: string, params?: Record<string, string | number>) => string;
}>({
  language: 'en',
  setLanguage: () => {},
  translate: (key: string) => key,
});

export const ToastContext = React.createContext<(message: string, isError?: boolean) => void>(() => {});

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [language, setLanguageState] = useState<string>(localStorage.getItem('farmfura_carrier_preferred_lang') || 'en');
  const [toast, setToast] = useState<{ message: string; isError: boolean; id: number } | null>(null);

  useEffect(() => {
    api.initializeData();
  }, []);

  const login = useCallback((user: User) => {
    setCurrentUser(user);
    localStorage.setItem('farmfura_carrier_session', JSON.stringify(user));
  }, []);

  const logout = useCallback(() => {
    setCurrentUser(null);
    localStorage.removeItem('farmfura_carrier_session');
  }, []);
  
  const updateUser = useCallback((user: User) => {
    setCurrentUser(user);
    localStorage.setItem('farmfura_carrier_session', JSON.stringify(user));
  }, []);

  useEffect(() => {
    const savedUser = localStorage.getItem('farmfura_carrier_session');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  const setLanguage = useCallback((lang: string) => {
    setLanguageState(lang);
    localStorage.setItem('farmfura_carrier_preferred_lang', lang);
  }, []);

  const translate = useCallback((key: string, params: Record<string, string | number> = {}) => {
    let text = translations[language as keyof typeof translations]?.[key as any] || translations['en'][key as any] || `[${key}]`;
    for (const param in params) {
      text = text.replace(`{${param}}`, String(params[param]));
    }
    return text;
  }, [language]);

  const showToast = useCallback((message: string, isError: boolean = false) => {
    setToast({ message, isError, id: Date.now() });
    setTimeout(() => setToast(null), 3000);
  }, []);
  
  const authContextValue = useMemo(() => ({ currentUser, login, logout, updateUser }), [currentUser, login, logout, updateUser]);
  const languageContextValue = useMemo(() => ({ language, setLanguage, translate }), [language, setLanguage, translate]);

  return (
    <AuthContext.Provider value={authContextValue}>
      <LanguageContext.Provider value={languageContextValue}>
        <ToastContext.Provider value={showToast}>
          {currentUser ? <MainApp /> : <Auth />}
          {toast && <Toast message={toast.message} isError={toast.isError} onClose={() => setToast(null)} />}
        </ToastContext.Provider>
      </LanguageContext.Provider>
    </AuthContext.Provider>
  );
};

export default App;
