import React, { useState, useContext, useMemo, useEffect } from 'react';
import { AuthContext, LanguageContext, ToastContext } from '../App';
import { api } from '../services/api';
import { Job } from '../types';
import Modal from './Modal';

const ProfileTab: React.FC = () => {
    const { currentUser, updateUser } = useContext(AuthContext);
    const { translate } = useContext(LanguageContext);
    const showToast = useContext(ToastContext);
    
    const [view, setView] = useState<'main' | 'bank'>('main');
    const [isWithdrawModalOpen, setWithdrawModalOpen] = useState(false);
    const [completedJobs, setCompletedJobs] = useState<Job[]>([]);

    useEffect(() => {
        if (currentUser) {
            setCompletedJobs(api.getCompletedJobs(currentUser.id));
        }
    }, [currentUser]);

    const totalEarnings = useMemo(() => {
        return completedJobs.reduce((sum, job) => sum + job.payout, 0);
    }, [completedJobs]);

    const [bankDetails, setBankDetails] = useState({
        accountNumber: currentUser?.bankDetails?.accountNumber || '',
        ifsc: currentUser?.bankDetails?.ifsc || '',
        branch: currentUser?.bankDetails?.branch || '',
        bank: currentUser?.bankDetails?.bank || '',
    });

    const handleBankDetailsSave = () => {
        if (!bankDetails.accountNumber || !bankDetails.ifsc) {
            showToast(translate('bank_account_number') + " and " + translate('ifsc_code') + " are required.", true);
            return;
        }
        const updatedUser = { ...currentUser!, bankDetails };
        api.updateEmployee(updatedUser);
        updateUser(updatedUser);
        showToast(translate('bank_details_saved'));
        setView('main');
    };

    const handleWithdrawClick = () => {
        if (!currentUser?.bankDetails?.accountNumber || !currentUser?.bankDetails?.ifsc) {
            showToast(translate('no_bank_details_prompt'), true);
            setView('bank');
            return;
        }
        setWithdrawModalOpen(true);
    };

    const confirmWithdrawal = () => {
        if (currentUser) {
            const updatedUser = api.withdrawFromWallet(currentUser.id);
            if (updatedUser) {
                updateUser(updatedUser);
                showToast(translate('withdrawal_success'));
            }
        }
        setWithdrawModalOpen(false);
    };

    if (view === 'bank') {
        return (
             <div>
                <div className="mb-4">
                    <button onClick={() => setView('main')} className="text-lg font-semibold text-gray-700 hover:text-gray-900 flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                        {translate('bank_details')}
                    </button>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                    <form className="space-y-4" onSubmit={e => {e.preventDefault(); handleBankDetailsSave();}}>
                        <div>
                            <label htmlFor="accountNumber" className="text-sm font-medium text-gray-700">{translate('bank_account_number')}</label>
                            <input id="accountNumber" type="text" value={bankDetails.accountNumber} onChange={e => setBankDetails({...bankDetails, accountNumber: e.target.value})} className="w-full mt-1 p-3 border rounded-md" required />
                        </div>
                        <div>
                            <label htmlFor="ifsc" className="text-sm font-medium text-gray-700">{translate('ifsc_code')}</label>
                            <input id="ifsc" type="text" value={bankDetails.ifsc} onChange={e => setBankDetails({...bankDetails, ifsc: e.target.value.toUpperCase()})} className="w-full mt-1 p-3 border rounded-md" required />
                        </div>
                        <div>
                            <label htmlFor="branch" className="text-sm font-medium text-gray-700">{translate('branch_name')}</label>
                            <input id="branch" type="text" value={bankDetails.branch} onChange={e => setBankDetails({...bankDetails, branch: e.target.value})} className="w-full mt-1 p-3 border rounded-md" />
                        </div>
                        <div>
                            <label htmlFor="bankName" className="text-sm font-medium text-gray-700">{translate('bank_name')}</label>
                            <input id="bankName" type="text" value={bankDetails.bank} onChange={e => setBankDetails({...bankDetails, bank: e.target.value})} className="w-full mt-1 p-3 border rounded-md" />
                        </div>
                        <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">{translate('save_details')}</button>
                    </form>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">{translate('profile_title')}</h2>
            
            <div className="bg-white p-4 rounded-lg shadow-sm space-y-4">
                <h3 className="text-lg font-bold border-b pb-2">{translate('wallet')}</h3>
                <div>
                    <p className="text-sm text-gray-500">{translate('total_earnings')}</p>
                    <p className="text-2xl font-bold text-gray-800">₹{totalEarnings.toFixed(2)}</p>
                </div>
                <div className="pt-4 border-t">
                     <div className="flex justify-between items-center">
                        <p className="text-sm text-gray-500">{translate('available_balance')}</p>
                        <p className="text-2xl font-bold text-green-600">₹{(currentUser?.availableBalance || 0).toFixed(2)}</p>
                    </div>
                    <button 
                        onClick={handleWithdrawClick}
                        disabled={(currentUser?.availableBalance || 0) === 0}
                        className="w-full mt-4 bg-green-600 text-white font-bold py-2 rounded-md hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed">
                        {translate('withdraw')}
                    </button>
                </div>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm space-y-4">
                 <div>
                     <p className="text-sm font-medium text-gray-500">Name</p>
                     <p className="font-semibold text-lg text-gray-800">{currentUser?.name}</p>
                 </div>
                 <div>
                     <p className="text-sm font-medium text-gray-500">Phone</p>
                     <p className="font-semibold text-lg text-gray-800">{currentUser?.phone}</p>
                 </div>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold border-b pb-2 mb-4">{translate('vehicle_details')}</h3>
                <div className="space-y-4">
                    <div>
                         <p className="text-sm font-medium text-gray-500">{translate('vehicle_type')}</p>
                         <p className="font-semibold text-lg text-gray-800">{currentUser?.vehicleType}</p>
                     </div>
                     <div>
                         <p className="text-sm font-medium text-gray-500">{translate('vehicle_number')}</p>
                         <p className="font-semibold text-lg text-gray-800">{currentUser?.vehicleNumber}</p>
                     </div>
                </div>
            </div>

            <button onClick={() => setView('bank')} className="bg-white p-4 rounded-lg shadow-sm w-full text-left flex justify-between items-center hover:bg-gray-50 transition-colors">
                <div>
                    <p className="font-bold text-gray-800">{translate('bank_details')}</p>
                    <p className="text-sm text-gray-500">{translate('manage_bank_details')}</p>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                </svg>
            </button>

             <div className="bg-white p-4 rounded-lg shadow-sm">
                 <h2 className="text-lg font-bold mb-4 border-b pb-2">{translate('help_support')}</h2>
                 <div className="space-y-4">
                    <div>
                        <p className="font-semibold text-gray-800">{translate('faq1_q')}</p>
                        <p className="text-sm text-gray-600 mt-1">{translate('faq1_a')}</p>
                    </div>
                    <div className="border-t pt-4">
                        <p className="font-semibold text-gray-800">{translate('faq2_q')}</p>
                        <p className="text-sm text-gray-600 mt-1">{translate('faq2_a')}</p>
                    </div>
                    <div className="border-t pt-4">
                        <p className="font-semibold text-gray-800">{translate('faq3_q')}</p>
                        <p className="text-sm text-gray-600 mt-1">{translate('faq3_a')}</p>
                    </div>
                    <div className="border-t pt-4">
                         <a href="#" className="text-blue-600 hover:underline font-semibold">{translate('contact_support')}</a>
                    </div>
                 </div>
             </div>

             <Modal
                isOpen={isWithdrawModalOpen}
                onClose={() => setWithdrawModalOpen(false)}
                title={translate('withdraw_confirmation_title')}
            >
                <div>
                    <p>{translate('withdraw_confirmation_body', { amount: `₹${(currentUser?.availableBalance || 0).toFixed(2)}` })}</p>
                    {currentUser?.bankDetails &&
                        <div className="mt-2 p-3 bg-gray-100 rounded-md text-sm">
                            <p><span className="font-semibold">{translate('bank_name')}:</span> {currentUser.bankDetails.bank}</p>
                            <p><span className="font-semibold">{translate('bank_account_number')}:</span> ...{currentUser.bankDetails.accountNumber.slice(-4)}</p>
                        </div>
                    }
                    <div className="flex justify-end space-x-3 mt-4">
                        <button onClick={() => setWithdrawModalOpen(false)} className="px-4 py-2 bg-gray-200 font-bold rounded-md hover:bg-gray-300">{translate('cancel')}</button>
                        <button onClick={confirmWithdrawal} className="px-4 py-2 bg-green-600 text-white font-bold rounded-md hover:bg-green-700">{translate('confirm')}</button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default ProfileTab;