
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. Analysis feature will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export async function analyzeRecipeWithGemini(description: string): Promise<string> {
    if(!API_KEY) {
        return "Gemini API key is not configured. Cannot analyze recipe.";
    }
    
    try {
        const model = 'gemini-2.5-flash';
        const systemInstruction = "You are a food safety expert. Analyze the following recipe description from a home cook. Provide a brief, bulleted list of feedback focusing on potential health/safety improvements or positive practices. Be encouraging and helpful. If the description is too vague, ask for more details. Keep the response under 100 words.";
        
        const response = await ai.models.generateContent({
            model: model,
            contents: description,
            config: {
                systemInstruction: systemInstruction,
            }
        });

        return response.text;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to get analysis from Gemini.");
    }
}
