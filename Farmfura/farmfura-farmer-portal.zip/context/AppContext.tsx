import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { AppMode, StagedItems, Submission, Sale, UserState, ToastMessage, User, PermissionStatus } from '../types';
import { translations } from '../constants';

type LocationStatus = 'idle' | 'detecting' | 'success' | 'error';

interface AppContextType {
  farmerId: string | null;
  login: (id: string) => void;
  logout: () => void;
  userState: UserState;
  updateUserState: (id: string, updates: Partial<User>) => void;
  currentUser: User | null;
  
  appMode: AppMode;
  setAppMode: React.Dispatch<React.SetStateAction<AppMode>>;
  
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string, replacements?: { [key: string]: string | number }) => string;
  
  stagedItems: StagedItems;
  setStagedItems: React.Dispatch<React.SetStateAction<StagedItems>>;
  
  submissions: Submission[];
  setSubmissions: React.Dispatch<React.SetStateAction<Submission[]>>;

  salesHistory: Sale[];
  setSalesHistory: React.Dispatch<React.SetStateAction<Sale[]>>;
  
  toast: ToastMessage | null;
  showToast: (message: string) => void;

  locationStatus: LocationStatus;
  permissionStatus: PermissionStatus;
  isLocationModalOpen: boolean;
  setIsLocationModalOpen: React.Dispatch<React.SetStateAction<boolean>>;
  initiateLocationDetection: () => void;
  fetchCoordinates: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [farmerId, setFarmerId] = useState<string | null>(() => localStorage.getItem('farmfura_farmerId'));
  const [userState, setUserState] = useState<UserState>(() => {
    const saved = localStorage.getItem('farmfura_userState');
    return saved ? JSON.parse(saved) : {};
  });
  const [appMode, setAppMode] = useState<AppMode>('sell');
  const [language, setLanguageState] = useState<string>(() => localStorage.getItem('farmfura_lang') || 'en');
  const [stagedItems, setStagedItems] = useState<StagedItems>({});
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [salesHistory, setSalesHistory] = useState<Sale[]>([]);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [locationStatus, setLocationStatus] = useState<LocationStatus>('idle');
  const [permissionStatus, setPermissionStatus] = useState<PermissionStatus>('prompt');
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);

  useEffect(() => {
    if (farmerId) {
      localStorage.setItem('farmfura_farmerId', farmerId);
    } else {
      localStorage.removeItem('farmfura_farmerId');
    }
  }, [farmerId]);

  useEffect(() => {
    localStorage.setItem('farmfura_userState', JSON.stringify(userState));
  }, [userState]);

  useEffect(() => {
    if (navigator.permissions) {
      navigator.permissions.query({ name: 'geolocation' }).then((result) => {
        setPermissionStatus(result.state);
        result.onchange = () => {
          setPermissionStatus(result.state);
        };
      });
    }
  }, []);
  
  const login = (id: string) => {
    setFarmerId(id);
    if (!userState[id]) {
      setUserState(prev => ({ ...prev, [id]: { name: '', hasOnboarded: false, location: null, ratings: [], averageRating: 4.5 } }));
    }
  };
  
  const logout = () => {
    setFarmerId(null);
    setStagedItems({});
    setAppMode('sell');
  };
  
  const updateUserState = (id: string, updates: Partial<User>) => {
    setUserState(prev => ({
      ...prev,
      [id]: { ...prev[id], ...updates },
    }));
  };

  const setLanguage = (lang: string) => {
    setLanguageState(lang);
    localStorage.setItem('farmfura_lang', lang);
  };
  
  const t = useCallback((key: string, replacements: { [key: string]: string | number } = {}) => {
    let translation = translations[language]?.[key] || key;
    Object.keys(replacements).forEach(placeholder => {
      translation = translation.replace(`{${placeholder}}`, String(replacements[placeholder]));
    });
    return translation;
  }, [language]);
  
  const showToast = (message: string) => {
    setToast({ message, id: Date.now() });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchCoordinates = useCallback(() => {
    if (!farmerId) return;

    setLocationStatus('detecting');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const newLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        updateUserState(farmerId, { location: newLocation });
        setLocationStatus('success');
        showToast(t('update_location_success', { lat: newLocation.lat.toFixed(4), lng: newLocation.lng.toFixed(4) }));
      },
      (error) => {
        console.error("Geolocation error:", error);
        setLocationStatus('error');
        showToast('Could not get location. Please enable permissions.');
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }, [farmerId, t, updateUserState, showToast]);

  const initiateLocationDetection = useCallback(() => {
    if (permissionStatus === 'granted') {
      fetchCoordinates();
    } else {
      setIsLocationModalOpen(true);
    }
  }, [permissionStatus, fetchCoordinates]);

  const currentUser = farmerId ? userState[farmerId] : null;
  
  return (
    <AppContext.Provider value={{
      farmerId, login, logout, userState, updateUserState, currentUser,
      appMode, setAppMode,
      language, setLanguage, t,
      stagedItems, setStagedItems,
      submissions, setSubmissions,
      salesHistory, setSalesHistory,
      toast, showToast,
      locationStatus, 
      permissionStatus,
      isLocationModalOpen,
      setIsLocationModalOpen,
      initiateLocationDetection,
      fetchCoordinates,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};