
import React, { useEffect } from 'react';

interface ToastProps {
  message: string;
  isError?: boolean;
  onDismiss: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, isError = false, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss();
    }, 3000);

    return () => {
      clearTimeout(timer);
    };
  }, [onDismiss]);

  const bgColor = isError ? 'bg-red-600' : 'bg-green-600';

  return (
    <div 
      className={`fixed bottom-4 left-1/2 -translate-x-1/2 p-4 rounded-lg shadow-xl text-white ${bgColor} transition-opacity duration-300 opacity-100 z-[150]`}
    >
      {message}
    </div>
  );
};
