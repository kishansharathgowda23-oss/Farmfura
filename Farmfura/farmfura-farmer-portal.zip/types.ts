export type PermissionStatus = 'prompt' | 'granted' | 'denied';

export interface Product {
  id: number;
  name: string;
  price?: number; // Retail price
  farmerPrice?: number; // Price farmer gets
  sellPrice?: number; // Price farmer sells at
  buyPrice?: number; // Price farmer buys at
  category: string;
  unit: 'kg' | 'bundle' | 'piece' | 'Litre' | 'stem' | 'bunch' | 'packet' | 'flower';
  image: string;
  names: { [key: string]: string };
  inStock?: boolean;
  type: 'vegetable' | 'fruit' | 'flower' | 'home-products' | 'seed' | 'farm_supply';
}

export interface Category {
  id: string;
  names: { [key: string]: string };
  type: string;
}

export interface StagedItemDetails {
  quantity: number;
  description?: string;
  fileName?: string;
  verificationStatus?: 'Pending' | 'Approved' | 'Rejected';
  analysisResult?: string;
}

export type StagedItems = {
  [productId: string]: number | StagedItemDetails;
};

export interface Submission {
  id: string;
  timestamp: number;
  items: { name: string; quantity: number; unit: string; price: number }[];
  totalEarnings: number;
  status: 'Pending' | 'Accepted' | 'Completed';
}

export interface Sale {
    productId: string;
    quantity: number;
    earnings?: number;
    cost?: number;
    date: Date;
    type: 'sale' | 'purchase';
}

export interface User {
  name: string;
  hasOnboarded: boolean;
  location: { lat: number; lng: number } | null;
  ratings: number[];
  averageRating: number;
}

export type UserState = {
  [farmerId: string]: User;
};

export type AppMode = 'sell' | 'buy';

export type ToastMessage = {
  message: string;
  id: number;
};