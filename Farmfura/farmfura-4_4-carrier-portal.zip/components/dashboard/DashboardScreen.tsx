import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { useToast } from '../../contexts/ToastContext';
import * as api from '../../services/mockApi';
import LanguageSwitcher from '../shared/LanguageSwitcher';
import AvailableTab from './tabs/AvailableTab';
import TransactionsTab from './tabs/TransactionsTab';
import ProfileTab from './tabs/ProfileTab';

type Tab = 'available' | 'transactions' | 'me';

const DashboardScreen: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const { t } = useLanguage();
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<Tab>('available');
  const jobCountRef = useRef<number>(0);

  // Effect for polling for new jobs.
  useEffect(() => {
    // 1. Get the initial count of available jobs when the component mounts.
    jobCountRef.current = api.getPickupRequests().filter(p => p.status === 'pending').length;

    // 2. Set up an interval to check for new jobs every 30 seconds.
    const interval = setInterval(() => {
      const availableJobs = api.getPickupRequests().filter(p => p.status === 'pending');
      
      // 3. If the number of available jobs has increased, show a toast notification.
      if (availableJobs.length > jobCountRef.current) {
        showToast(t('new_job_available'));
      }

      // 4. Update the reference with the latest count for the next check.
      jobCountRef.current = availableJobs.length;
    }, 30000); // Poll every 30 seconds

    // 5. Clean up the interval when the component unmounts to prevent memory leaks.
    return () => clearInterval(interval);
  }, [showToast, t]); // Dependencies for the effect.


  const renderContent = () => {
    switch (activeTab) {
      case 'available':
        return <AvailableTab />;
      case 'transactions':
        return <TransactionsTab />;
      case 'me':
        return <ProfileTab />;
      default:
        return <AvailableTab />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="text-3xl font-bold text-green-700 italic">🌱 Farmfura</div>
            <nav className="flex items-center space-x-4 md:space-x-6">
              <span className="hidden md:block font-semibold text-gray-700">{t('welcome')}, {currentUser?.name}</span>
              <div className="hidden md:block pl-4 border-l">
                <LanguageSwitcher/>
              </div>
              <button onClick={logout} className="font-semibold text-red-600 hover:text-red-800">{t('nav_logout')}</button>
            </nav>
          </div>
        </div>
      </header>
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-20">
        {renderContent()}
      </main>
      <BottomNavBar activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};

const BottomNavBar: React.FC<{ activeTab: Tab, setActiveTab: (tab: Tab) => void }> = ({ activeTab, setActiveTab }) => {
  const { t } = useLanguage();
  // Fix: Changed `JSX.Element` to `React.ReactNode` to resolve error 'Cannot find namespace JSX'.
  const navItems: { id: Tab; labelKey: string; icon: React.ReactNode }[] = [
    { id: 'available', labelKey: 'home_nav', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125h9.75a1.125 1.125 0 001.125-1.125V9.75M8.25 21h8.25" /></svg> },
    { id: 'transactions', labelKey: 'transactions_nav', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0l.879-.659M12 21a9.002 9.002 0 008.824-10.213A9.002 9.002 0 0012 3c-4.135 0-7.64 2.645-8.824 6.287A9.002 9.002 0 0012 21z" /></svg> },
    { id: 'me', labelKey: 'me_nav', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" /></svg> }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.1)] z-[100] flex justify-around p-1">
      {navItems.map(item => (
        <button key={item.id} onClick={() => setActiveTab(item.id)} className={`flex flex-col items-center justify-center flex-1 p-1 text-xs font-medium transition-colors duration-200 ease-in-out ${activeTab === item.id ? 'text-green-600' : 'text-gray-500'}`}>
          {item.icon}
          <span>{t(item.labelKey)}</span>
        </button>
      ))}
    </nav>
  );
};

export default DashboardScreen;