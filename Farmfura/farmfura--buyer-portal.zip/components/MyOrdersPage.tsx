
import React from 'react';
import { Order } from '../types';

interface MyOrdersPageProps {
    orders: Order[];
    translations: Record<string, string>;
    onChat: () => void;
}

const MyOrdersPage: React.FC<MyOrdersPageProps> = ({ orders, translations, onChat }) => {
    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-800 mb-6">{translations.my_orders_title}</h1>
            <div className="space-y-4">
                {orders.length === 0 ? (
                    <p className="text-center text-gray-500">{translations.no_orders}</p>
                ) : (
                    orders.map(order => (
                        <div key={order.id} className="bg-white p-4 rounded-lg shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center">
                            <div className="mb-2 sm:mb-0">
                                <p className="font-bold text-lg text-gray-800">{translations.order_id}: {order.id}</p>
                                <p className="text-sm text-gray-600">{translations.order_date}: {new Date(order.timestamp).toLocaleDateString()}</p>
                                <p className="text-sm text-gray-500 mt-1">{translations.order_items}: {order.items.map(item => `${item.name} (x${item.quantity})`).join(', ')}</p>
                            </div>
                            <div className="flex items-center space-x-4">
                                <span className="text-xl font-bold text-green-700">₹{order.total.toFixed(2)}</span>
                                <span className="text-sm px-3 py-1 rounded-full bg-yellow-100 text-yellow-800">{order.status}</span>
                                <button onClick={onChat} className="bg-blue-500 text-white px-3 py-1 rounded-md text-sm">{translations.chat_btn}</button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default MyOrdersPage;
