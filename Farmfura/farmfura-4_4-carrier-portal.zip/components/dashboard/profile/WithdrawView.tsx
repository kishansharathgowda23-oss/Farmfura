import React, { useState } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import { useLanguage } from '../../../contexts/LanguageContext';
import { useToast } from '../../../contexts/ToastContext';
import * as api from '../../../services/mockApi';

interface WithdrawViewProps {
  onBack: () => void;
  balance: number;
}

const WithdrawView: React.FC<WithdrawViewProps> = ({ onBack, balance }) => {
  const { currentUser, refreshUser } = useAuth();
  const { t } = useLanguage();
  const { showToast } = useToast();
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'Instant' | 'Standard'>('Standard');
  const [isConfirming, setIsConfirming] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      showToast('Please enter a valid amount.');
      return;
    }
    if (balance < numericAmount) {
      showToast(t('insufficient_balance'));
      return;
    }
    setIsConfirming(true);
  };

  const handleConfirmWithdrawal = () => {
    if (!currentUser) return;
    const numericAmount = parseFloat(amount);
    
    const result = api.addWithdrawal(currentUser.id, { amount: numericAmount, type });
    if (result) {
      showToast('Withdrawal request submitted!');
      refreshUser();
      onBack();
    } else {
      showToast('An error occurred.');
    }
    setIsConfirming(false);
  };

  const renderConfirmationDialog = () => {
    if (!isConfirming) return null;
    
    const numericAmount = parseFloat(amount);
    // Calculate the fee (1% for Instant, 0 for Standard)
    const fee = type === 'Instant' ? numericAmount * 0.01 : 0;
    // Calculate the final amount the user will receive
    const netPayout = numericAmount - fee;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
        <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-sm">
          <h3 className="text-xl font-bold text-gray-800">{t('withdraw_confirm_title')}</h3>
          <div className="my-4 text-gray-700 space-y-2">
            <div className="flex justify-between">
              <span>{t('amount')}:</span>
              <span className="font-semibold">₹{numericAmount.toFixed(2)}</span>
            </div>
            
            {/* Conditionally display the fee only for Instant withdrawals */}
            {type === 'Instant' && (
              <div className="flex justify-between border-t pt-2 mt-2">
                <span>{t('fee')}:</span> 
                <span className="font-semibold text-red-500">- ₹{fee.toFixed(2)}</span>
              </div>
            )}
            
            {/* Display the final net payout amount */}
            <div className="flex justify-between text-lg font-bold border-t pt-2 mt-2">
                <span>{t('net_payout')}:</span> 
                <span className="text-green-700">₹{netPayout.toFixed(2)}</span>
            </div>
          </div>
          <div className="flex justify-end space-x-3">
            <button onClick={() => setIsConfirming(false)} className="bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-md hover:bg-gray-400">
              {t('cancel')}
            </button>
            <button onClick={handleConfirmWithdrawal} className="bg-green-600 text-white font-bold py-2 px-4 rounded-md hover:bg-green-700">
              {t('confirm')}
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{t('withdraw_funds')}</h3>
        <p className="text-center text-gray-600 mb-4">{t('withdrawable_balance')}: <span className="font-bold text-green-600">₹{balance.toFixed(2)}</span></p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">{t('withdraw_type')}</label>
            <div className="flex space-x-4">
              <label className="flex items-center">
                <input type="radio" name="withdrawType" value="Standard" checked={type === 'Standard'} onChange={() => setType('Standard')} className="h-4 w-4 text-green-600 border-gray-300 focus:ring-green-500" />
                <span className="ml-2">{t('standard')}</span>
              </label>
              <label className="flex items-center">
                <input type="radio" name="withdrawType" value="Instant" checked={type === 'Instant'} onChange={() => setType('Instant')} className="h-4 w-4 text-green-600 border-gray-300 focus:ring-green-500" />
                <span className="ml-2">{t('instant')} (1% fee)</span>
              </label>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium">{t('amount')}</label>
            <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="w-full p-2 border rounded-md" placeholder="0.00" required step="0.01" min="1" max={balance} />
          </div>
          <div className="flex justify-end space-x-3 pt-4">
            <button type="button" onClick={onBack} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-md">{t('back')}</button>
            <button type="submit" className="bg-green-600 text-white font-bold py-2 px-4 rounded-md">{t('withdraw')}</button>
          </div>
        </form>
      </div>

      {renderConfirmationDialog()}
    </>
  );
};

export default WithdrawView;
