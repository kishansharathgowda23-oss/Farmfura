import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { allProducts } from '../constants';
import { StagedItemDetails } from '../types';
import { LocationIcon } from '../components/Icons';

export const CartPage: React.FC = () => {
    const { stagedItems, setStagedItems, appMode, t, setSubmissions, setSalesHistory, showToast } = useAppContext();
    const navigate = useNavigate();

    const { items, total } = useMemo(() => {
        const items = Object.entries(stagedItems).map(([id, itemData]) => {
            const product = allProducts.find(p => p.id === Number(id));
            if (!product) return null;

            const quantity = typeof itemData === 'number' ? itemData : (itemData as StagedItemDetails).quantity;
            const price = appMode === 'sell' ? (product.sellPrice ?? product.farmerPrice ?? 0) : (product.buyPrice ?? 0);
            return { product, quantity, total: quantity * price };
        }).filter(Boolean);
        const total = items.reduce((sum, item) => sum + (item?.total || 0), 0);
        return { items, total };
    }, [stagedItems, appMode, t]);

    const handleSubmit = () => {
        if(items.length === 0) {
            showToast(t('add_item_toast'));
            return;
        }

        if (appMode === 'sell') {
            const submissionId = Date.now().toString().slice(-6);
            setSubmissions(prev => [
                {
                    id: submissionId,
                    timestamp: Date.now(),
                    items: items.map(i => ({ name: i!.product.name, quantity: i!.quantity, unit: i!.product.unit, price: i!.product.sellPrice ?? i!.product.farmerPrice ?? 0 })),
                    totalEarnings: total,
                    status: 'Pending'
                },
                ...prev
            ]);
            
            items.forEach(i => {
                setSalesHistory(prev => [...prev, {
                    productId: String(i!.product.id),
                    quantity: i!.quantity,
                    earnings: i!.total,
                    date: new Date(),
                    type: 'sale'
                }]);
            });

            setStagedItems({});
            showToast(t('pickup_message_success'));
            navigate(`/status/${submissionId}`);
        } else {
            // In buy mode, go to purchase page of first item
            if(items[0]) {
                navigate(`/purchase/${items[0].product.id}`);
            }
        }
    };
    
    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-800 mb-6">{t(appMode === 'sell' ? 'cart_title_sell' : 'cart_title_buy')}</h1>
            <div className="space-y-4">
                {items.length === 0 ? (
                    <p className="text-center text-gray-500">Your cart is empty.</p>
                ) : (
                    items.map(({ product, quantity, total }) => (
                        <div key={product!.id} className="bg-white p-3 rounded-lg shadow-sm flex items-center justify-between">
                            <div className="flex items-center">
                                <img src={product!.image} alt={product!.name} className="w-16 h-16 object-cover rounded-md mr-4" onError={(e) => (e.currentTarget.src = 'https://picsum.photos/64/64')} />
                                <div>
                                    <p className="font-semibold">{product!.name}</p>
                                    <p className="text-sm text-gray-600">{quantity} {t(`unit_${product!.unit}`)} x ₹{(total/quantity).toFixed(2)}</p>
                                </div>
                            </div>
                            <p className="font-bold text-lg">₹{total.toFixed(2)}</p>
                        </div>
                    ))
                )}
            </div>
            {items.length > 0 && (
                <div className="mt-8 pt-4 border-t-2 border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4">
                    <div className="text-center md:text-left">
                        <span className="text-lg font-bold text-gray-700 mr-4">{t(appMode === 'sell' ? 'farmer_total_earnings' : 'cart_total_buy')}</span>
                        <span className={`text-xl font-bold ${appMode === 'sell' ? 'text-green-700' : 'text-blue-700'}`}>₹{total.toFixed(2)}</span>
                    </div>
                    <button onClick={handleSubmit} className={`w-full md:w-auto text-white font-bold py-3 px-6 rounded-md transition ${appMode === 'sell' ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'}`}>
                        {t(appMode === 'sell' ? 'cart_submit_sell' : 'cart_submit_buy')}
                    </button>
                </div>
            )}
        </div>
    );
};

export const PurchasePage: React.FC = () => {
    const { productId } = useParams<{ productId: string }>();
    const product = allProducts.find(p => p.id === Number(productId));
    const { t, setSalesHistory, showToast, initiateLocationDetection, locationStatus, currentUser } = useAppContext();
    const navigate = useNavigate();

    const [quantity, setQuantity] = useState(1);
    const [address, setAddress] = useState('');
    const [isDetectingForAddress, setIsDetectingForAddress] = useState(false);

    useEffect(() => {
        if (isDetectingForAddress && locationStatus === 'success' && currentUser?.location) {
            setAddress(`Lat: ${currentUser.location.lat.toFixed(4)}, Lng: ${currentUser.location.lng.toFixed(4)}\n(Please add street/house details)`);
            setIsDetectingForAddress(false);
        }
        if (isDetectingForAddress && locationStatus === 'error') {
            setIsDetectingForAddress(false);
        }
    }, [locationStatus, currentUser?.location, isDetectingForAddress]);

    if (!product) return <p>Product not found.</p>;

    const price = product.buyPrice ?? 0;
    const total = quantity * price;
    
    const handleConfirm = () => {
        if (quantity <= 0 || !address.trim()) {
            showToast('Please enter a valid quantity and address.');
            return;
        }
        setSalesHistory(prev => [...prev, {
            productId: String(product.id),
            quantity: quantity,
            cost: total,
            date: new Date(),
            type: 'purchase'
        }]);
        showToast(t('order_confirmed'));
        navigate(`/status/${Date.now().toString().slice(-6)}`);
    };
    
    const handleDetectLocation = () => {
        setIsDetectingForAddress(true);
        initiateLocationDetection();
    };

    return (
        <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-md">
            <h1 className="text-3xl font-bold text-gray-800 mb-6 border-b pb-4">{t('confirm_purchase_title')}</h1>
            <div className="flex items-center space-x-6 mb-6">
                <img src={product.image} className="w-20 h-20 object-cover rounded-md" />
                <div>
                    <p className="font-bold text-lg">{product.name}</p>
                    <p className="text-blue-600 font-semibold">@ ₹{price.toFixed(2)} / {t(`unit_${product.unit}`)}</p>
                </div>
            </div>
            <div className="space-y-4">
                <div>
                    <label htmlFor="purchase-quantity" className="block text-sm font-medium text-gray-700">{t('quantity')}</label>
                    <input type="number" id="purchase-quantity" value={quantity} onChange={e => setQuantity(Number(e.target.value))} min="1" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm" />
                </div>
                <div>
                    <label htmlFor="delivery-address" className="block text-sm font-medium text-gray-700">{t('delivery_address')}</label>
                    <textarea id="delivery-address" value={address} onChange={e => setAddress(e.target.value)} rows={3} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"></textarea>
                     <button onClick={handleDetectLocation} disabled={locationStatus === 'detecting'} className="mt-2 text-sm text-green-600 hover:underline flex items-center space-x-1">
                        <LocationIcon className="w-4 h-4"/>
                         <span>{locationStatus === 'detecting' && isDetectingForAddress ? 'Detecting...' : t('detect_location_btn')}</span>
                     </button>
                </div>
                <div className="text-right">
                    <p className="text-lg font-bold text-gray-800">{t('total_amount')}:</p>
                    <p className="text-2xl font-bold text-blue-600">₹{total.toFixed(2)}</p>
                </div>
            </div>
            <div className="mt-8 grid grid-cols-2 gap-4">
                <button onClick={() => navigate('/cart')} className="w-full bg-gray-200 text-gray-800 font-bold py-3 rounded-md">{t('cancel')}</button>
                <button onClick={handleConfirm} className="w-full bg-blue-600 text-white font-bold py-3 rounded-md">{t('confirm_purchase_btn')}</button>
            </div>
        </div>
    );
};

export const StatusPage: React.FC = () => {
    const { t } = useAppContext();
    const navigate = useNavigate();
    const [statusIndex, setStatusIndex] = useState(0);
    const [truckPosition, setTruckPosition] = useState(10);
    
    const statuses = [
        { icon: '⏳', title: 'Searching...', text: 'Finding a carrier for your pickup/delivery.' },
        { icon: '✅', title: 'Assigned!', text: 'A carrier is on their way.' },
        { icon: '🚚', title: 'Arrived!', text: 'Your carrier has arrived.' },
    ];

    useEffect(() => {
        const interval = setInterval(() => {
            setStatusIndex(prev => {
                const next = prev + 1;
                if(next < statuses.length) {
                    setTruckPosition(pos => pos + 40);
                    return next;
                }
                clearInterval(interval);
                return prev;
            });
        }, 4000);
        return () => clearInterval(interval);
    }, []);

    const currentStatus = statuses[statusIndex];

    return (
        <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-md text-center">
            <div className="text-5xl mb-4">{currentStatus.icon}</div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">{currentStatus.title}</h1>
            <p className="text-gray-600 mb-6">{currentStatus.text}</p>
            <div id="map-container" className="rounded-lg shadow-inner mb-4">
                <div id="truck-icon" style={{ left: `${truckPosition}%` }}>🚚</div>
            </div>
            <button className="bg-blue-500 text-white font-bold py-2 px-4 rounded-md">{t('chat_with_driver')}</button>
            <button onClick={() => navigate('/')} className="mt-8 bg-gray-300 text-gray-800 font-bold py-3 px-8 rounded-md">{t('back_to_dashboard_btn')}</button>
        </div>
    );
};