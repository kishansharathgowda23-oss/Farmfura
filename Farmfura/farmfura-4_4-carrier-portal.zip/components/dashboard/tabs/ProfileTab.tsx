import React, { useState, useEffect } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import { useLanguage } from '../../../contexts/LanguageContext';
import BankDetailsView from '../profile/BankDetailsView';
import WithdrawView from '../profile/WithdrawView';
import * as api from '../../../services/mockApi';

type ProfileView = 'main' | 'bank' | 'withdraw';

const ProfileTab: React.FC = () => {
  const [view, setView] = useState<ProfileView>('main');
  const { currentUser, logout, refreshUser } = useAuth();
  const { t } = useLanguage();
  const [completedJobCount, setCompletedJobCount] = useState(0);
  
  useEffect(() => {
    if (view === 'main') {
        refreshUser();
        if(currentUser){
            setCompletedJobCount(api.getCompletedJobs().filter(j => j.carrierId === currentUser.id).length);
        }
    }
  }, [view, refreshUser, currentUser]);

  if (!currentUser) return null;

  const getBadges = () => {
    const badges = [];
    if (completedJobCount >= 1) {
        badges.push({ name: t('rising_star'), color: 'bg-green-100 text-green-800' });
    }
    if (completedJobCount >= 5) {
        badges.push({ name: t('pro_carrier'), color: 'bg-blue-100 text-blue-800' });
    }
    if (completedJobCount >= 10) {
        badges.push({ name: t('expert_hauler'), color: 'bg-purple-100 text-purple-800' });
    }
    return badges;
  }

  const renderContent = () => {
    switch (view) {
      case 'bank':
        return <BankDetailsView onBack={() => setView('main')} />;
      case 'withdraw':
        return <WithdrawView onBack={() => setView('main')} balance={currentUser.withdrawableBalance || 0} />;
      case 'main':
      default:
        return (
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            {/* Balance Section */}
            <div className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 text-center">
              <h3 className="text-md font-medium text-gray-600 uppercase tracking-wider">{t('withdrawable_balance')}</h3>
              <p className="text-5xl font-bold text-green-700 mt-2">
                ₹{currentUser.withdrawableBalance?.toFixed(2) || '0.00'}
              </p>
            </div>

            <div className="p-6 space-y-6">
              {/* Achievements Section */}
              {getBadges().length > 0 && (
                <div>
                  <h4 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">{t('achievements')}</h4>
                  <div className="flex flex-wrap gap-2">
                    {getBadges().map(badge => (
                        <span key={badge.name} className={`px-3 py-1 text-sm font-semibold rounded-full ${badge.color}`}>
                            🏆 {badge.name}
                        </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Personal Details Section */}
              <div>
                <h4 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">{t('personal_information')}</h4>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">{t('profile_name')}</p>
                    <p className="font-semibold text-lg text-gray-900">{currentUser.name}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">{t('profile_phone')}</p>
                    <p className="font-semibold text-lg text-gray-900">{currentUser.phone}</p>

                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">{t('profile_vehicle')}</p>
                    <p className="font-semibold text-lg text-gray-900">{currentUser.vehicleType} ({currentUser.vehicleNumber})</p>
                  </div>
                </div>
              </div>

              {/* Actions Section */}
              <div>
                <h4 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">{t('actions')}</h4>
                <div className="space-y-3">
                  <button onClick={() => setView('bank')} className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-md hover:bg-blue-700 transition-colors">{t('bank_details')}</button>
                  <button onClick={() => setView('withdraw')} className="w-full bg-green-600 text-white font-bold py-3 px-4 rounded-md hover:bg-green-700 transition-colors">{t('withdraw_funds')}</button>
                  <button onClick={logout} className="w-full bg-red-600 text-white font-bold py-3 px-4 rounded-md hover:bg-red-700 transition-colors">{t('nav_logout')}</button>
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">{t('me_nav')}</h2>
      {renderContent()}
    </div>
  );
};

export default ProfileTab;
