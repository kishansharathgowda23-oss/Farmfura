import React, { useState, useEffect } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import { useLanguage } from '../../../contexts/LanguageContext';
import * as api from '../../../services/mockApi';
import { PickupJob, Withdrawal } from '../../../types';

const TransactionsTab: React.FC = () => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();
  const [completedJobs, setCompletedJobs] = useState<PickupJob[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);

  useEffect(() => {
    if (currentUser) {
      setCompletedJobs(api.getCompletedJobs().filter(j => j.carrierId === currentUser.id));
      setWithdrawals(api.getWithdrawals(currentUser.id));
    }
  }, [currentUser]);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-800 mb-4">{t('completed_jobs')}</h2>
        <div className="space-y-4">
          {completedJobs.length > 0 ? completedJobs.map(job => (
            <div key={job.id} className="bg-white rounded-lg shadow p-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-bold text-lg text-gray-900">{t('job_id')}: {job.id}</h3>
                  <p className="text-sm text-gray-600">{t('delivery_to')} {job.destinationShop}</p>
                </div>
                <span className="text-xl font-bold text-green-600">₹{job.payout}</span>
              </div>
              <p className="text-xs text-gray-500 mt-1">{t('completed_on')}: {job.completedAt ? new Date(job.completedAt).toLocaleString() : 'N/A'}</p>
            </div>
          )) : (
            <div className="bg-white rounded-lg shadow p-6 text-center">
              <p className="text-gray-500">{t('no_transactions_yet')}</p>
            </div>
          )}
        </div>
      </div>
      
      <div>
        <h2 className="text-2xl font-bold text-gray-800 mb-4">{t('withdrawal_history')}</h2>
        <div className="space-y-4">
          {withdrawals.length > 0 ? withdrawals.map(w => (
            <div key={w.id} className="bg-white rounded-lg shadow p-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-bold text-lg text-gray-900">{t('amount_withdrawn')}: <span className="text-red-600">- ₹{w.amount.toFixed(2)}</span></h3>
                  <p className="text-sm text-gray-600">{t('type')}: {t(w.type === 'Instant' ? 'instant' : 'standard')}</p>
                </div>
                 <p className="text-xs text-gray-500 mt-1">{t('date')}: {new Date(w.date).toLocaleString()}</p>
              </div>
            </div>
          )) : (
            <div className="bg-white rounded-lg shadow p-6 text-center">
              <p className="text-gray-500">{t('no_transactions_yet')}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TransactionsTab;