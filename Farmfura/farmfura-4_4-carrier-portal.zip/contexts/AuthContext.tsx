
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback } from 'react';
import { Employee } from '../types';
import * as api from '../services/mockApi';

interface AuthContextType {
  currentUser: Employee | null;
  login: (user: Employee) => void;
  logout: () => void;
  refreshUser: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<Employee | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.initializeData();
    const storedUser = localStorage.getItem('farmfura_current_user');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = (user: Employee) => {
    localStorage.setItem('farmfura_current_user', JSON.stringify(user));
    setCurrentUser(user);
  };

  const logout = () => {
    localStorage.removeItem('farmfura_current_user');
    setCurrentUser(null);
  };

  const refreshUser = useCallback(() => {
    if (currentUser) {
        const freshUser = api.getEmployeeById(currentUser.id);
        if (freshUser) {
            setCurrentUser(freshUser);
            localStorage.setItem('farmfura_current_user', JSON.stringify(freshUser));
        }
    }
  }, [currentUser]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <AuthContext.Provider value={{ currentUser, login, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
