import React from 'react';
import { SubscriptionPlan } from '../types';
import { SUBSCRIPTION_PLANS } from '../constants';

interface PremiumPageProps {
    translations: Record<string, string>;
    onSelectPlan: (plan: SubscriptionPlan) => void;
}

const PremiumPage: React.FC<PremiumPageProps> = ({ translations, onSelectPlan }) => {
    const starterPlan = SUBSCRIPTION_PLANS[0];
    const familyPlan = SUBSCRIPTION_PLANS[1];

    return (
        <div>
            <div className="text-center mb-10">
                <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">{translations.premium_title}</h1>
                <p className="text-gray-600 max-w-2xl mx-auto">{translations.premium_subtitle}</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
                <div className="bg-white rounded-lg shadow-lg p-8 transform hover:-translate-y-2 transition-transform duration-300">
                    <h3 className="text-2xl font-bold text-center text-gray-800 mb-4">{translations.starter_pack_title}</h3>
                    <p className="text-4xl font-bold text-center text-green-600 mb-6">₹{starterPlan.price}<span className="text-lg font-normal text-gray-500">{translations.per_week}</span></p>
                    <ul className="space-y-3 text-gray-600 mb-8">
                        <li className="flex items-center"><svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>{translations.starter_pack_f1}</li>
                        <li className="flex items-center"><svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>{translations.starter_pack_f2}</li>
                    </ul>
                    <button onClick={() => onSelectPlan(starterPlan)} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">{translations.subscribe_btn}</button>
                </div>
                <div className="bg-white rounded-lg shadow-lg p-8 transform hover:-translate-y-2 transition-transform duration-300 border-4 border-green-600 relative">
                    <div className="absolute top-0 -translate-y-1/2 left-1/2 -translate-x-1/2 bg-green-600 text-white text-sm font-bold px-4 py-1 rounded-full">{translations.popular_tag}</div>
                    <h3 className="text-2xl font-bold text-center text-gray-800 mb-4">{translations.family_pack_title}</h3>
                    <p className="text-4xl font-bold text-center text-green-600 mb-6">₹{familyPlan.price}<span className="text-lg font-normal text-gray-500">{translations.per_week}</span></p>
                    <ul className="space-y-3 text-gray-600 mb-8">
                       <li className="flex items-center"><svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>{translations.family_pack_f1}</li>
                       <li className="flex items-center"><svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>{translations.family_pack_f2}</li>
                    </ul>
                    <button onClick={() => onSelectPlan(familyPlan)} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">{translations.subscribe_btn}</button>
                </div>
            </div>
        </div>
    );
};

export default PremiumPage;