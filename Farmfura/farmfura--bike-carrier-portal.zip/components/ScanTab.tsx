
import React, { useEffect, useState, useContext } from 'react';
import { useCamera } from '../hooks/useCamera';
import { LanguageContext } from '../App';

const ScanTab: React.FC = () => {
    const { translate } = useContext(LanguageContext);
    const { videoRef, status, startCamera, stopCamera } = useCamera();
    const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');

    useEffect(() => {
        startCamera(facingMode);
        return () => {
            stopCamera();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [facingMode]);

    const switchCamera = () => {
        setFacingMode(prev => (prev === 'user' ? 'environment' : 'user'));
    };

    return (
        <div>
            <h2 className="text-xl font-bold mb-4">{translate('scan_title')}</h2>
            <div id="scan-video-container" className="relative w-full bg-gray-800 rounded-lg overflow-hidden flex items-center justify-center min-h-[300px] md:min-h-[450px]">
                <video ref={videoRef} className={`w-full h-full object-cover ${status === 'running' ? '' : 'hidden'}`} autoPlay playsInline></video>
                
                {status === 'starting' && <div className="text-white text-center p-4">{translate('starting_camera')}</div>}
                {status === 'permission' && (
                    <div className="text-white text-center p-4">
                         <p>{translate('allow_camera_access')}</p>
                         <button onClick={() => startCamera(facingMode)} className="mt-2 bg-yellow-500 text-white text-sm font-bold py-2 px-3 rounded-md hover:bg-yellow-600">{translate('retry_camera')}</button>
                     </div>
                )}
                {status === 'error' && <div className="text-red-400 text-center p-4">{translate('camera_error')}</div>}
            </div>
            <button onClick={switchCamera} type="button" className="w-full mt-4 bg-blue-500 text-white font-bold py-3 rounded-md hover:bg-blue-600">{translate('switch_camera')}</button>
        </div>
    );
};

export default ScanTab;
