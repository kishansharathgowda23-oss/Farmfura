import { Employee, PickupJob, BankDetails, Withdrawal } from '../types';

const initLocalStorage = <T,>(key: string, defaultData: T) => {
  if (!localStorage.getItem(key)) {
    localStorage.setItem(key, JSON.stringify(defaultData));
  }
};

export const initializeData = () => {
  initLocalStorage<Employee[]>('farmfura_employees', [
    { id: '4x4001', name: 'Vikram Singh', role: '4x4_carrier', status: 'Active', phone: '7000000000', vehicleType: 'Mahindra Bolero', vehicleNumber: 'KA-02-CD-5678', withdrawableBalance: 0 }
  ]);
  initLocalStorage<PickupJob[]>('farmfura_pickupRequests', [
    {
      id: `PKUP${Date.now().toString().slice(-4)}`,
      farmerName: 'Rakesh Gowda',
      location: 'Devanahalli, Bengaluru',
      destinationShop: 'FreshMart',
      items: [{ name: 'Potato', quantity: 100, unit: 'kg' }, { name: 'Carrot', quantity: 80, unit: 'kg' }],
      payout: 500,
      status: 'pending',
      carrierId: null,
      distanceKms: 15
    },
    {
      id: `PKUP${(Date.now() - 1000).toString().slice(-4)}`,
      farmerName: 'Sunil Kumar',
      location: 'Chikkaballapur, Bengaluru',
      destinationShop: 'DailyGreens',
      items: [{ name: 'Tomato', quantity: 200, unit: 'kg' }],
      payout: 650,
      status: 'pending',
      carrierId: null,
      distanceKms: 25
    }
  ]);
  initLocalStorage<PickupJob[]>('farmfura_completedJobs', []);
  initLocalStorage<Withdrawal[]>('farmfura_withdrawals', []);
  initLocalStorage<{[userId: string]: BankDetails}>('farmfura_bankDetails', {});
};

const getFromStorage = <T,>(key: string): T => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
};

const saveToStorage = <T,>(key: string, data: T) => {
  localStorage.setItem(key, JSON.stringify(data));
};

// --- Employee Functions ---
export const getEmployees = (): Employee[] => getFromStorage<Employee[]>('farmfura_employees');

export const getEmployeeById = (userId: string): Employee | undefined => {
    const employees = getEmployees();
    return employees.find(emp => emp.id === userId);
};

export const updateEmployee = (userId: string, updates: Partial<Employee>): Employee | undefined => {
    const employees = getEmployees();
    const userIndex = employees.findIndex(e => e.id === userId);
    if (userIndex > -1) {
      employees[userIndex] = { ...employees[userIndex], ...updates };
      saveToStorage('farmfura_employees', employees);
      return employees[userIndex];
    }
    return undefined;
};

export const findEmployeeByPhone = (phone: string): Employee | undefined => {
  const employees = getEmployees();
  return employees.find(emp => emp.phone === phone && emp.role === '4x4_carrier');
};
export const addEmployee = (employeeData: Omit<Employee, 'id'>): Employee => {
  const employees = getEmployees();
  const newEmployee: Employee = {
    ...employeeData,
    id: `APP${Date.now().toString().slice(-4)}`,
    withdrawableBalance: 0
  };
  employees.push(newEmployee);
  saveToStorage('farmfura_employees', employees);
  return newEmployee;
};

// --- Job Functions ---
export const getPickupRequests = (): PickupJob[] => getFromStorage<PickupJob[]>('farmfura_pickupRequests');
export const updatePickupRequest = (jobId: string, updates: Partial<PickupJob>): PickupJob | undefined => {
  const jobs = getPickupRequests();
  const jobIndex = jobs.findIndex(j => j.id === jobId);
  if (jobIndex > -1) {
    jobs[jobIndex] = { ...jobs[jobIndex], ...updates };
    saveToStorage('farmfura_pickupRequests', jobs);
    return jobs[jobIndex];
  }
  return undefined;
};
export const getCompletedJobs = (): PickupJob[] => getFromStorage<PickupJob[]>('farmfura_completedJobs');

export const completeJob = (jobId: string): PickupJob | undefined => {
    const jobs = getPickupRequests();
    const jobIndex = jobs.findIndex(j => j.id === jobId);
    if(jobIndex > -1) {
        const [jobToComplete] = jobs.splice(jobIndex, 1);
        jobToComplete.status = 'delivered';
        jobToComplete.completedAt = new Date().toISOString();
        const completed = getCompletedJobs();
        completed.unshift(jobToComplete);
        saveToStorage('farmfura_pickupRequests', jobs);
        saveToStorage('farmfura_completedJobs', completed);

        if (jobToComplete.carrierId) {
            const carrier = getEmployeeById(jobToComplete.carrierId);
            if (carrier) {
                const distanceBonus = (jobToComplete.distanceKms || 10) * 20;
                const totalEarnings = jobToComplete.payout + distanceBonus;
                const newBalance = (carrier.withdrawableBalance || 0) + totalEarnings;
                updateEmployee(carrier.id, { withdrawableBalance: newBalance });
            }
        }
        return jobToComplete;
    }
    return undefined;
}

export const cancelJob = (jobId: string): PickupJob | undefined => {
    return updatePickupRequest(jobId, { status: 'pending', carrierId: null });
}

export const rateCompletedJob = (jobId: string, rating: number): PickupJob | undefined => {
    const jobs = getCompletedJobs();
    const jobIndex = jobs.findIndex(j => j.id === jobId);
    if (jobIndex > -1) {
        jobs[jobIndex].carrierRating = rating;
        saveToStorage('farmfura_completedJobs', jobs);
        return jobs[jobIndex];
    }
    return undefined;
}


// --- Bank & Withdrawal Functions ---
export const getBankDetails = (userId: string): BankDetails | null => {
  const allDetails = getFromStorage<{[userId: string]: BankDetails}>('farmfura_bankDetails');
  return allDetails[userId] || null;
}

export const saveBankDetails = (userId: string, details: BankDetails) => {
  const allDetails = getFromStorage<{[userId: string]: BankDetails}>('farmfura_bankDetails');
  allDetails[userId] = details;
  saveToStorage('farmfura_bankDetails', allDetails);
}

export const getWithdrawals = (userId: string): Withdrawal[] => {
  const allWithdrawals = getFromStorage<Withdrawal[]>('farmfura_withdrawals');
  // In a real app, withdrawals would be associated with a user ID. Here we return all for simplicity.
  return allWithdrawals; 
}

export const addWithdrawal = (userId: string, withdrawalData: Omit<Withdrawal, 'id' | 'status' | 'date'>): Withdrawal | null => {
  const user = getEmployeeById(userId);
  if (!user || (user.withdrawableBalance || 0) < withdrawalData.amount) {
      return null; // Insufficient balance
  }

  const newBalance = (user.withdrawableBalance || 0) - withdrawalData.amount;
  updateEmployee(userId, { withdrawableBalance: newBalance });
    
  const allWithdrawals = getWithdrawals(userId);
  const newWithdrawal: Withdrawal = {
    ...withdrawalData,
    id: `WTH${Date.now().toString().slice(-5)}`,
    date: new Date().toISOString(),
    status: 'Completed'
  };
  allWithdrawals.unshift(newWithdrawal);
  saveToStorage('farmfura_withdrawals', allWithdrawals);
  return newWithdrawal;
}
