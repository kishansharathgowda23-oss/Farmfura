
import React from 'react';

interface BottomNavProps {
    currentPage: string;
    onNavigate: (page: any) => void;
    translations: Record<string, string>;
}

// FIX: Changed icon type from `JSX.Element` to `React.ReactElement` to resolve JSX namespace error.
const NavLink: React.FC<{ href: string; currentPage: string; onNavigate: (page: any) => void; icon: React.ReactElement; label: string }> = ({ href, currentPage, onNavigate, icon, label }) => (
    <a 
        href={href} 
        onClick={(e) => { e.preventDefault(); onNavigate(href); }}
        className={`flex flex-col items-center justify-center w-1/5 pt-1 transition-colors ${currentPage === href ? 'text-green-600' : 'text-gray-600 hover:text-green-600'}`}
    >
        {icon}
        <span className="text-xs font-medium">{label}</span>
    </a>
);

const BottomNav: React.FC<BottomNavProps> = ({ currentPage, onNavigate, translations }) => {
    return (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-[0_-1px_3px_rgba(0,0,0,0.1)] z-50">
            <div className="flex justify-around items-center h-16">
                <NavLink 
                    href="#buyer-page" 
                    currentPage={currentPage} 
                    onNavigate={onNavigate}
                    label={translations.bottom_nav_shop}
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>}
                />
                <NavLink 
                    href="#rewards-page" 
                    currentPage={currentPage} 
                    onNavigate={onNavigate}
                    label={translations.bottom_nav_rewards}
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-1" fill="currentColor" viewBox="0 0 24 24"><path d="M12,2C6.486,2,2,6.486,2,12s4.486,10,10,10s10-4.486,10-10S17.514,2,12,2z M12,20c-4.411,0-8-3.589-8-8s3.589-8,8-8 s8,3.589,8,8S16.411,20,12,20z"></path><path d="M12,6c-3.309,0-6,2.691-6,6s2.691,6,6,6s6-2.691,6-6S9.309,6,12,6z M12,16c-2.206,0-4-1.794-4-4s1.794-4,4-4 s4,1.794,4,4S14.206,16,12,16z"></path></svg>}
                />
                <NavLink 
                    href="#premium-page" 
                    currentPage={currentPage} 
                    onNavigate={onNavigate}
                    label={translations.bottom_nav_premium}
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-1" viewBox="0 0 24 24" fill="currentColor"><path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .55-.45 1-1 1H6c-.55 0-1-.45-1-1v-1h14v1z"></path></svg>}
                />
                <NavLink 
                    href="#my-orders-page" 
                    currentPage={currentPage} 
                    onNavigate={onNavigate}
                    label={translations.bottom_nav_orders}
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>}
                />
                 <NavLink 
                    href="#me-page" 
                    currentPage={currentPage} 
                    onNavigate={onNavigate}
                    label={translations.bottom_nav_me}
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>}
                />
            </div>
        </div>
    );
};

export default BottomNav;