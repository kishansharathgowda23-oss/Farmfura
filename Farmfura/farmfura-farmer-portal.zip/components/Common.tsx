
import React, { ReactNode } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { CartIcon, HomeIcon, InventoryIcon, ProfileIcon, SubmissionsIcon } from './Icons';

export const Toast: React.FC<{ message: string }> = ({ message }) => {
  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 p-4 rounded-lg shadow-xl text-white bg-green-600 z-[101] animate-fade-in-out">
      {message}
    </div>
  );
};

export const Header: React.FC = () => {
    const { appMode, setAppMode, t, setStagedItems, language, setLanguage, logout } = useAppContext();
    
    const handleModeSwitch = () => {
        setAppMode(prev => prev === 'sell' ? 'buy' : 'sell');
        setStagedItems({}); // Clear cart on mode switch
    };

    const handleLangChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setLanguage(e.target.value);
    };

    return (
        <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center py-4">
                    <div className="text-3xl font-bold text-green-700 italic flex items-center">
                        🌱 Farmfura
                        <span className="ml-4 text-base font-normal text-green-500 bg-green-100 px-3 py-1 rounded-full hidden md:inline">
                            {t(appMode === 'sell' ? 'mode_sell' : 'mode_buy')}
                        </span>
                    </div>
                    <div className="flex items-center space-x-4">
                        <button onClick={handleModeSwitch} className="font-semibold text-blue-600 hover:text-blue-800">
                            {t(appMode === 'sell' ? 'mode_buy' : 'mode_sell')}
                        </button>
                        <select value={language} onChange={handleLangChange} className="block appearance-none bg-white border border-gray-300 px-4 py-2 pr-8 rounded-md shadow-sm text-sm">
                            <option value="en">English</option>
                            <option value="kn">ಕನ್ನಡ</option>
                            <option value="hi">हिन्दी</option>
                        </select>
                        <button onClick={logout} className="font-semibold text-red-600 hover:text-red-800">{t('nav_logout')}</button>
                    </div>
                </div>
            </div>
        </header>
    );
};

export const BottomNav: React.FC = () => {
    const { appMode, t, stagedItems } = useAppContext();
    const location = useLocation();
    const itemCount = Object.keys(stagedItems).length;

    const navLinkClasses = "flex flex-col items-center text-xs text-gray-500 w-1/5 transition-colors duration-200";
    const activeLinkClasses = "text-green-600";

    const getLinkClass = (path: string) => {
        return `${navLinkClasses} ${location.pathname === path ? activeLinkClasses : ''}`;
    }

    return (
        <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-[0_-1px_3px_rgba(0,0,0,0.1)] flex justify-around items-center py-2 z-50">
            <NavLink to="/" className={getLinkClass('/')}>
                <HomeIcon className="w-6 h-6 mb-0.5"/>
                <span>{t('nav_dashboard')}</span>
            </NavLink>
            {appMode === 'sell' && (
                <>
                    <NavLink to="/submissions" className={getLinkClass('/submissions')}>
                        <SubmissionsIcon className="w-6 h-6 mb-0.5" />
                        <span>{t('nav_my_submissions')}</span>
                    </NavLink>
                    <NavLink to="/inventory" className={getLinkClass('/inventory')}>
                        <InventoryIcon className="w-6 h-6 mb-0.5" />
                        <span>{t('nav_inventory')}</span>
                    </NavLink>
                </>
            )}
            <NavLink to="/cart" className={`${getLinkClass('/cart')} relative`}>
                <CartIcon className="w-6 h-6 mb-0.5" />
                <span>{t('nav_cart')}</span>
                {itemCount > 0 && <span className="absolute top-0 right-3 px-1.5 py-0.5 text-xs font-bold text-white bg-red-500 rounded-full">{itemCount}</span>}
            </NavLink>
            <NavLink to="/profile" className={getLinkClass('/profile')}>
                <ProfileIcon className="w-6 h-6 mb-0.5" />
                <span>{t('nav_you')}</span>
            </NavLink>
        </nav>
    );
};

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: ReactNode;
}

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, children }) => {
    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[120] transition-opacity duration-300"
            onClick={onClose}
        >
            <div 
                className="bg-white p-6 sm:p-8 rounded-lg shadow-xl max-w-sm w-11/12 transform transition-transform duration-300 scale-100"
                onClick={(e) => e.stopPropagation()}
            >
                {children}
            </div>
        </div>
    );
};

export const Spinner: React.FC = () => (
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
);
