
export interface User {
    id: string;
    name: string;
    role: string | string[]; // Can be single role or array of roles
    status: 'Active' | 'Pending' | 'Rejected' | 'Accepted' | 'Expired';
    phone: string;
    shopName: string;
    rejectionReason?: string;
    approvalTimestamp?: number;
    bankDetails?: BankDetails;
    balance?: number;
    rewardPoints?: number; // For dynamic rewards
    autoPayoutEnabled?: boolean; // For automated payouts
}

export interface BankDetails {
    accountNumber: string;
    ifsc: string;
    branch: string;
    bank: string;
}

export interface TimeSlot {
    id: string;
    date: string;
    time: string;
    shop: string;
    status: 'Booked' | 'Completed' | 'On Duty'; // Added 'On Duty' status
    payout?: number;
    isBonus?: boolean; // For bonus slots
}

// Represents an available, bookable slot
export interface TimeSlotTemplate {
    time: string;
    payoutRange: string;
    isBonus: boolean;
}

export interface Location {
    name: string;
    location: string;
}

export interface Withdrawal {
    id: string;
    amount: number;
    date: string;
    status: 'Pending' | 'Completed' | 'Failed';
}

export interface ToastMessage {
    message: string;
    isError: boolean;
    id: number;
}

export type TabName = 'home' | 'me' | 'scan' | 'transactions' | 'rewards';