
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import { useLanguage } from '../../../contexts/LanguageContext';
import { useToast } from '../../../contexts/ToastContext';
import * as api from '../../../services/mockApi';
import { BankDetails } from '../../../types';

interface BankDetailsViewProps {
  onBack: () => void;
}

const BankDetailsView: React.FC<BankDetailsViewProps> = ({ onBack }) => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();
  const { showToast } = useToast();
  const [details, setDetails] = useState<BankDetails>({
    accountNumber: '',
    ifsc: '',
    branchName: '',
    bankName: '',
  });

  useEffect(() => {
    if (currentUser) {
      const existingDetails = api.getBankDetails(currentUser.id);
      if (existingDetails) {
        setDetails(existingDetails);
      }
    }
  }, [currentUser]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setDetails(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentUser) {
      api.saveBankDetails(currentUser.id, details);
      showToast('Bank details saved successfully!');
      onBack();
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-xl font-bold text-gray-800 mb-4">{t('bank_details')}</h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium">{t('account_number')}</label>
          <input type="text" name="accountNumber" value={details.accountNumber} onChange={handleChange} className="w-full p-2 border rounded-md" required />
        </div>
        <div>
          <label className="block text-sm font-medium">{t('ifsc_code')}</label>
          <input type="text" name="ifsc" value={details.ifsc} onChange={handleChange} className="w-full p-2 border rounded-md" required />
        </div>
        <div>
          <label className="block text-sm font-medium">{t('branch_name')}</label>
          <input type="text" name="branchName" value={details.branchName} onChange={handleChange} className="w-full p-2 border rounded-md" required />
        </div>
        <div>
          <label className="block text-sm font-medium">{t('bank_name')}</label>
          <input type="text" name="bankName" value={details.bankName} onChange={handleChange} className="w-full p-2 border rounded-md" required />
        </div>
        <div className="flex justify-end space-x-3 pt-4">
          <button type="button" onClick={onBack} className="bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-md">{t('back')}</button>
          <button type="submit" className="bg-green-600 text-white font-bold py-2 px-4 rounded-md">{t('save_details')}</button>
        </div>
      </form>
    </div>
  );
};

export default BankDetailsView;
