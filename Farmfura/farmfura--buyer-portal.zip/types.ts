export interface Product {
  id: number;
  name: string;
  price: number;
  farmerPrice: number;
  category: 'vegetables' | 'fruits' | 'flowers' | 'homemade';
  unit: 'kg' | 'bundle' | 'piece' | 'pack';
  image: string;
  names: {
    kn: string;
    hi: string;
  };
  inStock: boolean;
}

export interface Category {
  id: 'all' | 'vegetables' | 'fruits' | 'flowers' | 'homemade';
  names: {
    en: string;
    kn: string;
    hi: string;
  };
}

export interface CartItem extends Product {
  quantity: number;
  isSubscription?: boolean;
}

export interface Order {
  id: string;
  timestamp: number;
  items: CartItem[];
  total: number;
  status: string;
  deliveryDay?: string;
}

export interface User {
  loginCredential: string;
  name: string;
}

export interface Address {
  id: number;
  name: string;
  address: string;
  city: string;
  pin: string;
}

export interface SubscriptionPlan {
    name: string;
    price: number;
    maxWeight: number; // in kgs
    description: string;
}
