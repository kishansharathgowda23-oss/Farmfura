import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { allProducts, categories, allSupplies } from '../constants';
import { LocationIcon, MicIcon, SearchIcon } from '../components/Icons';
import ProductCard from '../components/ProductCard';
import { QuantityModal } from '../components/Modals';
import { Product } from '../types';
import { Spinner } from '../components/Common';

const DashboardPage: React.FC = () => {
    const { appMode, t, currentUser, initiateLocationDetection, locationStatus, language } = useAppContext();
    const [searchTerm, setSearchTerm] = useState('');
    const [activePrimaryCategory, setActivePrimaryCategory] = useState('all');
    const [isQuantityModalOpen, setQuantityModalOpen] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

    const handleAddQuantity = (product: Product) => {
        setSelectedProduct(product);
        setQuantityModalOpen(true);
    };

    const handleVoiceSearch = () => {
        // This is a mock implementation
        const mockSearches = appMode === 'sell' ? ['Tomato', 'Mango'] : ['Urea', 'Maize'];
        setSearchTerm(mockSearches[Math.floor(Math.random() * mockSearches.length)]);
    };

    const { title, subtitle, productsToDisplay, primaryCategories } = useMemo(() => {
        const isSellMode = appMode === 'sell';
        const products = isSellMode ? allProducts.filter(p => p.type !== 'farm_supply' && p.type !== 'seed') : allSupplies;
        
        const filtered = products.filter(p => {
            const lowerCaseName = p.name.toLowerCase();
            const lowerCaseLangName = p.names?.[language]?.toLowerCase() || '';
            const lowerCaseSearch = searchTerm.toLowerCase();
            
            const matchesSearch = !lowerCaseSearch || lowerCaseName.includes(lowerCaseSearch) || lowerCaseLangName.includes(lowerCaseSearch);
            const matchesPrimary = activePrimaryCategory === 'all' || p.type === activePrimaryCategory;

            return matchesSearch && matchesPrimary;
        });

        return {
            title: isSellMode ? t('seller_dashboard_title') : t('buyer_dashboard_title'),
            subtitle: isSellMode ? t('farmer_dashboard_subtitle') : t('buyer_dashboard_subtitle'),
            productsToDisplay: filtered,
            primaryCategories: isSellMode ? categories.sell : categories.buy,
        }
    }, [appMode, searchTerm, activePrimaryCategory, t, language]);


    const renderLocationDisplay = () => {
        if (locationStatus === 'detecting') {
            return <div className="flex items-center text-sm text-gray-700 mb-6 h-5"><Spinner /> <span className="ml-2">Detecting...</span></div>;
        }
        if (currentUser?.location) {
            return <div className="text-sm text-gray-700 mb-6 h-5">📍 Lat: {currentUser.location.lat.toFixed(4)}, Lng: {currentUser.location.lng.toFixed(4)}</div>;
        }
        return <div className="text-sm text-gray-700 mb-6 h-5"></div>;
    }

    return (
        <div className="max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between md:items-center mb-2">
                <div>
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-800">{title}</h1>
                    <p className="text-gray-600">{subtitle}</p>
                    <p className={`text-lg font-semibold mt-1 ${appMode === 'sell' ? 'text-green-700' : 'text-blue-700'}`}>
                        Welcome, {currentUser?.name || 'Farmer'}!
                    </p>
                </div>
                <button onClick={initiateLocationDetection} disabled={locationStatus === 'detecting'} className={`text-sm hover:underline flex items-center space-x-1 mt-2 md:mt-0 ${appMode === 'sell' ? 'text-green-600' : 'text-blue-600'}`}>
                    <LocationIcon className="w-4 h-4" />
                    <span>{t(appMode === 'sell' ? 'detect_location_btn' : 'detect_home_location_btn')}</span>
                </button>
            </div>
            {renderLocationDisplay()}

            <div className="mb-6 flex items-center space-x-2">
                <div className="relative w-full">
                    <input type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder={t('search_placeholder')} className={`w-full p-3 pl-10 border rounded-md focus:outline-none focus:ring-2 ${appMode === 'sell' ? 'focus:ring-green-500' : 'focus:ring-blue-500'}`} />
                    <SearchIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
                <button onClick={handleVoiceSearch} type="button" className="bg-gray-200 p-3 rounded-md hover:bg-gray-300 transition shrink-0">
                    <MicIcon className="w-5 h-5 text-gray-600" />
                </button>
            </div>

            <div className="mb-4 flex flex-wrap gap-3 border-b pb-4">
                {primaryCategories.map(cat => (
                    <button key={cat.id} onClick={() => { setActivePrimaryCategory(cat.id); }} className={`category-btn px-4 py-2 text-sm font-semibold rounded-full border border-gray-300 bg-white text-gray-700 hover:bg-gray-100 transition ${activePrimaryCategory === cat.id ? 'bg-green-600 text-white shadow-md' : ''}`}>
                        {cat.names[language] || cat.names.en}
                    </button>
                ))}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4 md:gap-6">
                {productsToDisplay.map(product => (
                    <ProductCard key={product.id} product={product} onAddQuantity={handleAddQuantity} />
                ))}
            </div>
            
            <QuantityModal isOpen={isQuantityModalOpen} onClose={() => setQuantityModalOpen(false)} product={selectedProduct} />
        </div>
    );
};

export default DashboardPage;