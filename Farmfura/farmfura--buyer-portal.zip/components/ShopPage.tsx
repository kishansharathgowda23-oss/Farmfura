
import React, { useState, useEffect } from 'react';
import { Product, Category } from '../types';
import ProductCard from './ProductCard';

interface ShopPageProps {
    products: Product[];
    categories: Category[];
    addToCart: (product: Product, quantity: number) => void;
    translations: Record<string, string>;
    showToast: (message: string, isError?: boolean) => void;
}

const ShopPage: React.FC<ShopPageProps> = ({ products, categories, addToCart, translations, showToast }) => {
    const [activeCategory, setActiveCategory] = useState<string>('all');
    const [searchTerm, setSearchTerm] = useState('');
    const [isListening, setIsListening] = useState(false);

    const filteredProducts = products
        .filter(p => activeCategory === 'all' || p.category === activeCategory)
        .filter(p => {
            const lowerSearchTerm = searchTerm.toLowerCase();
            return (
                p.name.toLowerCase().includes(lowerSearchTerm) ||
                p.names.kn.toLowerCase().includes(lowerSearchTerm) ||
                p.names.hi.toLowerCase().includes(lowerSearchTerm)
            );
        })
        .sort((a,b) => a.name.localeCompare(b.name));

    const handleVoiceSearch = () => {
        // FIX: Cast window to `any` to access non-standard SpeechRecognition properties.
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        if (!SpeechRecognition) {
            showToast('Voice recognition is not supported in your browser.', true);
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.lang = translations.lang_code || 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        recognition.onstart = () => setIsListening(true);
        recognition.onend = () => setIsListening(false);
        recognition.onerror = (event: any) => {
            showToast(translations.voice_error_toast.replace('{error}', event.error), true);
        };
        recognition.onresult = (event: any) => {
            const speechResult = event.results[0][0].transcript;
            setSearchTerm(speechResult);
        };

        try {
            recognition.start();
        } catch(e) {
            showToast(translations.voice_start_error_toast, true);
        }
    };
    
    return (
        <div>
            <div className="mb-6">
                <h1 className="text-3xl font-bold text-gray-800 mb-2">{translations.buyer_page_title}</h1>
                <p className="text-gray-600">{translations.buyer_page_subtitle}</p>
            </div>
            <div className="mb-6 flex items-center">
                <div className="relative w-full">
                    <input 
                        type="text" 
                        placeholder={translations.buyer_search_placeholder}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full p-3 pl-10 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                    <svg className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
                <button onClick={handleVoiceSearch} className={`ml-2 p-3 bg-white border rounded-md text-gray-500 hover:text-green-600 hover:border-green-500 transition-colors ${isListening ? 'bg-red-100 border-red-500' : ''}`} title={translations.buyer_voice_search_title}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line></svg>
                </button>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4 overflow-x-auto pb-4 mb-6">
                {categories.map(cat => (
                    <button 
                        key={cat.id} 
                        onClick={() => setActiveCategory(cat.id)}
                        className={`flex-shrink-0 text-gray-700 font-semibold py-2 px-4 rounded-full transition ${activeCategory === cat.id ? 'bg-green-600 text-white shadow-md' : 'bg-gray-200'}`}
                    >
                        {cat.names[translations.lang_code as keyof typeof cat.names] || cat.names.en}
                    </button>
                ))}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
                {filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} onAddToCart={addToCart} translations={translations} />
                ))}
            </div>
        </div>
    );
};

export default ShopPage;