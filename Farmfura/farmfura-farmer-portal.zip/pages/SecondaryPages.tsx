import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { LocationIcon, PhoneIcon, ProfileIcon, StarIcon } from '../components/Icons';
import { Modal } from '../components/Common';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { allProducts } from '../constants';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export const SubmissionsPage: React.FC = () => {
    const { submissions, t } = useAppContext();
    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-800 mb-6">{t('my_submissions_title')}</h1>
            <div className="space-y-4">
                {submissions.length === 0 ? (
                    <p className="text-center text-gray-500">{t('no_submissions')}</p>
                ) : (
                    submissions.map(sub => (
                        <div key={sub.id} className={`bg-white p-4 rounded-lg shadow-sm border-l-4 ${sub.status === 'Pending' ? 'border-yellow-500' : 'border-green-500'}`}>
                            <p className="font-bold">{t('submission_id')}: {sub.id} ({sub.status})</p>
                            <p className="text-sm text-gray-600">{t('date')}: {new Date(sub.timestamp).toLocaleDateString()}</p>
                            <p className="font-semibold mt-2">{t('total')}: ₹{sub.totalEarnings.toFixed(2)}</p>
                            <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                                {sub.items.map((item, index) => <li key={index}>{item.quantity} {t(`unit_${item.unit}`)} of {item.name}</li>)}
                            </ul>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export const InventoryPage: React.FC = () => {
    const { salesHistory, t } = useAppContext();
    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-800 mb-6">{t('nav_inventory')}</h1>
            <div className="space-y-2">
                {salesHistory.length === 0 ? (
                    <p className="text-center text-gray-500">No transactions recorded yet.</p>
                ) : (
                    [...salesHistory].sort((a,b) => b.date.getTime() - a.date.getTime()).map((item, index) => {
                        const product = allProducts.find(p => p.id === Number(item.productId));
                        if (!product) return null;
                        const isSale = item.type === 'sale';
                        return (
                             <div key={index} className={`bg-white p-4 rounded-lg shadow-sm flex justify-between items-center border-l-4 ${isSale ? 'border-green-400' : 'border-blue-400'}`}>
                                <div>
                                    <p className="font-bold text-gray-800">{product.name} ({isSale ? 'SALE' : 'PURCHASE'})</p>
                                    <p className="text-sm text-gray-600">{item.quantity} {t(`unit_${product.unit}`)} @ {new Date(item.date).toLocaleDateString()}</p>
                                </div>
                                <p className={`font-bold ${isSale ? 'text-green-600' : 'text-blue-600'}`}>₹{(isSale ? item.earnings : item.cost)?.toFixed(2)}</p>
                            </div>
                        )
                    })
                )}
            </div>
        </div>
    );
};

export const ProfilePage: React.FC = () => {
    const { currentUser, farmerId, logout, t, initiateLocationDetection, locationStatus } = useAppContext();
    const [isAnalyticsOpen, setAnalyticsOpen] = useState(false);
    
    const locationText = currentUser?.location
        ? `Lat: ${currentUser.location.lat.toFixed(4)}, Lng: ${currentUser.location.lng.toFixed(4)}`
        : 'Location not set';

    return (
        <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-6">{t('nav_you')}</h1>
            <div className="space-y-4">
                <div className="flex items-center space-x-4">
                    <ProfileIcon className="w-6 h-6 text-gray-500" />
                    <p className="text-lg text-gray-800">{currentUser?.name || farmerId}</p>
                </div>
                 <div className="flex items-center space-x-4">
                    <PhoneIcon className="w-6 h-6 text-gray-500" />
                     <p className="text-lg text-gray-800">{farmerId}</p>
                </div>
                <div className="flex items-start space-x-4">
                    <LocationIcon className="w-6 h-6 text-gray-500 pt-1" />
                     <p className="text-lg text-gray-800">{locationStatus === 'detecting' ? 'Detecting...' : locationText}</p>
                </div>
                <div className="flex items-center space-x-4">
                    <StarIcon className="w-6 h-6 text-yellow-500" />
                    <p className="text-lg text-gray-800">{currentUser?.averageRating.toFixed(1) || '4.5'}</p>
                </div>
            </div>
             <div className="mt-8 border-t pt-6 space-y-4">
                <button onClick={initiateLocationDetection} disabled={locationStatus === 'detecting'} className="w-full text-left font-semibold p-2 rounded-md hover:bg-gray-100">{t('update_location')}</button>
                <button onClick={() => setAnalyticsOpen(true)} className="w-full text-left font-semibold p-2 rounded-md hover:bg-gray-100">{t('view_analytics')}</button>
                <button onClick={logout} className="w-full text-left text-red-600 font-semibold p-2 rounded-md hover:bg-red-50">{t('nav_logout')}</button>
             </div>
             <AnalyticsModal isOpen={isAnalyticsOpen} onClose={() => setAnalyticsOpen(false)} />
        </div>
    );
};

const AnalyticsModal: React.FC<{isOpen: boolean, onClose: () => void}> = ({isOpen, onClose}) => {
    const { salesHistory, t } = useAppContext();
    
    const salesData = {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [
        {
          label: t('monthly_earnings'),
          data: [1200, 1900, 3000, 5000, 2300, 3200], // Mock data
          backgroundColor: 'rgba(22, 163, 74, 0.6)',
        },
      ],
    };

    const topProducts = salesHistory
        .filter(s => s.type === 'sale')
        .reduce((acc, sale) => {
            const product = allProducts.find(p => p.id === Number(sale.productId));
            if(product) {
                acc[product.name] = (acc[product.name] || 0) + sale.quantity;
            }
            return acc;
        }, {} as {[key:string]: number});

    return (
        <Modal isOpen={isOpen} onClose={onClose}>
            <h2 className="text-2xl font-bold mb-6">{t('view_analytics')}</h2>
            <div className="mb-8">
                <h3 className="font-semibold mb-2">{t('monthly_earnings')}</h3>
                <Bar data={salesData} />
            </div>
            <div>
                 <h3 className="font-semibold mb-2">{t('top_selling')}</h3>
                 <div className="space-y-2">
                    {/* FIX: Corrected the sort function to prevent a TypeScript type error. The previous implementation with destructuring was causing type inference issues. */}
                     {Object.entries(topProducts).sort(([, qtyA], [, qtyB]) => qtyB - qtyA).slice(0,5).map(([name, qty]) => (
                         <div key={name} className="flex justify-between p-2 bg-gray-100 rounded">
                             <span>{name}</span>
                             <span className="font-bold">{qty} units</span>
                         </div>
                     ))}
                 </div>
            </div>
        </Modal>
    );
};