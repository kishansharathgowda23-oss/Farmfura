
import React, { useState, useEffect, useContext } from 'react';
import { Job } from '../types';
import { api } from '../services/api';
import { AuthContext, LanguageContext } from '../App';

const TransactionsTab: React.FC = () => {
    const { currentUser } = useContext(AuthContext);
    const { translate, language } = useContext(LanguageContext);
    const [jobs, setJobs] = useState<Job[]>([]);

    useEffect(() => {
        if (currentUser) {
            const completedJobs = api.getCompletedJobs(currentUser.id);
            const sortedJobs = completedJobs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
            setJobs(sortedJobs);
        }
    }, [currentUser]);

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString(language, {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    };

    return (
        <div>
            <h2 className="text-xl font-bold mb-4">{translate('transaction_history')}</h2>
            <div className="space-y-3">
                {jobs.length > 0 ? (
                    jobs.map(job => (
                        <div key={job.id} className="bg-white p-4 rounded-lg shadow-sm">
                            <div className="flex justify-between items-center">
                                <div>
                                    <p className="font-semibold">Order #{job.orderId}</p>
                                    <p className="text-sm text-gray-500">{formatDate(job.date)}</p>
                                </div>
                                <p className="font-bold text-green-600">+ ₹{job.payout}</p>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="text-center text-gray-500 pt-8">{translate('no_transactions')}</p>
                )}
            </div>
        </div>
    );
};

export default TransactionsTab;
