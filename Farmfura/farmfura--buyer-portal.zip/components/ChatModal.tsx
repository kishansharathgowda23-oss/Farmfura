
import React from 'react';

interface ChatModalProps {
    isOpen: boolean;
    onClose: () => void;
    translations: Record<string, string>;
}

const ChatModal: React.FC<ChatModalProps> = ({ isOpen, onClose, translations }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center p-4 z-[110]">
            <div className="bg-white rounded-lg shadow-2xl w-full max-w-md flex flex-col">
                <div className="flex justify-between items-center p-4 border-b">
                    <h2 className="text-lg font-bold text-gray-800">{translations.chat_modal_title}</h2>
                    <button onClick={onClose} className="text-gray-600 hover:text-gray-900 text-2xl font-bold">&times;</button>
                </div>
                <div className="p-4 flex-grow overflow-y-auto h-64">
                    <div className="space-y-4">
                        <div className="flex items-start">
                            <img src="https://picsum.photos/80/80" alt="Carrier Avatar" className="rounded-full mr-2 w-8 h-8" />
                            <div className="bg-gray-200 rounded-xl p-3 max-w-xs text-sm">
                                <p>{translations.chat_modal_default_msg}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="p-4 border-t flex">
                    <input type="text" placeholder={translations.chat_modal_input_placeholder} className="flex-grow p-2 border rounded-md focus:outline-none" />
                    <button className="ml-2 bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">{translations.chat_modal_send_btn}</button>
                </div>
            </div>
        </div>
    );
};

export default ChatModal;
