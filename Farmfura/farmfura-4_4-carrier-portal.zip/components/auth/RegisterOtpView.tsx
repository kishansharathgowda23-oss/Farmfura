
import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useToast } from '../../contexts/ToastContext';

interface RegisterOtpViewProps {
  phone: string;
  onOtpVerified: () => void;
  onBack: () => void;
}

const RegisterOtpView: React.FC<RegisterOtpViewProps> = ({ phone, onOtpVerified, onBack }) => {
  const [otp, setOtp] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const { t } = useLanguage();
  const { showToast } = useToast();

  useEffect(() => {
      // Auto-verify for demo
      setOtp('1234');
      setIsVerifying(true);
      const timer = setTimeout(() => {
          onOtpVerified();
      }, 1500);
      return () => clearTimeout(timer);
      // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp === '1234') {
      onOtpVerified();
    } else {
      showToast('Invalid OTP.');
    }
  };

  return (
    <div className="bg-white p-8 shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{t('register_step_2')}</h2>
      <p className="text-center text-sm text-gray-600 mb-4">{t('otp_sent_to')} <span className="font-semibold">{phone}</span>.</p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          className="w-full p-3 border rounded-md text-center tracking-widest"
          placeholder={t('otp_placeholder')}
          required
          readOnly={isVerifying}
        />
        <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 disabled:opacity-50" disabled={isVerifying}>
          {isVerifying ? t('verifying_otp') : t('verify_otp')}
        </button>
        <button type="button" onClick={onBack} className="w-full bg-gray-200 text-gray-800 font-bold py-3 rounded-md hover:bg-gray-300 mt-2">{t('back')}</button>
      </form>
    </div>
  );
};

export default RegisterOtpView;
