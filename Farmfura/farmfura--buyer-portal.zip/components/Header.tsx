
import React from 'react';

interface HeaderProps {
    isLoggedIn: boolean;
    cartItemCount: number;
    onCartClick: () => void;
    onLogout: () => void;
    onLogoClick: () => void;
    showBack: boolean;
    onBack: () => void;
    language: string;
    onLanguageChange: (lang: string) => void;
}

const Header: React.FC<HeaderProps> = ({ 
    isLoggedIn, cartItemCount, onCartClick, onLogout, onLogoClick, 
    showBack, onBack, language, onLanguageChange 
}) => {
    return (
        <header className="bg-white shadow-sm sticky top-0 z-50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center py-4 relative">
                    <div className="flex items-center">
                         {showBack && (
                            <a href="#" onClick={(e) => { e.preventDefault(); onBack(); }} className="font-semibold text-gray-600 hover:text-green-700 mr-4 whitespace-nowrap">
                                ← Back
                            </a>
                        )}
                        <div className="text-3xl font-bold text-green-700 italic cursor-pointer" onClick={onLogoClick}>
                            🌱 Farmfura
                        </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 sm:space-x-4 ml-auto">
                        <div className="relative">
                            <select value={language} onChange={e => onLanguageChange(e.target.value)} className="block appearance-none w-full bg-white border border-gray-300 hover:border-gray-500 px-4 py-2 pr-8 rounded-md shadow-sm text-sm focus:outline-none focus:ring-green-500 focus:border-green-500">
                                <option value="en">English</option>
                                <option value="kn">ಕನ್ನಡ</option>
                                <option value="hi">हिन्दी</option>
                            </select>
                            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 6.757 7.586 5.343 9z"/></svg>
                            </div>
                        </div>

                        {isLoggedIn && (
                            <>
                                <button onClick={onCartClick} className="relative text-gray-600 hover:text-green-600" title="View Cart">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                                    <span className="absolute -top-2 -right-2 bg-red-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">{cartItemCount}</span>
                                </button>
                                <a href="#" onClick={(e) => { e.preventDefault(); onLogout(); }} className="font-semibold text-red-600 hover:text-red-800">
                                    Logout
                                </a>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
