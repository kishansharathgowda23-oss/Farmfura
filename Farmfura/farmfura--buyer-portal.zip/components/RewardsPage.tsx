
import React from 'react';

interface RewardsPageProps {
    translations: Record<string, string>;
}

const RewardsPage: React.FC<RewardsPageProps> = ({ translations }) => {
    // This is a placeholder. In a real app, this data would come from state/props.
    const farmfuraCoins = 100;
    const coinRewards = [
        { id: 1, description: "50% off delivery fee", cost: 50, active: true },
        { id: 2, description: "10% off total order", cost: 150, active: true },
        { id: 3, description: "Free 1kg of Onions", cost: 80, active: true },
    ];
    const redeemedRewards: number[] = [];

    return (
        <>
            <div className="text-center mb-8">
                <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">{translations.rewards_title}</h1>
                <p className="text-gray-600 max-w-2xl mx-auto">{translations.rewards_subtitle}</p>
            </div>
            <div className="max-w-md mx-auto bg-white p-6 rounded-lg shadow-md mb-8">
                <div className="flex justify-between items-center">
                    <span className="text-lg font-semibold text-gray-700">{translations.your_balance}</span>
                    <span className="text-2xl font-bold text-yellow-600 flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 mr-2"><path d="M12,2C6.486,2,2,6.486,2,12s4.486,10,10,10s10-4.486,10-10S17.514,2,12,2z M12,20c-4.411,0-8-3.589-8-8s3.589-8,8-8 s8,3.589,8,8S16.411,20,12,20z"></path><path d="M12,6c-3.309,0-6,2.691-6,6s2.691,6,6,6s6-2.691,6-6S9.309,6,12,6z M12,16c-2.206,0-4-1.794-4-4s1.794-4,4-4 s4,1.794,4,4S14.206,16,12,16z"></path></svg>
                        {farmfuraCoins}
                    </span>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {coinRewards.filter(r => r.active).map(reward => (
                    <div key={reward.id} className="bg-white rounded-lg shadow-md p-6 flex flex-col justify-between">
                        <div>
                            <p className="font-bold text-lg text-gray-800">{reward.description}</p>
                            <p className="text-indigo-600 font-bold mt-2">{reward.cost} Coins</p>
                        </div>
                        <button 
                            className="mt-4 w-full bg-indigo-600 text-white font-bold py-2 rounded-md hover:bg-indigo-700 transition disabled:bg-gray-400 disabled:cursor-not-allowed" 
                            disabled={farmfuraCoins < reward.cost || redeemedRewards.includes(reward.id)}
                        >
                            {redeemedRewards.includes(reward.id) ? translations.reward_redeemed : translations.redeem_btn}
                        </button>
                    </div>
                ))}
            </div>
        </>
    );
};

export default RewardsPage;
