
import React, { useState, useEffect } from 'react';

interface OrderStatusPageProps {
    onBackToShop: () => void;
    onChat: () => void;
    translations: Record<string, string>;
}

const OrderStatusPage: React.FC<OrderStatusPageProps> = ({ onBackToShop, onChat, translations }) => {
    const [status, setStatus] = useState(0); // 0: Searching, 1: Accepted, 2: On the way, 3: Arrived

    useEffect(() => {
        const interval = setInterval(() => {
            setStatus(prevStatus => {
                if (prevStatus >= 3) {
                    clearInterval(interval);
                    return 3;
                }
                return prevStatus + 1;
            });
        }, 5000);
        return () => clearInterval(interval);
    }, []);

    const getStatusContent = () => {
        switch (status) {
            case 0:
                return {
                    icon: <svg className="w-16 h-16 mx-auto text-yellow-500 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
                    text: translations.delivery_status_waiting,
                    mapStatus: translations.map_loading
                };
            case 1:
                return {
                    icon: <svg className="w-16 h-16 mx-auto text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>,
                    text: translations.delivery_status_accepted,
                    mapStatus: translations.map_eta_10
                };
            case 2:
                return {
                    icon: <svg className="w-16 h-16 mx-auto text-blue-500 animate-pulse" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>,
                    text: translations.delivery_status_on_the_way,
                    mapStatus: translations.map_eta_5
                };
            case 3:
                return {
                    icon: <svg className="w-16 h-16 mx-auto text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>,
                    text: translations.delivery_status_arrived,
                    mapStatus: translations.map_arrived
                };
            default: return { icon: null, text: '', mapStatus: '' };
        }
    };

    const { icon, text, mapStatus } = getStatusContent();

    return (
        <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-md text-center">
            <div className="mb-4">{icon}</div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">{translations.delivery_status_title}</h1>
            <p className="text-gray-600 mb-6">{text}</p>
            
            <div className={`bg-gray-100 p-4 rounded-lg shadow-inner space-y-4 ${status > 0 ? 'block' : 'hidden'}`}>
                <div className="flex items-center space-x-4">
                    <img src="https://picsum.photos/80/80" alt="Carrier Vehicle" className="rounded-full w-16 h-16" />
                    <div className="text-left flex-grow">
                        <h3 className="font-bold text-lg text-green-800 flex items-center">
                            Ravi M.
                            <span className="ml-2 text-sm font-normal text-yellow-500 flex items-center">
                                4.9 <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                            </span>
                        </h3>
                        <p className="text-xs text-gray-500">{translations.carrier_vehicle_label} TVS Jupiter</p>
                    </div>
                </div>
                <div className="relative">
                    <img src="https://i.imgur.com/g1p4e1e.png" alt="Live Map" className="w-full h-48 object-cover rounded-md shadow-sm" />
                    <div className="absolute top-2 left-2 bg-white text-xs font-semibold px-2 py-1 rounded-full shadow-md">{mapStatus}</div>
                </div>
                <button onClick={onChat} className="w-full bg-blue-500 text-white font-bold py-2 rounded-md hover:bg-blue-600 transition">
                    {translations.chat_with_carrier_btn}
                </button>
            </div>
            
            <button onClick={onBackToShop} className="mt-8 bg-green-600 text-white font-bold py-3 px-8 rounded-md hover:bg-green-700 transition">
                {translations.continue_shopping_btn}
            </button>
        </div>
    );
};

export default OrderStatusPage;
