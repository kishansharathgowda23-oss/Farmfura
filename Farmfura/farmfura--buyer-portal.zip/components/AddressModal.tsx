
import React, { useState } from 'react';
import { Address } from '../types';

interface AddressModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (address: Address) => void;
    translations: Record<string, string>;
    showToast: (message: string, isError?: boolean) => void;
}

const AddressModal: React.FC<AddressModalProps> = ({ isOpen, onClose, onSave, translations, showToast }) => {
    const [name, setName] = useState('');
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('');
    const [pin, setPin] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim()) {
            showToast(translations.form_field_required.replace('{fieldName}', 'Full Name'), true);
            return;
        }
        if (!address.trim()) {
            showToast(translations.form_field_required.replace('{fieldName}', 'Address'), true);
            return;
        }
        if (!city.trim()) {
            showToast(translations.form_field_required.replace('{fieldName}', 'City'), true);
            return;
        }
        if (!pin.trim()) {
            showToast(translations.form_field_required.replace('{fieldName}', 'Pin Code'), true);
            return;
        }
        onSave({ id: Date.now(), name, address, city, pin });
        setName(''); setAddress(''); setCity(''); setPin('');
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center p-4 z-[110]">
            <div className="bg-white rounded-lg shadow-2xl w-full max-w-md flex flex-col">
                <div className="flex justify-between items-center p-4 border-b">
                    <h2 className="text-lg font-bold text-gray-800">{translations.address_modal_title}</h2>
                    <button onClick={onClose} className="text-gray-600 hover:text-gray-900 text-2xl font-bold">&times;</button>
                </div>
                <form onSubmit={handleSubmit} className="p-4 space-y-4">
                    <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder={translations.address_modal_name_placeholder} className="w-full p-3 border rounded-md" required />
                    <input type="text" value={address} onChange={e => setAddress(e.target.value)} placeholder={translations.address_modal_address_placeholder} className="w-full p-3 border rounded-md" required />
                    <input type="text" value={city} onChange={e => setCity(e.target.value)} placeholder={translations.address_modal_city_placeholder} className="w-full p-3 border rounded-md" required />
                    <input type="text" value={pin} onChange={e => setPin(e.target.value)} placeholder={translations.address_modal_pin_placeholder} className="w-full p-3 border rounded-md" required />
                    <button type="submit" className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">{translations.address_modal_save_btn}</button>
                </form>
            </div>
        </div>
    );
};

export default AddressModal;
