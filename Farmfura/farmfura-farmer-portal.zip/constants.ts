import { Product, Category } from './types';

// Data Arrays (Vegetables, Fruits, etc.)
export const vegetables: Product[] = [
    { id: 16, name: 'Amaranth leaves', price: 22, farmerPrice: 18, category: 'leafy', unit: 'bundle', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/KISHAN%20D/AMARNATH%20LEAVES.png', names: { kn: 'ದಂಟಿನ ಸೊಪ್ಪು', hi: 'चौलाई' }, inStock: true, type: 'vegetable' },
    { id: 28, name: 'Ash Gourd', price: 30, farmerPrice: 24, category: 'other', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/ash%20ground.jpg', names: { kn: 'ಬೂದುಗುಂಬಳ', hi: 'पेठा' }, inStock: true, type: 'vegetable' },
    { id: 45, name: 'Bamboo Shoot', price: 90, farmerPrice: 72, category: 'other', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/bamboo%20shoot.jpg', names: { kn: 'ಬಿದಿರು ಚಿಗುರು', hi: 'बांस की शाखा' }, inStock: true, type: 'vegetable' },
    { id: 8, name: 'Beans', price: 60, farmerPrice: 48, category: 'other', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/Beans.jpg', names: { kn: 'ಹುರುಳಿಕಾಯಿ', hi: 'फलियां' }, inStock: true, type: 'vegetable' },
    { id: 52, name: 'Beetroot', price: 40, farmerPrice: 32, category: 'root', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/beetroot.jpg', names: { kn: 'ಬೀಟ್ರೂಟ್', hi: 'चुकंदर' }, inStock: true, type: 'vegetable' },
    { id: 26, name: 'Bitter Gourd', price: 50, farmerPrice: 40, category: 'other', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/bitter%20gourd.jpg', names: { kn: 'ಹಾಗಲಕಾಯಿ', hi: 'करेला' }, inStock: true, type: 'vegetable' },
    { id: 24, name: 'Bottle Gourd', price: 35, farmerPrice: 28, category: 'other', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/bottle%20gourd.jpg', names: { kn: 'ಸೋರೆಕಾಯಿ', hi: 'लौकी' }, inStock: true, type: 'vegetable' },
    { id: 6, name: 'Brinjal', price: 35, farmerPrice: 28, category: 'other', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/brinjal.jpg', names: { kn: 'ಬದನೆಕಾಯಿ', hi: 'बैंगन' }, inStock: true, type: 'vegetable' },
    { id: 4, name: 'Carrot', price: 45, farmerPrice: 36, category: 'root', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/carrot.jpg', names: { kn: 'ಕ್ಯಾರೆಟ್', hi: 'गाजर' }, inStock: true, type: 'vegetable' },
    { id: 2, name: 'Potato', price: 25, farmerPrice: 20, category: 'root', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/potato.jpg', names: { kn: 'ಆಲೂಗಡ್ಡೆ', hi: 'आलू' }, inStock: true, type: 'vegetable' },
    { id: 1, name: 'Tomato', price: 30, farmerPrice: 24, category: 'other', unit: 'kg', image: 'https://raw.githubusercontent.com/kishansharathgowda23-oss/farmfura-images./main/KISHAN%20D/tomato.jpg', names: { kn: 'ಟೊಮೆಟೊ', hi: 'टमाटर' }, inStock: true, type: 'vegetable' },
];

export const fruits: Product[] = [
    { id: 1001, name: 'Mango', category: 'tropical', unit: 'kg', farmerPrice: 60, image: 'https://picsum.photos/200/150?random=1', names: { kn: 'ಮಾವು', hi: 'आम' }, type: 'fruit' },
    { id: 1002, name: 'Banana', category: 'tropical', unit: 'kg', farmerPrice: 30, image: 'https://picsum.photos/200/150?random=2', names: { kn: 'ಬಾಳೆಹಣ್ಣು', hi: 'केला' }, type: 'fruit' },
    { id: 1009, name: 'Orange', category: 'citrus', unit: 'kg', farmerPrice: 55, image: 'https://picsum.photos/200/150?random=3', names: { kn: 'ಕಿತ್ತಳೆ', hi: 'संतरा' }, type: 'fruit' },
    { id: 1013, name: 'Grapes', category: 'berry', unit: 'kg', farmerPrice: 70, image: 'https://picsum.photos/200/150?random=4', names: { kn: 'ದ್ರಾಕ್ಷಿ', hi: 'अंगूर' }, type: 'fruit' },
    { id: 1014, name: 'Apple', category: 'temperate', unit: 'kg', farmerPrice: 150, image: 'https://picsum.photos/200/150?random=5', names: { kn: 'ಸೇಬು', hi: 'सेब' }, type: 'fruit' },
];

export const flowers: Product[] = [
    { id: 3001, name: 'Sunflower', category: 'seed', farmerPrice: 15, unit: 'stem', image: 'https://picsum.photos/200/150?random=6', names: { kn: 'ಸೂರ್ಯಕಾಂತಿ', hi: 'सूरजमुखी' }, type: 'flower' },
    { id: 3002, name: 'Marigold', category: 'seed', farmerPrice: 50, unit: 'kg', image: 'https://picsum.photos/200/150?random=7', names: { kn: 'ಚೆಂಡು ಹೂವು', hi: 'गेंदा' }, type: 'flower' },
    { id: 3031, name: 'Rose', category: 'sapling', farmerPrice: 20, unit: 'stem', image: 'https://picsum.photos/200/150?random=8', names: { kn: 'ಗುಲಾಬಿ', hi: 'गुलाब' }, type: 'flower' },
];

export const homemadeProducts: Product[] = [
    { id: 7001, name: 'Mango Pickle', category: 'preserved_fermented', farmerPrice: 150, unit: 'kg', image: 'https://picsum.photos/200/150?random=9', names: { kn: 'ಮಾವಿನ ಉಪ್ಪಿನಕಾಯಿ', hi: 'आम का अचार' }, type: 'home-products' },
    { id: 7002, name: 'Lemon Pickle', category: 'preserved_fermented', farmerPrice: 120, unit: 'kg', image: 'https://picsum.photos/200/150?random=10', names: { kn: 'ನಿಂಬೆ ಉಪ್ಪಿನಕಾಯಿ', hi: 'नींबू का अचार' }, type: 'home-products' },
    { id: 7004, name: 'Mixed Veg Pickle', category: 'preserved_fermented', farmerPrice: 130, unit: 'kg', image: 'https://picsum.photos/200/150?random=11', names: { kn: 'ಮಿಶ್ರ ತರಕಾರಿ ಉಪ್ಪಿನಕಾಯಿ', hi: 'मिक्स वेज अचार' }, type: 'home-products' },
    { id: 7003, name: 'Garlic Pickle', category: 'preserved_fermented', farmerPrice: 180, unit: 'kg', image: 'https://picsum.photos/200/150?random=12', names: { kn: 'ಬೆಳ್ಳುಳ್ಳಿ ಉಪ್ಪಿನಕಾಯಿ', hi: 'लहसुन का अचार' }, type: 'home-products' },
    { id: 7020, name: 'Green Chilli Pickle', category: 'preserved_fermented', farmerPrice: 110, unit: 'kg', image: 'https://picsum.photos/200/150?random=13', names: { kn: 'ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ಉಪ್ಪಿನಕಾಯಿ', hi: 'हरी मिर्च का अचार' }, type: 'home-products' },
];


const saplingPrice = (farmerPrice = 0) => {
    const price = Math.round(farmerPrice / 4);
    return price > 0 ? price : 1;
};

export const allProduce = [...vegetables, ...fruits, ...flowers, ...homemadeProducts].sort((a, b) => a.name.localeCompare(b.name)).map(p => ({...p, sellPrice: p.farmerPrice || p.price, buyPrice: (p.price || p.farmerPrice || 0) * 1.2 }));

const vegetableSaplings = vegetables.map((v, i) => ({
    id: 4000 + i, name: `${v.name} Sapling`, category: 'vegetable_sapling', unit: 'piece', sellPrice: saplingPrice(v.farmerPrice), buyPrice: saplingPrice(v.farmerPrice) * 1.5, image: v.image, names: { kn: `${v.names.kn} ಸಸಿ`, hi: `${v.names.hi} का पौधा` }, type: 'seed'
} as Product));

const fruitSaplings = fruits.map((f, i) => ({
    id: 5000 + i, name: `${f.name} Sapling`, category: 'fruit_sapling', unit: 'piece', sellPrice: saplingPrice(f.farmerPrice), buyPrice: saplingPrice(f.farmerPrice) * 1.5, image: f.image, names: { kn: `${f.names.kn} ಸಸಿ`, hi: `${f.names.hi} का पौधा` }, type: 'seed'
} as Product));

const flowerSeeds = flowers.filter(f => f.category === 'seed' || f.category === 'both').map((f, i) => ({
    id: 10000 + i, name: `${f.name} Seeds`, category: 'flower_seed', unit: 'packet', sellPrice: saplingPrice(f.farmerPrice), buyPrice: saplingPrice(f.farmerPrice) * 1.2, image: f.image, names: { kn: `${f.names.kn} ಬೀಜಗಳು`, hi: `${f.names.hi} के बीज`}, type: 'seed'
} as Product));

const flowerSaplings = flowers.filter(f => f.category === 'sapling' || f.category === 'both').map((f, i) => ({
    id: 11000 + i, name: `${f.name} Sapling`, category: 'flower_sapling', unit: 'piece', sellPrice: saplingPrice(f.farmerPrice) * 2, buyPrice: saplingPrice(f.farmerPrice) * 2.5, image: f.image, names: { kn: `${f.names.kn} ಸಸಿ`, hi: `${f.names.hi} का पौधा`}, type: 'seed'
} as Product));


export const seeds = [
    { id: 2004, name: 'Maize (Corn)', category: 'cereal', unit: 'kg', sellPrice: 20, buyPrice: 28, image: 'https://picsum.photos/200/150?random=15', names: { kn: 'ಮೆಕ್ಕೆ ಜೋಳ', hi: 'मक्का' }, type: 'seed' },
    { id: 2006, name: 'Ragi (Finger Millet)', category: 'cereal', unit: 'kg', sellPrice: 40, buyPrice: 55, image: 'https://picsum.photos/200/150?random=16', names: { kn: 'ರಾಗಿ', hi: 'रागी' }, type: 'seed' },
] as Product[];

const organicPesticides: Product[] = [
    { id: 6001, name: 'Cow Dung', category: 'organic_pesticide', unit: 'kg', sellPrice: 5, buyPrice: 8, image: 'https://picsum.photos/200/150?random=19', names: { kn: 'ಸಗಣಿ', hi: 'गोबर' }, type: 'farm_supply' },
    { id: 6002, name: 'Cow Urine', category: 'organic_pesticide', unit: 'Litre', sellPrice: 10, buyPrice: 15, image: 'https://picsum.photos/200/150?random=20', names: { kn: 'ಗೋಮೂತ್ರ', hi: 'गोमूत्र' }, type: 'farm_supply' }
];

export const inorganicPesticides: Product[] = [
    { id: 6003, name: 'Urea (46% N)', category: 'inorganic_fertilizer', unit: 'kg', buyPrice: 30, image: 'https://picsum.photos/200/150?random=17', names: { kn: 'ಯೂರಿಯಾ', hi: 'यूरिया' }, type: 'farm_supply' },
    { id: 6004, name: 'DAP (18-46-0)', category: 'inorganic_fertilizer', unit: 'kg', buyPrice: 60, image: 'https://picsum.photos/200/150?random=18', names: { kn: 'ಡಿಎಪಿ', hi: 'डीएपी' }, type: 'farm_supply' },
];

export const allSupplies: Product[] = [...seeds, ...vegetableSaplings, ...fruitSaplings, ...flowerSeeds, ...flowerSaplings, ...organicPesticides, ...inorganicPesticides];
export const allProducts: Product[] = [...allProduce, ...allSupplies];

export const categories: { sell: Category[]; buy: Category[]; sub: Category[] } = {
    sell: [
        { id: 'all', names: { en: 'All Produce', kn: 'ಎಲ್ಲಾ ಉತ್ಪನ್ನ', hi: 'सभी उपज' }, type: 'primary' },
        { id: 'vegetable', names: { en: 'Vegetables', kn: 'ತರಕಾರಿಗಳು', hi: 'सब्जियां' }, type: 'primary' },
        { id: 'fruit', names: { en: 'Fruits', kn: 'ಹಣ್ಣುಗಳು', hi: 'फल' }, type: 'primary' },
        { id: 'flower', names: { en: 'Flowers', kn: 'ಹೂವುಗಳು', hi: 'फूल' }, type: 'primary' },
        { id: 'home-products', names: { en: 'Home Products', kn: 'ಮನೆ ಉತ್ಪನ್ನಗಳು', hi: 'घर के उत्पाद' }, type: 'primary' },
    ],
    buy: [
        { id: 'all', names: { en: 'All Supplies', kn: 'ಎಲ್ಲಾ ಸರಬರಾಜು', hi: 'सभी आपूर्ति' }, type: 'primary' },
        { id: 'seed', names: { en: 'Seed & Sapling', kn: 'ಬೀಜ ಮತ್ತು ಸಸಿ', hi: 'बीज और पौधे' }, type: 'primary' },
        { id: 'farm_supply', names: { en: 'Fertilizers & Pesticides', kn: 'ಗೊಬ್ಬರಗಳು ಮತ್ತು ಕೀಟನಾಶಕಗಳು', hi: 'उर्वरक और कीटनाशक' }, type: 'primary' },
    ],
    sub: []
};

export const translations: { [key: string]: { [key: string]: string } } = {
    en: { 
        nav_dashboard: 'Dashboard', nav_my_submissions: 'Submissions', nav_you: 'You', nav_logout: 'Logout', nav_inventory: 'History', nav_cart: 'Cart',
        seller_dashboard_title: 'Seller Dashboard', buyer_dashboard_title: 'Buyer Dashboard',
        farmer_dashboard_subtitle: 'Update your available produce quantity.', buyer_dashboard_subtitle: 'Find seeds, saplings, and farming supplies.',
        detect_location_btn: 'Detect Farm Location', detect_home_location_btn: 'Detect Home Location', farmer_total_earnings: 'Total Potential Earnings:',
        farmer_submit_btn: 'Submit Availability', my_submissions_title: 'My Submissions (Sell)', no_submissions: 'You have not submitted any availability yet.',
        pickup_status_title: 'Pickup Status', pickup_status_waiting: 'Searching for a carrier...',
        back_to_dashboard_btn: 'Back to Dashboard',
        unit_kg: 'kg', unit_bundle: 'bundle', unit_piece: 'piece', unit_Litre: 'Litre', unit_stem: 'stem', unit_bunch: 'bunch', unit_packet: 'packet', unit_flower: 'flower',
        pickup_message_success: 'Availability submitted!', pickup_status_accepted: 'Carrier assigned! On the way.', pickup_status_arrived: 'Carrier has arrived.',
        request_price_change: 'Request Price', current_price: 'Current Price', new_requested_price: 'New Requested Price', submit_request: 'Submit',
        request_sent: 'Price request for {productName} sent.', invalid_price: 'New price must be higher.', cancel: 'Cancel',
        enter_quantity: 'Enter Quantity', total_amount: 'Total Amount', add_to_submission_btn: 'Add to Cart',
        added_to_submission: '{quantity} {unit} of {productName} added to cart',
        add_quantity_btn: 'Add Quantity', buy_now_btn: 'Buy Now', sell_btn: 'Sell', sell_price: 'Sell Price', buy_price: 'Buy Price',
        purchase_redirect: 'Redirecting to purchase page...', confirm_purchase_title: 'Confirm Purchase', confirm_purchase_btn: 'Confirm',
        quantity: 'Quantity', delivery_address: 'Delivery Address', purchase_confirmed: 'Purchase confirmed!',
        login_quote: '"To farm is to be a student of nature, a steward of the land, and a provider for the community."',
        farmer_login_title: 'Farmer Login', phone_number_label: 'Phone Number', otp_label: 'Enter OTP', send_otp_btn: 'Send OTP', verify_login_btn: 'Verify & Login',
        welcome_title: 'Welcome to Farmfura!', enter_name_prompt: 'Please enter your name.', name_label: 'Your Name', complete_registration_btn: 'Complete Registration',
        all: 'All', submission_id: 'Submission ID', date: 'Date', total: 'Total',
        how_it_was_made: "How was this made?", making_placeholder: "Describe the ingredients and process...", upload_photos_videos: "Upload Photos/Videos",
        search_placeholder: 'Search for produce or supply...', phone_placeholder: 'Enter 10-digit phone number',
        otp_sent_toast: 'OTP Sent to {phone}', invalid_otp_toast: 'Invalid OTP.', otp_auto_filling: 'OTP Received: {otp}. Auto-filling...',
        invalid_phone_toast: 'Please enter a valid 10-digit phone number.', add_item_toast: 'Please add at least one item.',
        view_analytics: 'View Analytics', monthly_earnings: 'Monthly Earnings', top_selling: 'Top Selling Products',
        chat_with_driver: 'Chat with Driver', type_message: 'Type a message...',
        mode_sell: 'Seller Dashboard', mode_buy: 'Buyer Dashboard',
        switch_mode: 'Switch Mode', cart_title_sell: 'Availability Cart (Sell)', cart_title_buy: 'Purchase Cart (Buy)',
        cart_total_buy: 'Total Cost:', cart_submit_buy: 'Place Order', cart_submit_sell: 'Submit Availability',
        order_confirmed: 'Order placed!',
        analyze_recipe: 'Analyze Recipe', analyzing: 'Analyzing...', analysis_result: 'Analysis Result',
        update_location: 'Update Location',
        location_permission_title: "Location Access Required",
        location_permission_prompt_desc: "To automatically detect your farm or delivery address, Farmfura needs access to your device's location. Please click 'Allow Access' and then 'Allow' in the browser prompt.",
        location_permission_denied_desc: "Location access is blocked. To use this feature, please enable location permissions for this site in your browser settings.",
        location_allow_access: "Allow Access",
        close: "Close",
    },
    kn: { 
        nav_dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್', nav_my_submissions: 'ಸಲ್ಲಿಕೆಗಳು', nav_you: 'ನೀವು', nav_logout: 'ಲಾಗ್ ಔಟ್', nav_inventory: 'ಇತಿಹಾಸ', nav_cart: 'ಕಾರ್ಟ್',
        seller_dashboard_title: 'ಮಾರಾಟಗಾರ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್', buyer_dashboard_title: 'ಖರೀದಿದಾರ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
        farmer_dashboard_subtitle: 'ನಿಮ್ಮ ಲಭ್ಯವಿರುವ ಉತ್ಪನ್ನದ ಪ್ರಮಾಣವನ್ನು ನವೀಕರಿಸಿ.', buyer_dashboard_subtitle: 'ಬೀಜಗಳು, ಸಸಿಗಳು ಮತ್ತು ಕೃಷಿ ಸಾಮಗ್ರಿಗಳನ್ನು ಹುಡುಕಿ.',
        detect_location_btn: 'ಕೃಷಿ ಸ್ಥಳವನ್ನು ಪತ್ತೆ ಮಾಡಿ', detect_home_location_btn: 'ಮನೆ ಸ್ಥಳವನ್ನು ಪತ್ತೆ ಮಾಡಿ', farmer_total_earnings: 'ಒಟ್ಟು ಸಂಭಾವ್ಯ ಗಳಿಕೆಗಳು:',
        farmer_submit_btn: 'ಲಭ್ಯತೆಯನ್ನು ಸಲ್ಲಿಸಿ', my_submissions_title: 'ನನ್ನ ಸಲ್ಲಿಕೆಗಳು (ಮಾರಾಟ)', no_submissions: 'ನೀವು ಇನ್ನೂ ಯಾವುದೇ ಲಭ್ಯತೆಯನ್ನು ಸಲ್ಲಿಸಿಲ್ಲ.',
        pickup_status_title: 'ಪಿಕಪ್ ಸ್ಥಿತಿ', pickup_status_waiting: 'ವಾಹಕಕ್ಕಾಗಿ ಹುಡುಕಲಾಗುತ್ತಿದೆ...',
        back_to_dashboard_btn: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ಗೆ ಹಿಂತಿರುಗಿ',
        unit_kg: 'ಕೆಜಿ', unit_bundle: 'ಕಟ್ಟು', unit_piece: 'ಪೀಸ್', unit_Litre: 'ಲೀಟರ್', unit_stem: 'ಕಾಂಡ', unit_bunch: 'ಗುಂಪು', unit_packet: 'ಪ್ಯಾಕೆಟ್', unit_flower: 'ಹೂವು',
        pickup_message_success: 'ಲಭ್ಯತೆಯನ್ನು ಸಲ್ಲಿಸಲಾಗಿದೆ!', pickup_status_accepted: 'ವಾಹಕವನ್ನು ನಿಯೋಜಿಸಲಾಗಿದೆ! ದಾರಿಯಲ್ಲಿದೆ.', pickup_status_arrived: 'ವಾಹಕವು ತಲುಪಿದೆ.',
        request_price_change: 'ಬೆಲೆ ವಿನಂತಿಸಿ', current_price: 'ಪ್ರಸ್ತುತ ಬೆಲೆ', new_requested_price: 'ಹೊಸ ವಿನಂತಿಸಿದ ಬೆಲೆ', submit_request: 'ಸಲ್ಲಿಸಿ',
        request_sent: '{productName} ಗಾಗಿ ಬೆಲೆ ವಿನಂತಿಯನ್ನು ಕಳುಹಿಸಲಾಗಿದೆ.', invalid_price: 'ಹೊಸ ಬೆಲೆ ಹೆಚ್ಚಾಗಿರಬೇಕು.', cancel: 'ರದ್ದುಮಾಡು',
        enter_quantity: 'ಪ್ರಮಾಣವನ್ನು ನಮೂದಿಸಿ', total_amount: 'ಒಟ್ಟು ಮೊತ್ತ', add_to_submission_btn: 'ಕಾರ್ಟ್‌ಗೆ ಸೇರಿಸಿ',
        added_to_submission: '{productName} ನ {quantity} {unit} ಕಾರ್ಟ್‌ಗೆ ಸೇರಿಸಲಾಗಿದೆ',
        add_quantity_btn: 'ಪ್ರಮಾಣವನ್ನು ಸೇರಿಸಿ', buy_now_btn: 'ಈಗ ಖರೀದಿಸಿ', sell_btn: 'ಮಾರಾಟ', sell_price: 'ಮಾರಾಟದ ಬೆಲೆ', buy_price: 'ಖರೀದಿ ಬೆಲೆ',
        purchase_redirect: 'ಖರೀದಿ ಪುಟಕ್ಕೆ ಮರುನಿರ್ದೇಶಿಸಲಾಗುತ್ತಿದೆ...', confirm_purchase_title: 'ಖರೀದಿಯನ್ನು ದೃಢೀಕರಿಸಿ', confirm_purchase_btn: 'ದೃಢೀಕರಿಸಿ',
        quantity: 'ಪ್ರಮಾಣ', delivery_address: 'ವಿತರಣಾ ವಿಳಾಸ', purchase_confirmed: 'ಖರೀದಿ ದೃಢೀಕರಿಸಲಾಗಿದೆ!',
        login_quote: '"ಕೃಷಿ ಮಾಡುವುದು ಪ್ರಕೃತಿಯ ವಿದ್ಯಾರ್ಥಿಯಾಗುವುದು, ಭೂಮಿಯ ಪಾಲಕರಾಗುವುದು ಮತ್ತು ಸಮುದಾಯಕ್ಕೆ ಒದಗಿಸುವವರಾಗುವುದು."',
        farmer_login_title: 'ರೈತರ ಲಾಗಿನ್', phone_number_label: 'ದೂರವಾಣಿ ಸಂಖ್ಯೆ', otp_label: 'ಒಟಿಪಿ ನಮೂದಿಸಿ', send_otp_btn: 'ಒಟಿಪಿ ಕಳುಹಿಸಿ', verify_login_btn: 'ಪರಿಶೀಲಿಸಿ ಮತ್ತು ಲಾಗಿನ್ ಮಾಡಿ',
        welcome_title: 'ಫಾರ್ಮ್‌ಫುರಾಗೆ ಸುಸ್ವಾಗತ!', enter_name_prompt: 'ದಯವಿಟ್ಟು ನಿಮ್ಮ ಹೆಸರನ್ನು ನಮೂದಿಸಿ.', name_label: 'ನಿಮ್ಮ ಹೆಸರು', complete_registration_btn: 'ನೋಂದಣಿ ಪೂರ್ಣಗೊಳಿಸಿ',
        all: 'ಎಲ್ಲಾ', submission_id: 'ಸಲ್ಲಿಕೆ ಐಡಿ', date: 'ದಿನಾಂಕ', total: 'ಒಟ್ಟು',
        how_it_was_made: "ಇದನ್ನು ಹೇಗೆ ಮಾಡಲಾಯಿತು?", making_placeholder: "ಪದಾರ್ಥಗಳು ಮತ್ತು ಪ್ರಕ್ರಿಯೆಯನ್ನು ವಿವರಿಸಿ...", upload_photos_videos: "ಫೋಟೋಗಳು/ವೀಡಿಯೊಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ",
        search_placeholder: 'ಉತ್ಪನ್ನ ಅಥವಾ ಸರಬರಾಜುಗಾಗಿ ಹುಡುಕಿ...', phone_placeholder: '10-ಅಂಕಿಯ ಫೋನ್ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ',
        otp_sent_toast: '{phone} ಗೆ OTP ಕಳುಹಿಸಲಾಗಿದೆ', invalid_otp_toast: 'ಅಮಾನ್ಯ OTP.', otp_auto_filling: 'OTP ಸ್ವೀಕರಿಸಲಾಗಿದೆ: {otp}. ಸ್ವಯಂ-ಭರ್ತಿ ಮಾಡಲಾಗುತ್ತಿದೆ...',
        invalid_phone_toast: 'ದಯವಿಟ್ಟು ಮಾನ್ಯ 10-ಅಂಕಿಯ ಫೋನ್ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ.', add_item_toast: 'ದಯವಿಟ್ಟು ಕನಿಷ್ಠ ಒಂದು ಐಟಂ ಸೇರಿಸಿ.',
        view_analytics: 'ವಿಶ್ಲೇಷಣೆ ವೀಕ್ಷಿಸಿ', monthly_earnings: 'ಮಾಸಿಕ ಗಳಿಕೆಗಳು', top_selling: 'ಅತ್ಯುತ್ತಮ ಮಾರಾಟದ ಉತ್ಪನ್ನಗಳು',
        chat_with_driver: 'ಚಾಲಕರೊಂದಿಗೆ ಚಾಟ್ ಮಾಡಿ', type_message: 'ಸಂದೇಶವನ್ನು ಟೈಪ್ ಮಾಡಿ...',
        mode_sell: 'ಮಾರಾಟಗಾರ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್', mode_buy: 'ಖರೀದಿದಾರ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
        switch_mode: 'ಮೋಡ್ ಬದಲಾಯಿಸಿ', cart_title_sell: 'ಲಭ್ಯತೆ ಕಾರ್ಟ್ (ಮಾರಾಟ)', cart_title_buy: 'ಖರೀದಿ ಕಾರ್ಟ್ (ಖರೀದಿ)',
        cart_total_buy: 'ಒಟ್ಟು ವೆಚ್ಚ:', cart_submit_buy: 'ಆರ್ಡರ್ ನೀಡಿ', cart_submit_sell: 'ಲಭ್ಯತೆಯನ್ನು ಸಲ್ಲಿಸಿ',
        order_confirmed: 'ಆರ್ಡರ್ ದೃಢೀಕರಿಸಲಾಗಿದೆ!',
        analyze_recipe: 'ಪಾಕವಿಧಾನವನ್ನು ವಿಶ್ಲೇಷಿಸಿ', analyzing: 'ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...', analysis_result: 'ವಿಶ್ಲೇಷಣೆ ಫಲಿತಾಂಶ',
        update_location: 'ಸ್ಥಳವನ್ನು ನವೀಕರಿಸಿ',
        location_permission_title: "ಸ್ಥಳ ಪ್ರವೇಶದ ಅಗತ್ಯವಿದೆ",
        location_permission_prompt_desc: "ನಿಮ್ಮ ಫಾರ್ಮ್ ಅಥವಾ ವಿತರಣಾ ವಿಳಾಸವನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಪತ್ತೆಹಚ್ಚಲು, ಫಾರ್ಮ್‌ಫುರಾಗೆ ನಿಮ್ಮ ಸಾಧನದ ಸ್ಥಳಕ್ಕೆ ಪ್ರವೇಶದ ಅಗತ್ಯವಿದೆ. ದಯವಿಟ್ಟು 'ಪ್ರವೇಶವನ್ನು ಅನುಮತಿಸಿ' ಕ್ಲಿಕ್ ಮಾಡಿ ಮತ್ತು ನಂತರ ಬ್ರೌಸರ್ ಪ್ರಾಂಪ್ಟ್‌ನಲ್ಲಿ 'ಅನುಮತಿಸಿ' ಕ್ಲಿಕ್ ಮಾಡಿ.",
        location_permission_denied_desc: "ಸ್ಥಳ ಪ್ರವೇಶವನ್ನು ನಿರ್ಬಂಧಿಸಲಾಗಿದೆ. ಈ ವೈಶಿಷ್ಟ್ಯವನ್ನು ಬಳಸಲು, ದಯವಿಟ್ಟು ನಿಮ್ಮ ಬ್ರೌಸರ್ ಸೆಟ್ಟಿಂಗ್‌ಗಳಲ್ಲಿ ಈ ಸೈಟ್‌ಗೆ ಸ್ಥಳ ಅನುಮತಿಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿ.",
        location_allow_access: "ಪ್ರವೇಶವನ್ನು ಅನುಮತಿಸಿ",
        close: "ಮುಚ್ಚಿ",
    },
    hi: { 
        nav_dashboard: 'डैशबोर्ड', nav_my_submissions: 'सबमिशन', nav_you: 'आप', nav_logout: 'लॉग आउट', nav_inventory: 'इन्वेंटरी', nav_cart: 'कार्ट',
        seller_dashboard_title: 'विक्रेता डैशबोर्ड', buyer_dashboard_title: 'खरीददार डैशबोर्ड',
        farmer_dashboard_subtitle: 'अपनी उपलब्ध उपज की मात्रा को अपडेट करें।', buyer_dashboard_subtitle: 'बीज, पौधे और खेती की आपूर्ति खोजें।',
        detect_location_btn: 'खेत का स्थान पता लगाएं', detect_home_location_btn: 'घर का स्थान पता लगाएं', farmer_total_earnings: 'कुल संभावित कमाई:',
        farmer_submit_btn: 'उपलब्धता जमा करें', my_submissions_title: 'मेरे सबमिशन (बेचें)', no_submissions: 'आपने अभी तक कोई उपलब्धता सबमिट नहीं की है।',
        pickup_status_title: 'पिकअप स्थिति', pickup_status_waiting: 'वाहक की खोज की जा रही है...',
        back_to_dashboard_btn: 'डैशबोर्ड पर वापस जाएं',
        unit_kg: 'किग्रा', unit_bundle: 'बंडल', unit_piece: 'पीस', unit_Litre: 'लीटर', unit_stem: 'तना', unit_bunch: 'गुच्छा', unit_packet: 'पैकेट', unit_flower: 'फूल',
        pickup_message_success: 'उपलब्धता सबमिट की गई!', pickup_status_accepted: 'वाहक सौंपा गया! रास्ते में।', pickup_status_arrived: 'वाहक आ गया है।',
        request_price_change: 'कीमत का अनुरोध करें', current_price: 'वर्तमान मूल्य', new_requested_price: 'नया अनुरोधित मूल्य', submit_request: 'भेजें',
        request_sent: '{productName} के लिए मूल्य अनुरोध भेजा गया।', invalid_price: 'नया मूल्य अधिक होना चाहिए।', cancel: 'रद्द करें',
        enter_quantity: 'मात्रा दर्ज करें', total_amount: 'कुल राशि', add_to_submission_btn: 'कार्ट में जोड़ें',
        added_to_submission: '{productName} का {quantity} {unit} कार्ट में जोड़ा गया',
        add_quantity_btn: 'मात्रा जोड़ें', buy_now_btn: 'अभी खरीदें', sell_btn: 'बेचें', sell_price: 'बिक्री मूल्य', buy_price: 'खरीद मूल्य',
        purchase_redirect: 'खरीद पृष्ठ पर रीडायरेक्ट किया जा रहा है...', confirm_purchase_title: 'खरीद की पुष्टि करें', confirm_purchase_btn: 'पुष्टि करें',
        quantity: 'मात्रा', delivery_address: 'वितरण पता', purchase_confirmed: 'खरीद की पुष्टि हुई!',
        login_quote: '"खेती करना प्रकृति का छात्र बनना, भूमि का संरक्षक बनना और समुदाय के लिए प्रदाता बनना है।"',
        farmer_login_title: 'किसान लॉगिन', phone_number_label: 'फ़ोन नंबर', otp_label: 'ओटीपी दर्ज करें', send_otp_btn: 'ओटीपी भेजें', verify_login_btn: 'सत्यापित करें और लॉगिन करें',
        welcome_title: 'फार्मफुरा में आपका स्वागत है!', enter_name_prompt: 'कृपया अपना नाम दर्ज करें।', name_label: 'आपका नाम', complete_registration_btn: 'पंजीकरण पूरा करें',
        all: 'सभी', submission_id: 'सबमिशन आईडी', date: 'तारीख', total: 'कुल',
        how_it_was_made: "यह कैसे बनाया गया था?", making_placeholder: "सामग्री और प्रक्रिया का वर्णन करें...", upload_photos_videos: "फ़ोटो/वीडियो अपलोड करें",
        search_placeholder: 'उपज या आपूर्ति के लिए खोजें...', phone_placeholder: '10 अंकों का फ़ोन नंबर दर्ज करें',
        otp_sent_toast: '{phone} पर OTP भेजा गया', invalid_otp_toast: 'अमान्य OTP।', otp_auto_filling: 'OTP प्राप्त हुआ: {otp}. स्वतः भरा जा रहा है...',
        invalid_phone_toast: 'कृपया एक वैध 10-अंकीय फ़ोन नंबर दर्ज करें।', add_item_toast: 'कृपया कम से कम एक आइटम जोड़ें।',
        view_analytics: 'एनालिटिक्स देखें', monthly_earnings: 'मासिक कमाई', top_selling: 'शीर्ष बिकने वाले उत्पाद',
        chat_with_driver: 'ड्राइवर से चैट करें', type_message: 'एक संदेश लिखें...',
        mode_sell: 'विक्रेता डैशबोर्ड', mode_buy: 'खरीददार डैशबोर्ड',
        switch_mode: 'मोड बदलें', cart_title_sell: 'उपलब्धता कार्ट (बेचें)', cart_title_buy: 'खरीद कार्ट (खरीदें)',
        cart_total_buy: 'कुल लागत:', cart_submit_buy: 'ऑर्डर दें', cart_submit_sell: 'उपलब्धता जमा करें',
        order_confirmed: 'ऑर्डर की पुष्टि हुई!',
        analyze_recipe: 'नुस्खा का विश्लेषण करें', analyzing: 'विश्लेषण हो रहा है...', analysis_result: 'विश्लेषण परिणाम',
        update_location: 'स्थान अपडेट करें',
        location_permission_title: "स्थान पहुंच आवश्यक है",
        location_permission_prompt_desc: "आपके खेत या डिलीवरी पते का स्वचालित रूप से पता लगाने के लिए, फार्मफुरा को आपके डिवाइस के स्थान तक पहुंचने की आवश्यकता है। कृपया 'पहुंच की अनुमति दें' पर क्लिक करें और फिर ब्राउज़र प्रॉम्प्ट में 'अनुमति दें' पर क्लिक करें।",
        location_permission_denied_desc: "स्थान पहुंच अवरुद्ध है। इस सुविधा का उपयोग करने के लिए, कृपया अपनी ब्राउज़र सेटिंग्स में इस साइट के लिए स्थान अनुमतियों को सक्षम करें।",
        location_allow_access: "पहुंच की अनुमति दें",
        close: "बंद करें",
    }
};