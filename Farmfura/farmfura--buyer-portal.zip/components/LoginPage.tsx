
import React, { useState } from 'react';
import { User } from '../types';

interface LoginPageProps {
    onLoginSuccess: (user: User) => void;
    translations: Record<string, string>;
    showToast: (message: string, isError?: boolean) => void;
}

type LoginStep = 'credential' | 'password' | 'otp';

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess, translations, showToast }) => {
    const [step, setStep] = useState<LoginStep>('credential');
    const [credential, setCredential] = useState('');
    const [password, setPassword] = useState('');
    const [otp, setOtp] = useState('');
    const [isPasswordVisible, setIsPasswordVisible] = useState(false);
    
    const handleContinue = () => {
        const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(credential);
        const isPhone = /^\d{10}$/.test(credential);
        
        if (isEmail) {
            setStep('password');
        } else if (isPhone) {
            setStep('otp');
            setTimeout(() => {
                showToast(translations.otp_sent_toast.replace('{credential}', credential));
                setOtp('1234'); // Demo OTP
            }, 500);
        } else {
            showToast(translations.invalid_login_toast, true);
        }
    };

    const handleLogin = () => {
        if (password) {
            onLoginSuccess({ loginCredential: credential, name: 'Valued Customer' });
        } else {
            showToast(translations.invalid_password_toast, true);
        }
    };

    const handleOtpVerify = () => {
        if (otp === '1234') {
            onLoginSuccess({ loginCredential: credential, name: 'Valued Customer' });
        } else {
            showToast(translations.invalid_otp_toast, true);
        }
    };
    
    const renderStep = () => {
        switch(step) {
            case 'password':
                return (
                    <div className="bg-white p-8 rounded-2xl shadow-lg text-center">
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">{translations.login_password_title}</h2>
                        <p className="text-gray-600 mb-6">{translations.login_password_subtitle}</p>
                        <div className="space-y-4">
                            <div className="relative">
                                <input 
                                    type={isPasswordVisible ? 'text' : 'password'}
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder={translations.login_password_placeholder}
                                    className="w-full p-3 border rounded-md text-center focus:outline-none focus:ring-2 focus:ring-green-500 pr-10" 
                                />
                                <button type="button" onClick={() => setIsPasswordVisible(!isPasswordVisible)} className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                                    {isPasswordVisible ? (
                                        <svg className="h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.542-7 1.274-4.057 5.064 7-9.542-7 .847 0 1.673.124 2.468.352M4 4l16 16" /></svg>
                                    ) : (
                                        <svg className="h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                    )}
                                </button>
                            </div>
                            <button onClick={handleLogin} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">{translations.login_login_btn}</button>
                        </div>
                    </div>
                );
            case 'otp':
                return (
                     <div className="bg-white p-8 rounded-2xl shadow-lg text-center">
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">{translations.login_otp_title}</h2>
                        <p className="text-gray-600 mb-6">{translations.login_otp_subtitle}</p>
                        <div className="space-y-4">
                            <div>
                                <label htmlFor="otp-input" className="sr-only">{translations.login_otp_label}</label>
                                <input type="text" id="otp-input" value={otp} onChange={(e) => setOtp(e.target.value)} className="w-full p-3 border rounded-md text-center bg-gray-100 focus:outline-none" />
                            </div>
                            <button onClick={handleOtpVerify} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">{translations.login_verify_btn}</button>
                        </div>
                    </div>
                );
            default: // credential
                return (
                    <div className="bg-white p-8 rounded-2xl shadow-lg text-center">
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">{translations.login_welcome_title}</h2>
                        <p className="text-gray-600 mb-6">{translations.login_welcome_subtitle}</p>
                        <div className="space-y-4">
                            <input 
                                type="text"
                                value={credential}
                                onChange={(e) => setCredential(e.target.value)}
                                placeholder={translations.login_credential_placeholder}
                                className="w-full p-3 border rounded-md text-center focus:outline-none focus:ring-2 focus:ring-green-500" 
                            />
                            <button onClick={handleContinue} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition">{translations.login_continue_btn}</button>
                        </div>
                    </div>
                );
        }
    };

    return (
        <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-md w-full space-y-8">
                {renderStep()}
            </div>
        </div>
    );
};

export default LoginPage;
