
import React, { useState, useEffect, createContext, useContext } from 'react';
import { Auth } from './components/Auth';
import { MainApp } from './components/MainApp';
import { Toast } from './components/Toast';
import { initMockData } from './services/storageService';
import type { User, ToastMessage } from './types';

// --- Theme Context for High Contrast Mode ---
interface ThemeContextType {
    isHighContrast: boolean;
    toggleHighContrast: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
    const context = useContext(ThemeContext);
    if (!context) throw new Error("useTheme must be used within a ThemeProvider");
    return context;
};

const ThemeProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
    const [isHighContrast, setIsHighContrast] = useState(() => {
        return localStorage.getItem('farmfura_high_contrast') === 'true';
    });

    useEffect(() => {
        if (isHighContrast) {
            document.documentElement.classList.add('high-contrast');
        } else {
            document.documentElement.classList.remove('high-contrast');
        }
        localStorage.setItem('farmfura_high_contrast', String(isHighContrast));
    }, [isHighContrast]);

    const toggleHighContrast = () => {
        setIsHighContrast(prev => !prev);
    };

    return (
        <ThemeContext.Provider value={{ isHighContrast, toggleHighContrast }}>
            {children}
        </ThemeContext.Provider>
    );
};


const App: React.FC = () => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [toast, setToast] = useState<ToastMessage | null>(null);
    
    useEffect(() => {
        initMockData();
    }, []);

    const showToast = (message: string, isError: boolean = false) => {
        setToast({ message, isError, id: Date.now() });
    };

    const handleLogin = (user: User) => {
        setCurrentUser(user);
    };

    const handleLogout = () => {
        setCurrentUser(null);
    };

    return (
        <ThemeProvider>
            <div className="flex flex-col min-h-screen bg-gray-100">
                {currentUser ? (
                    <MainApp user={currentUser} onLogout={handleLogout} showToast={showToast} />
                ) : (
                    <Auth onLogin={handleLogin} showToast={showToast} />
                )}
                {toast && <Toast message={toast.message} isError={toast.isError} onDismiss={() => setToast(null)} />}
            </div>
        </ThemeProvider>
    );
};

export default App;