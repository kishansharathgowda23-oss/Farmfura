import React, { useState, useEffect, useContext } from 'react';
import { Order } from '../types';
import { api } from '../services/api';
import { AuthContext, LanguageContext, ToastContext } from '../App';
import Modal from './Modal';

type HomeSubTab = 'available' | 'pickups';

const JobCard: React.FC<{ order: Order; onAccept: (order: Order) => void; isAccepted?: boolean; onDrop: (order: Order) => void; }> = ({ order, onAccept, isAccepted, onDrop }) => {
    const { translate } = useContext(LanguageContext);
    return (
        <div className="bg-white p-4 rounded-lg shadow-sm">
            <div className="flex justify-between items-start">
                <div>
                    <p className="font-bold text-lg">Order #{order.id}</p>
                    <p className="text-sm text-gray-500">{order.items}</p>
                </div>
                <div className="text-right">
                    <p className="font-bold text-xl text-green-600">₹{order.payout}</p>
                    <p className="text-xs text-gray-500">{translate('payout')}</p>
                </div>
            </div>

            <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4 text-sm">
                <div>
                    <p className="font-medium text-gray-500">{translate('pickup_from')}</p>
                    <p className="font-semibold text-gray-800">{order.assignedShopName}</p>
                </div>
                <div>
                    <p className="font-medium text-gray-500">{translate('deliver_to')}</p>
                    <p className="font-semibold text-gray-800">{order.customer.name}</p>
                    <p className="text-gray-600">{order.customer.address}</p>
                </div>
            </div>

            <div className="mt-4 pt-4 border-t">
                {isAccepted ? (
                    <button onClick={() => onDrop(order)} className="w-full bg-red-500 text-white font-bold py-2 rounded-md hover:bg-red-600">{translate('drop_job_btn')}</button>
                ) : (
                    <button onClick={() => onAccept(order)} className="w-full bg-blue-600 text-white font-bold py-2 rounded-md hover:bg-blue-700">{translate('accept_job_btn')}</button>
                )}
            </div>
        </div>
    );
};


const DeliveriesTab: React.FC = () => {
    const { currentUser } = useContext(AuthContext);
    const { translate } = useContext(LanguageContext);
    const showToast = useContext(ToastContext);

    const [subTab, setSubTab] = useState<HomeSubTab>('available');
    const [availableJobs, setAvailableJobs] = useState<Order[]>([]);
    const [myPickups, setMyPickups] = useState<Order[]>([]);
    const [selectedJob, setSelectedJob] = useState<Order | null>(null);
    const [isAcceptModalOpen, setAcceptModalOpen] = useState(false);
    const [isDropModalOpen, setDropModalOpen] = useState(false);

    const fetchData = () => {
        setAvailableJobs(api.getAvailableOrders());
        if (currentUser) {
            setMyPickups(api.getAcceptedOrders(currentUser.id));
        }
    };

    useEffect(() => {
        fetchData();
    }, [currentUser]);

    const handleAcceptClick = (order: Order) => {
        setSelectedJob(order);
        setAcceptModalOpen(true);
    };

    const handleDropClick = (order: Order) => {
        setSelectedJob(order);
        setDropModalOpen(true);
    };

    const confirmAcceptJob = () => {
        if (selectedJob && currentUser) {
            const updatedOrder: Order = { ...selectedJob, status: 'accepted_by_carrier', carrierId: currentUser.id };
            api.updateOrder(updatedOrder);
            showToast(translate('job_accepted_success'));
            fetchData();
        }
        setAcceptModalOpen(false);
        setSelectedJob(null);
    };

    const confirmDropJob = () => {
         if (selectedJob) {
            const updatedOrder: Order = { ...selectedJob, status: 'ready', carrierId: undefined };
            api.updateOrder(updatedOrder);
            showToast(translate('job_dropped_success'));
            fetchData();
        }
        setDropModalOpen(false);
        setSelectedJob(null);
    };


    const TabButton: React.FC<{ tab: HomeSubTab; label: string; }> = ({ tab, label }) => (
        <button
            onClick={() => setSubTab(tab)}
            className={`pb-2 font-semibold border-b-2 ${subTab === tab ? 'text-blue-700 border-blue-700' : 'text-gray-500 border-transparent'}`}
        >
            {label}
        </button>
    );

    return (
        <div>
            <div className="border-b-2 flex space-x-8 mb-4">
                <TabButton tab="available" label={translate('available_jobs')} />
                <TabButton tab="pickups" label={translate('my_pickups')} />
            </div>

            <div className="space-y-4">
                {subTab === 'available' && (
                    availableJobs.length > 0 ? (
                        availableJobs.map(order => <JobCard key={order.id} order={order} onAccept={handleAcceptClick} onDrop={handleDropClick} />)
                    ) : (
                        <p className="text-center text-gray-500 pt-8">{translate('no_available_jobs')}</p>
                    )
                )}

                {subTab === 'pickups' && (
                    myPickups.length > 0 ? (
                        myPickups.map(order => <JobCard key={order.id} order={order} isAccepted onAccept={handleAcceptClick} onDrop={handleDropClick} />)
                    ) : (
                        <p className="text-center text-gray-500 pt-8">{translate('no_active_pickups')}</p>
                    )
                )}
            </div>

            <Modal
                isOpen={isAcceptModalOpen}
                onClose={() => setAcceptModalOpen(false)}
                title={translate('confirm_job_title')}
            >
                <div>
                    <p>{translate('job_summary')}</p>
                    {selectedJob && (
                        <div className="mt-2 p-3 bg-gray-100 rounded-md">
                            <p><span className="font-semibold">Order:</span> #{selectedJob.id}</p>
                            <p><span className="font-semibold">From:</span> {selectedJob.assignedShopName}</p>
                            <p><span className="font-semibold">To:</span> {selectedJob.customer.name}, {selectedJob.customer.address}</p>
                            <p><span className="font-semibold">Payout:</span> ₹{selectedJob.payout}</p>
                        </div>
                    )}
                    <div className="flex justify-end space-x-3 mt-4">
                        <button onClick={() => setAcceptModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300">{translate('cancel')}</button>
                        <button onClick={confirmAcceptJob} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">{translate('confirm')}</button>
                    </div>
                </div>
            </Modal>
            
            <Modal
                isOpen={isDropModalOpen}
                onClose={() => setDropModalOpen(false)}
                title={translate('confirm_drop_title')}
            >
                 <div>
                    <p>{translate('confirm_drop_body')}</p>
                    <div className="flex justify-end space-x-3 mt-4">
                        <button onClick={() => setDropModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300">{translate('no')}</button>
                        <button onClick={confirmDropJob} className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">{translate('yes_drop')}</button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default DeliveriesTab;