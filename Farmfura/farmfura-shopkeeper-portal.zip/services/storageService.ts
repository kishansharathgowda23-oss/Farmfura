import type { User, TimeSlot, Location, Withdrawal } from '../types';

const EMPLOYEES_KEY = 'farmfura_employees';
const SUPPLY_GRIDS_KEY = 'farmfura_supply_grids';
const OUTLETS_KEY = 'farmfura_outlets';
const BOOKED_SLOTS_KEY = 'farmfura_booked_slots';
const WITHDRAWALS_KEY = 'farmfura_withdrawals';

const defaultEmployees: User[] = [
    { id: 'SHP001', name: 'Anand Gupta', role: 'shop_owner', status: 'Active', phone: '9000000001', shopName: 'FreshMart' },
    { 
        id: 'SHK001', 
        name: 'Sunita Devi', 
        role: ['shopkeeper', 'bike_carrier'], // User with multiple roles
        status: 'Active', 
        phone: '9000000002', 
        shopName: 'Farmfura Koramangala', 
        balance: 1250, 
        rewardPoints: 450, // Added reward points
        autoPayoutEnabled: false // Added auto-payout preference
    },
    {
        id: 'SHK_ACCEPTED',
        name: 'Priya Sharma',
        role: 'shopkeeper',
        status: 'Accepted',
        phone: '9000000005',
        shopName: 'Farmfura Jayanagar',
        approvalTimestamp: Date.now() - (47 * 60 * 60 * 1000) // Approved 47 hours ago to test auto-activation
    },
    { id: 'BC001', name: 'Ramesh Kumar', role: 'bike_carrier', status: 'Active', phone: '9000000003' },
    { id: '4x4001', name: 'Vikram Singh', role: '4x4_carrier', status: 'Active', phone: '9000000004' }
] as any[];

const defaultSupplyGrids: Location[] = [
    { name: 'Farmfura Supply Grid - Whitefield', location: 'Whitefield, Bengaluru' },
    { name: 'Farmfura Supply Grid - Electronic City', location: 'Electronic City, Bengaluru' }
];

const defaultOutlets: Location[] = [
    { name: 'Farmfura Koramangala', location: 'Koramangala 5th Block, Bengaluru' },
    { name: 'Farmfura Indiranagar', location: 'Indiranagar 100ft Road, Bengaluru' },
    { name: 'Farmfura Jayanagar', location: 'Jayanagar 4th Block, Bengaluru' }
];

const defaultBookedSlots: TimeSlot[] = [
     { id: 'slot1', date: '2025-10-14', time: '08:00 AM - 11:00 AM', shop: 'Farmfura Koramangala', status: 'Completed', payout: 350, isBonus: true },
     { id: 'slot2', date: '2025-10-18', time: '11:00 AM - 02:00 PM', shop: 'Farmfura Koramangala', status: 'Booked' },
     { id: 'slot3', date: new Date(Date.now() - 86400000).toISOString(), time: '02:00 PM - 05:00 PM', shop: 'Farmfura Koramangala', status: 'Booked' }, // Yesterday's slot for completion simulation
];

const defaultWithdrawals: Withdrawal[] = [
    { id: 'W' + (Date.now() - 86400000 * 5), amount: 500, date: new Date(Date.now() - 86400000 * 5).toISOString(), status: 'Completed' },
    { id: 'W' + (Date.now() - 86400000 * 2), amount: 250, date: new Date(Date.now() - 86400000 * 2).toISOString(), status: 'Pending' },
    { id: 'W' + (Date.now() - 86400000 * 1), amount: 100, date: new Date(Date.now() - 86400000 * 1).toISOString(), status: 'Failed' },
];

export const initMockData = () => {
    if (!localStorage.getItem(EMPLOYEES_KEY)) {
        localStorage.setItem(EMPLOYEES_KEY, JSON.stringify(defaultEmployees));
    }
    if (!localStorage.getItem(SUPPLY_GRIDS_KEY)) {
        localStorage.setItem(SUPPLY_GRIDS_KEY, JSON.stringify(defaultSupplyGrids));
    }
    if (!localStorage.getItem(OUTLETS_KEY)) {
        localStorage.setItem(OUTLETS_KEY, JSON.stringify(defaultOutlets));
    }
    if (!localStorage.getItem(BOOKED_SLOTS_KEY)) {
        localStorage.setItem(BOOKED_SLOTS_KEY, JSON.stringify(defaultBookedSlots));
    }
    if (!localStorage.getItem(WITHDRAWALS_KEY)) {
        localStorage.setItem(WITHDRAWALS_KEY, JSON.stringify(defaultWithdrawals));
    }
};

export const getEmployees = (): User[] => JSON.parse(localStorage.getItem(EMPLOYEES_KEY) || '[]');
export const saveEmployees = (employees: User[]) => localStorage.setItem(EMPLOYEES_KEY, JSON.stringify(employees));

export const getSupplyGrids = (): Location[] => JSON.parse(localStorage.getItem(SUPPLY_GRIDS_KEY) || '[]');
export const getOutlets = (): Location[] => JSON.parse(localStorage.getItem(OUTLETS_KEY) || '[]');

export const getBookedSlots = (): TimeSlot[] => JSON.parse(localStorage.getItem(BOOKED_SLOTS_KEY) || '[]');
export const saveBookedSlots = (slots: TimeSlot[]) => localStorage.setItem(BOOKED_SLOTS_KEY, JSON.stringify(slots));

export const getWithdrawals = (): Withdrawal[] => JSON.parse(localStorage.getItem(WITHDRAWALS_KEY) || '[]');
export const saveWithdrawals = (withdrawals: Withdrawal[]) => localStorage.setItem(WITHDRAWALS_KEY, JSON.stringify(withdrawals));