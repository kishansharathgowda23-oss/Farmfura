import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useToast } from '../../contexts/ToastContext';
import { useLanguage } from '../../contexts/LanguageContext';

interface CameraCaptureProps {
  onCapture: (imageDataUrl: string) => void;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture }) => {
  const [isCapturing, setIsCapturing] = useState(true);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const { showToast } = useToast();
  const { t } = useLanguage();

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  const startCamera = useCallback(async () => {
    stopCamera();
    if (videoRef.current) {
      videoRef.current.style.transform = facingMode === 'user' ? 'scaleX(-1)' : 'scaleX(1)';
    }
    const constraints = { audio: false, video: { facingMode } };
    try {
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      showToast("Could not access camera. Please check permissions.");
    }
  }, [facingMode, stopCamera, showToast]);

  useEffect(() => {
    if (isCapturing) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [isCapturing, startCamera, stopCamera]);

  const handleCapturePhoto = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video && canvas) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        if (facingMode === 'user') {
          context.save();
          context.scale(-1, 1);
          context.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
          context.restore();
        } else {
          context.drawImage(video, 0, 0, canvas.width, canvas.height);
        }
        const dataUrl = canvas.toDataURL('image/jpeg', 0.5);
        setCapturedImage(dataUrl);
        onCapture(dataUrl);
        setIsCapturing(false);
      }
    }
  };

  const handleRecapture = () => {
    setCapturedImage(null);
    onCapture('');
    setIsCapturing(true);
  };

  const handleSwitchCamera = () => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  };

  return (
    <div>
      <div className="relative w-full bg-gray-200 rounded-md overflow-hidden aspect-video">
        <video ref={videoRef} className={`w-full h-full object-cover ${isCapturing ? '' : 'hidden'}`} autoPlay playsInline muted></video>
        <canvas ref={canvasRef} className="hidden"></canvas>
        {capturedImage && <img src={capturedImage} className={`absolute top-0 left-0 w-full h-full object-cover ${!isCapturing ? '' : 'hidden'}`} alt="Captured" />}
      </div>
      {isCapturing ? (
        <div className="flex justify-center space-x-4 mt-2">
          <button type="button" onClick={handleCapturePhoto} className="bg-blue-600 text-white font-bold py-2 px-4 rounded-md text-sm">{t('capture_photo')}</button>
          <button type="button" onClick={handleSwitchCamera} className="bg-gray-500 text-white font-bold py-2 px-4 rounded-md text-sm">{t('switch_camera')}</button>
        </div>
      ) : (
        <div className="flex justify-center space-x-4 mt-2">
          <button type="button" onClick={handleRecapture} className="bg-yellow-500 text-white font-bold py-2 px-4 rounded-md text-sm">{t('retake_photo')}</button>
        </div>
      )}
    </div>
  );
};

export default CameraCapture;