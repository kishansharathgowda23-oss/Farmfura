
import React from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import AuthScreen from './components/auth/AuthScreen';
import DashboardScreen from './components/dashboard/DashboardScreen';
import { ToastProvider } from './contexts/ToastContext';

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <ToastProvider>
        <AuthProvider>
          <Main />
        </AuthProvider>
      </ToastProvider>
    </LanguageProvider>
  );
};

const Main: React.FC = () => {
  const { currentUser } = useAuth();
  return currentUser ? <DashboardScreen /> : <AuthScreen />;
};

export default App;
