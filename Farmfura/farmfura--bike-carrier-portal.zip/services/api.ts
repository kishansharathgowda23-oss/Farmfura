
import { User, Order, Job, RegistrationData } from '../types';
import { REG_PROGRESS_KEY } from '../constants';

const EMPLOYEES_KEY = 'farmfura_employees';
const ORDERS_KEY = 'farmfura_pendingOrders';
const JOBS_KEY = 'farmfura_delivery_jobs';

const defaultEmployees: User[] = [
    { id: 'BC_DEMO_001', name: 'Demo User', role: 'bike_carrier', status: 'Active', phone: '8000000000', vehicleType: 'Demo Bike 125', vehicleNumber: 'TS-09-XY-9999', availableBalance: 1250 },
    { id: 'BC001', name: 'Ramesh Kumar', role: 'bike_carrier', status: 'Active', phone: '9000000003', vehicleType: 'TVS Jupiter', vehicleNumber: 'KA-01-AB-1234', availableBalance: 850 },
    { id: '4x4001', name: 'Vikram Singh', role: '4x4_carrier', status: 'Active', phone: '9000000004', vehicleType: 'Mahindra Bolero', vehicleNumber: 'KA-02-CD-5678', availableBalance: 2100 },
    {
        id: 'BC_ACCEPTED',
        name: 'Raj Verma',
        role: 'bike_carrier',
        status: 'Accepted',
        phone: '9000000005',
        vehicleType: 'Honda Activa',
        vehicleNumber: 'KA-05-EF-5678',
        licenseFileName: 'raj_license.pdf',
        rcFileName: 'raj_rc.pdf',
        livePhoto: 'https://placehold.co/100x100/e2e8f0/e2e8f0?text=RV',
        approvalTimestamp: Date.now(),
        assignedHub: 'Farmfura Hub - Koramangala',
        availableBalance: 0,
    },
];

const defaultOrders: Order[] = [
    { id: 'ORD5432', customer: { name: 'Rina Mehta', address: '123, Rose Villa, Koramangala' }, items: '2kg Tomato, 1kg Potato', assignedShopName: 'FreshMart', payout: 45, status: 'packing' },
    { id: 'ORD5433', customer: { name: 'Arjun Nair', address: 'A-40, Sun City Apts, HSR Layout' }, items: '5kg Onion, 2kg Carrot', assignedShopName: 'Farmfura Koramangala', payout: 55, status: 'accepted_by_carrier', carrierId: 'BC001' },
    { id: 'ORD5434', customer: { name: 'Pooja Desai', address: '789, Green Heights, Indiranagar' }, items: '1kg Ginger, 500g Garlic', assignedShopName: 'Farmfura Koramangala', payout: 40, status: 'ready' },
    { id: 'ORD5435', customer: { name: 'Karan Singh', address: 'Plot 55, BTM 2nd Stage' }, items: '1kg Spinach, 1kg Beans', assignedShopName: 'FreshMart', payout: 35, status: 'ready' }
];

const defaultJobs: Job[] = [
     { id: 'JOB1', date: '2025-10-14', orderId: 'ORD5001', payout: 50, status: 'Completed', carrierId: 'BC001' },
     { id: 'JOB2', date: '2025-10-15', orderId: 'ORD5002', payout: 45, status: 'Completed', carrierId: 'BC001' },
     { id: 'JOB3', date: '2025-10-16', orderId: 'ORD5003', payout: 60, status: 'Completed', carrierId: 'BC_DEMO_001' },
];

const initLocalStorage = <T,>(key: string, defaultData: T) => {
    if (!localStorage.getItem(key)) {
        localStorage.setItem(key, JSON.stringify(defaultData));
    }
};

const getFromStorage = <T,>(key: string): T => {
    return JSON.parse(localStorage.getItem(key) || '[]') as T;
};

const saveToStorage = <T,>(key: string, data: T) => {
    localStorage.setItem(key, JSON.stringify(data));
};


export const api = {
    initializeData: () => {
        initLocalStorage(EMPLOYEES_KEY, defaultEmployees);
        initLocalStorage(ORDERS_KEY, defaultOrders);
        initLocalStorage(JOBS_KEY, defaultJobs);
    },
    
    // User / Employee methods
    getEmployees: (): User[] => getFromStorage<User[]>(EMPLOYEES_KEY),
    getEmployeeByPhone: (phone: string): User | undefined => {
        const users = api.getEmployees();
        return users.find(u => u.phone === phone && (u.role === 'bike_carrier' || u.role === '4x4_carrier'));
    },
    updateEmployee: (updatedUser: User): void => {
        let users = api.getEmployees();
        const index = users.findIndex(u => u.id === updatedUser.id);
        if (index > -1) {
            users[index] = updatedUser;
        } else {
            users.push(updatedUser);
        }
        saveToStorage(EMPLOYEES_KEY, users);
    },
    createEmployee: (data: RegistrationData): User => {
        const newUser: User = {
            id: 'BC' + Date.now(),
            name: data.fullName!,
            phone: data.phone!,
            role: 'bike_carrier',
            status: 'Pending',
            vehicleType: data.vehicleType!,
            vehicleNumber: data.vehicleNumber!,
            licenseFileName: data.licenseFileName,
            rcFileName: data.rcFileName,
            livePhoto: data.livePhoto,
            availableBalance: 0,
        };
        let users = api.getEmployees();
        users = users.filter(emp => !(emp.phone === newUser.phone && (emp.status === 'Rejected' || emp.status === 'Expired')));
        users.push(newUser);
        saveToStorage(EMPLOYEES_KEY, users);
        return newUser;
    },
    withdrawFromWallet: (userId: string): User | null => {
        let users = api.getEmployees();
        const index = users.findIndex(u => u.id === userId);
        if (index > -1 && users[index].availableBalance) {
            users[index].availableBalance = 0;
            saveToStorage(EMPLOYEES_KEY, users);
            return users[index];
        }
        return null;
    },

    // Order methods
    getAvailableOrders: (): Order[] => {
        return getFromStorage<Order[]>(ORDERS_KEY).filter(o => o.status === 'ready');
    },
    getAcceptedOrders: (carrierId: string): Order[] => {
        return getFromStorage<Order[]>(ORDERS_KEY).filter(o => o.status === 'accepted_by_carrier' && o.carrierId === carrierId);
    },
    updateOrder: (updatedOrder: Order): void => {
        const orders = getFromStorage<Order[]>(ORDERS_KEY);
        const index = orders.findIndex(o => o.id === updatedOrder.id);
        if (index > -1) {
            orders[index] = updatedOrder;
            saveToStorage(ORDERS_KEY, orders);
        }
    },
    
    // Job methods
    getCompletedJobs: (carrierId: string): Job[] => {
        return getFromStorage<Job[]>(JOBS_KEY).filter(j => j.carrierId === carrierId && j.status === 'Completed');
    },

    // Registration progress methods
    saveRegProgress: (data: RegistrationData) => saveToStorage(REG_PROGRESS_KEY, data),
    loadRegProgress: (): RegistrationData | null => {
        const data = localStorage.getItem(REG_PROGRESS_KEY);
        return data ? JSON.parse(data) : null;
    },
    clearRegProgress: () => localStorage.removeItem(REG_PROGRESS_KEY),
};