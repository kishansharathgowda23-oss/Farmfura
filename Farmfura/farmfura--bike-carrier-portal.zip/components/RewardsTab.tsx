
import React, { useContext } from 'react';
import { LanguageContext } from '../App';

const RewardsTab: React.FC = () => {
    const { translate } = useContext(LanguageContext);

    return (
        <div>
            <h2 className="text-xl font-bold mb-4">{translate('rewards_title')}</h2>
            <div className="bg-white p-6 rounded-lg shadow-sm text-center mb-6">
                <p className="text-lg text-gray-500">{translate('rewards_points')}</p>
                <p className="text-5xl font-bold text-yellow-500">850</p>
            </div>
            <h3 className="text-lg font-semibold mb-4">{translate('reward_tiers')}</h3>
            <div className="space-y-3">
                <div className="bg-white p-4 rounded-lg shadow-sm border-l-4 border-yellow-800">
                    <p className="font-bold text-yellow-800">{translate('tier_bronze')}</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm opacity-60">
                    <p className="font-bold text-gray-500">{translate('tier_silver')}</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm opacity-60">
                    <p className="font-bold text-gray-500">{translate('tier_gold')}</p>
                </div>
            </div>
        </div>
    );
};

export default RewardsTab;
