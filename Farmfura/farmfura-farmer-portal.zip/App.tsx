import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useAppContext } from './context/AppContext';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import { SubmissionsPage, InventoryPage, ProfilePage } from './pages/SecondaryPages';
import { CartPage, PurchasePage, StatusPage } from './pages/CartAndPurchasePages';
import { Toast, Header, BottomNav } from './components/Common';
import { LocationPermissionModal } from './components/Modals';

const App: React.FC = () => {
  return (
    <AppProvider>
      <Main />
    </AppProvider>
  );
};

const Main: React.FC = () => {
  const { farmerId, toast } = useAppContext();

  return (
    <HashRouter>
      {farmerId ? <AuthenticatedApp /> : <UnauthenticatedApp />}
      {toast && <Toast message={toast.message} />}
    </HashRouter>
  );
};

const UnauthenticatedApp: React.FC = () => {
  return (
    <Routes>
      <Route path="/auth" element={<AuthPage />} />
      <Route path="*" element={<Navigate to="/auth" replace />} />
    </Routes>
  );
};

const AuthenticatedApp: React.FC = () => {
  const { isLocationModalOpen, setIsLocationModalOpen } = useAppContext();
  return (
    <div className="pb-20 md:pt-16">
      <Header />
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/submissions" element={<SubmissionsPage />} />
          <Route path="/inventory" element={<InventoryPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/purchase/:productId" element={<PurchasePage />} />
          <Route path="/status/:submissionId" element={<StatusPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <BottomNav />
      <LocationPermissionModal 
        isOpen={isLocationModalOpen} 
        onClose={() => setIsLocationModalOpen(false)} 
      />
    </div>
  );
};

export default App;