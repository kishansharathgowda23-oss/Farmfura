
import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { useToast } from '../../contexts/ToastContext';
import * as api from '../../services/mockApi';

interface LoginViewProps {
  onGoToRegister: () => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onGoToRegister }) => {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const { login } = useAuth();
  const { t } = useLanguage();
  const { showToast } = useToast();

  const handleContinue = () => {
    if (!/^\d{10}$/.test(phone)) {
      showToast('Invalid phone number.');
      return;
    }
    
    if (otpSent) {
      if (otp === '1234') {
        const user = api.findEmployeeByPhone(phone);
        if (user && user.status === 'Active') {
          login(user);
          showToast('Login successful!');
        } else {
          showToast('Login failed. Account might be inactive or not found.');
        }
      } else {
        showToast('Invalid OTP.');
      }
    } else {
      const user = api.findEmployeeByPhone(phone);
      if (user && user.status === 'Active') {
        setOtpSent(true);
        showToast('OTP Sent! (It\'s 1234)');
      } else if (user && user.status !== 'Active') {
        showToast(`Your application is still ${user.status}. Please wait for approval.`);
      } else {
        showToast('Account not found. Please register.');
      }
    }
  };

  return (
    <div className="bg-white p-8 shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{t('4x4_carrier_login')}</h2>
      <div className="space-y-4">
        <input
          type="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="w-full p-3 border rounded-md"
          placeholder={t('phone_placeholder')}
          required
        />
        {otpSent && (
          <div className="visible">
            <input
              type="text"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="w-full p-3 border rounded-md text-center tracking-widest"
              placeholder={t('otp_placeholder')}
            />
          </div>
        )}
        <button onClick={handleContinue} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700">
          {otpSent ? t('verify_login_btn') : t('send_otp_btn')}
        </button>
      </div>
      <p className="text-center text-sm text-gray-600 mt-6">
        <span>{t('no_account')} </span>
        <button onClick={onGoToRegister} className="text-green-600 font-semibold hover:text-green-700">
          {t('register_here')}
        </button>
      </p>
    </div>
  );
};

export default LoginView;
