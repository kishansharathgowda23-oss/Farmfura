import React, { useState, useCallback } from 'react';
import { Product, CartItem, Order, User, Address, SubscriptionPlan } from './types';
import { ALL_PRODUCTS, CATEGORIES, TRANSLATIONS, SUBSCRIPTION_PLANS } from './constants';
import LoginPage from './components/LoginPage';
import Header from './components/Header';
import ShopPage from './components/ShopPage';
import RewardsPage from './components/RewardsPage';
import PremiumPage from './components/PremiumPage';
import CheckoutPage from './components/CheckoutPage';
import MyOrdersPage from './components/MyOrdersPage';
import MePage from './components/MePage';
import OrderStatusPage from './components/OrderStatusPage';
import BottomNav from './components/BottomNav';
import CartPanel from './components/CartPanel';
import Toast from './components/Toast';
import AddressModal from './components/AddressModal';
import ChatModal from './components/ChatModal';
import SubscriptionSelectionPage from './components/SubscriptionSelectionPage';


type Page = '#login' | '#buyer-page' | '#rewards-page' | '#premium-page' | '#checkout-page' | '#my-orders-page' | '#me-page' | '#order-status-page' | '#subscription-selection';

const App: React.FC = () => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [currentPage, setCurrentPage] = useState<Page>('#login');
    const [language, setLanguage] = useState('en');
    const [cart, setCart] = useState<CartItem[]>([]);
    const [orders, setOrders] = useState<Order[]>([]);
    const [addresses, setAddresses] = useState<Address[]>([]);

    const [isCartOpen, setIsCartOpen] = useState(false);
    const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
    const [isChatModalOpen, setIsChatModalOpen] = useState(false);
    
    const [toast, setToast] = useState<{ message: string; isError: boolean } | null>(null);
    
    const [activeSubscription, setActiveSubscription] = useState<SubscriptionPlan | null>(null);
    const [subscriptionSelection, setSubscriptionSelection] = useState<CartItem[]>([]);


    const translations = {
        ...(TRANSLATIONS[language as keyof typeof TRANSLATIONS] || TRANSLATIONS.en),
        lang_code: language
    };

    const showToast = useCallback((message: string, isError = false) => {
        setToast({ message, isError });
        setTimeout(() => setToast(null), 3000);
    }, []);

    const handleLoginSuccess = (user: User) => {
        setCurrentUser(user);
        setCurrentPage('#buyer-page');
    };

    const handleLogout = () => {
        setCurrentUser(null);
        setCurrentPage('#login');
        setCart([]);
        setOrders([]);
    };

    const handleNavigate = (page: Page) => {
        // Reset subscription flow if navigating away
        if (page !== '#checkout-page' && page !== '#subscription-selection') {
            setActiveSubscription(null);
            setSubscriptionSelection([]);
        }
        setCurrentPage(page);
    };
    
    const addToCart = (productToAdd: Product, quantity: number) => {
        setCart(prevCart => {
            const existingItem = prevCart.find(item => item.id === productToAdd.id);
            if (existingItem) {
                return prevCart.map(item => 
                    item.id === productToAdd.id 
                    ? { ...item, quantity: item.quantity + quantity } 
                    : item
                );
            }
            return [...prevCart, { ...productToAdd, quantity }];
        });
        const productName = productToAdd.names[language as keyof typeof productToAdd.names] || productToAdd.name;
        showToast(translations.added_to_cart_toast.replace('{productName}', productName));
    };

    const updateCartQuantity = (productId: number, amount: number) => {
        setCart(prevCart => {
            const itemToUpdate = prevCart.find(item => item.id === productId);
            if (!itemToUpdate) return prevCart;
            
            const newQuantity = itemToUpdate.quantity + amount;
            if (newQuantity <= 0) {
                return prevCart.filter(item => item.id !== productId);
            }
            return prevCart.map(item => 
                item.id === productId ? { ...item, quantity: newQuantity } : item
            );
        });
    };

    const removeFromCart = (productId: number) => {
        setCart(prevCart => prevCart.filter(item => item.id !== productId));
    };

    const clearCart = () => {
        setCart([]);
    };
    
    const handleSelectPlan = (plan: SubscriptionPlan) => {
        setActiveSubscription(plan);
        handleNavigate('#subscription-selection');
    };
    
    const handleConfirmSubscription = (selectedItems: CartItem[]) => {
        if (!activeSubscription) return;
        
        setSubscriptionSelection(selectedItems);
        
        const subscriptionCartItem: CartItem = {
            id: activeSubscription.name === 'Starter Pack' ? 9001 : 9002,
            name: `${activeSubscription.name}`,
            price: activeSubscription.price,
            quantity: 1,
            isSubscription: true,
            farmerPrice: 0, category: 'vegetables', unit: 'pack', image: '', names: { kn: '', hi: ''}, inStock: true
        };
        setCart([subscriptionCartItem]);
        handleNavigate('#checkout-page');
    };

    const handlePlaceOrder = (order: Omit<Order, 'id' | 'timestamp' | 'status'>) => {
        const newOrder: Order = {
            id: `#FF${Date.now().toString().slice(-4)}`,
            timestamp: Date.now(),
            items: order.items,
            total: order.total,
            status: 'Pending',
            deliveryDay: order.deliveryDay
        };
        setOrders(prev => [newOrder, ...prev]);
        clearCart();
        handleNavigate('#order-status-page');
    };

    const handleAddAddress = (address: Address) => {
        setAddresses(prev => [...prev, address]);
        setIsAddressModalOpen(false);
        showToast(translations.address_saved_toast);
    };

    const renderPage = () => {
        if (!currentUser) {
            return <LoginPage onLoginSuccess={handleLoginSuccess} translations={translations} showToast={showToast} />;
        }
        switch (currentPage) {
            case '#buyer-page':
                return <ShopPage products={ALL_PRODUCTS} categories={CATEGORIES} addToCart={addToCart} translations={translations} showToast={showToast} />;
            case '#rewards-page':
                return <RewardsPage translations={translations} />;
            case '#premium-page':
                return <PremiumPage translations={translations} onSelectPlan={handleSelectPlan} />;
            case '#subscription-selection':
                if (!activeSubscription) {
                    handleNavigate('#premium-page');
                    return null;
                }
                return <SubscriptionSelectionPage plan={activeSubscription} products={ALL_PRODUCTS} onConfirmSelection={handleConfirmSubscription} translations={translations} showToast={showToast} />;
            case '#checkout-page':
                return <CheckoutPage cart={cart} addresses={addresses} onPlaceOrder={handlePlaceOrder} openAddressModal={() => setIsAddressModalOpen(true)} translations={translations} showToast={showToast} isSubscriptionCheckout={!!activeSubscription} subscriptionSelection={subscriptionSelection}/>;
            case '#my-orders-page':
                return <MyOrdersPage orders={orders} translations={translations} onChat={() => setIsChatModalOpen(true)} />;
            case '#me-page':
                return <MePage user={currentUser} addresses={addresses} translations={translations} />;
            case '#order-status-page':
                return <OrderStatusPage onBackToShop={() => handleNavigate('#buyer-page')} onChat={() => setIsChatModalOpen(true)} translations={translations} />;
            default:
                return <ShopPage products={ALL_PRODUCTS} categories={CATEGORIES} addToCart={addToCart} translations={translations} showToast={showToast} />;
        }
    };

    return (
        <>
            <Header
                isLoggedIn={!!currentUser}
                cartItemCount={cart.length}
                onCartClick={() => setIsCartOpen(true)}
                onLogout={handleLogout}
                onLogoClick={() => currentUser && handleNavigate('#buyer-page')}
                showBack={!currentUser && currentPage !== '#login'}
                onBack={() => setCurrentPage('#login')}
                language={language}
                onLanguageChange={setLanguage}
            />
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {renderPage()}
            </main>

            {currentUser && (
                <>
                    <BottomNav currentPage={currentPage} onNavigate={handleNavigate} translations={translations} />
                    <CartPanel
                        isOpen={isCartOpen}
                        onClose={() => setIsCartOpen(false)}
                        cartItems={cart}
                        onUpdateQuantity={updateCartQuantity}
                        onRemoveItem={removeFromCart}
                        onCheckout={() => {
                            setIsCartOpen(false);
                            handleNavigate('#checkout-page');
                        }}
                        translations={translations}
                    />
                    <AddressModal 
                        isOpen={isAddressModalOpen} 
                        onClose={() => setIsAddressModalOpen(false)}
                        onSave={handleAddAddress}
                        translations={translations}
                        showToast={showToast}
                    />
                    <ChatModal
                        isOpen={isChatModalOpen}
                        onClose={() => setIsChatModalOpen(false)}
                        translations={translations}
                    />
                </>
            )}

            {toast && <Toast message={toast.message} isError={toast.isError} />}
        </>
    );
};

export default App;