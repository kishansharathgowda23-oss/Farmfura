import React, { useState } from 'react';
import { SubscriptionPlan, Product, CartItem } from '../types';

interface SubscriptionSelectionPageProps {
    plan: SubscriptionPlan;
    products: Product[];
    onConfirmSelection: (selectedItems: CartItem[]) => void;
    translations: Record<string, string>;
    showToast: (message: string, isError?: boolean) => void;
}

const SubscriptionSelectionPage: React.FC<SubscriptionSelectionPageProps> = ({ plan, products, onConfirmSelection, translations, showToast }) => {
    const [selectedItems, setSelectedItems] = useState<CartItem[]>([]);
    
    const availableProducts = products.filter(p => p.category === 'vegetables' || p.category === 'fruits');

    const getItemWeight = (item: Product, quantity: number): number => {
        switch(item.unit) {
            case 'kg': return quantity;
            case 'bundle': return quantity * 0.25; // Assumption: a bundle is 250g
            case 'piece': return quantity * 0.15; // Assumption: a piece is 150g
            case 'pack': return quantity * 0.2; // Assumption: a pack is 200g
            default: return 0;
        }
    }
    
    const totalWeight = selectedItems.reduce((sum, item) => sum + getItemWeight(item, item.quantity), 0);

    const handleQuantityChange = (product: Product, newQuantity: number) => {
        const currentItem = selectedItems.find(item => item.id === product.id);
        const otherItemsWeight = totalWeight - (currentItem ? getItemWeight(currentItem, currentItem.quantity) : 0);
        const newItemWeight = getItemWeight(product, newQuantity);

        if (otherItemsWeight + newItemWeight > plan.maxWeight) {
            showToast(`Cannot exceed max weight of ${plan.maxWeight}kg`, true);
            return;
        }

        setSelectedItems(prevItems => {
            if (newQuantity <= 0) {
                return prevItems.filter(item => item.id !== product.id);
            }
            const existingItem = prevItems.find(item => item.id === product.id);
            if (existingItem) {
                return prevItems.map(item => item.id === product.id ? { ...item, quantity: newQuantity } : item);
            }
            return [...prevItems, { ...product, quantity: newQuantity }];
        });
    };

    return (
        <div>
            <div className="text-center mb-6">
                <h1 className="text-3xl font-bold text-gray-800 mb-2">{translations.subscription_selection_title}</h1>
                <p className="text-gray-600">{translations.subscription_selection_subtitle.replace('{planName}', plan.name)}</p>
            </div>

            <div className="sticky top-[80px] bg-white/80 backdrop-blur-sm p-4 rounded-lg shadow-md mb-6 z-10 flex justify-between items-center">
                <h2 className="text-lg font-semibold">{plan.name}</h2>
                <div className="text-right">
                    <div className="font-bold text-lg">{translations.current_weight}: <span className={totalWeight > plan.maxWeight ? 'text-red-500' : 'text-green-600'}>{totalWeight.toFixed(2)}kg</span></div>
                    <div className="text-sm text-gray-500">{translations.max_weight}: {plan.maxWeight}kg</div>
                </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {availableProducts.map(product => {
                    const currentItem = selectedItems.find(item => item.id === product.id);
                    const quantity = currentItem ? currentItem.quantity : 0;
                    const isKg = product.unit === 'kg';
                    const step = isKg ? 0.25 : 1;

                    return (
                        <div key={product.id} className="bg-white p-4 rounded-lg shadow-sm text-center">
                            <img src={product.image} alt={product.name} className="w-full h-24 object-cover rounded-md mb-2" />
                            <h3 className="text-sm font-semibold h-10">{product.names[translations.lang_code as keyof typeof product.names] || product.name}</h3>
                            <div className="flex items-center justify-center space-x-2 mt-2">
                                <button onClick={() => handleQuantityChange(product, quantity - step)} className="h-8 w-8 rounded-full bg-gray-200 font-bold">-</button>
                                <span className="w-12 text-center font-semibold">{quantity}{isKg && 'kg'}</span>
                                <button onClick={() => handleQuantityChange(product, quantity + step)} className="h-8 w-8 rounded-full bg-gray-200 font-bold">+</button>
                            </div>
                        </div>
                    )
                })}
            </div>

            <div className="mt-8 text-center">
                <button 
                    onClick={() => onConfirmSelection(selectedItems)}
                    disabled={selectedItems.length === 0}
                    className="bg-green-600 text-white font-bold py-3 px-8 rounded-md hover:bg-green-700 transition disabled:bg-gray-400"
                >
                    {translations.confirm_and_checkout}
                </button>
            </div>
        </div>
    );
};

export default SubscriptionSelectionPage;
