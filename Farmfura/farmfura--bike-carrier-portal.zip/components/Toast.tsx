
import React, { useEffect, useState } from 'react';

interface ToastProps {
  message: string;
  isError?: boolean;
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, isError = false, onClose }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
    const timer = setTimeout(() => {
      setVisible(false);
      // Allow time for fade-out animation before calling onClose
      setTimeout(onClose, 300);
    }, 2700);
    
    return () => clearTimeout(timer);
  }, [message, onClose]);

  const bgColor = isError ? 'bg-red-600' : 'bg-green-600';

  return (
    <div
      className={`fixed bottom-20 left-1/2 -translate-x-1/2 p-4 rounded-lg shadow-xl text-white transition-opacity duration-300 z-[150] ${bgColor} ${visible ? 'opacity-100' : 'opacity-0'}`}
    >
      {message}
    </div>
  );
};

export default Toast;
