
import React from 'react';
import { CartItem } from '../types';

interface CartPanelProps {
    isOpen: boolean;
    onClose: () => void;
    cartItems: CartItem[];
    onUpdateQuantity: (productId: number, amount: number) => void;
    onRemoveItem: (productId: number) => void;
    onCheckout: () => void;
    translations: Record<string, string>;
}

const CartPanel: React.FC<CartPanelProps> = ({ isOpen, onClose, cartItems, onUpdateQuantity, onRemoveItem, onCheckout, translations }) => {
    const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

    const getQuantityDisplay = (item: CartItem) => {
        const unitText = translations[`unit_${item.unit}`] || item.unit;
        if (item.unit === 'kg' && item.quantity < 1) {
            return `${Math.round(item.quantity * 1000)}g`;
        } else if (item.unit === 'kg') {
            return `${item.quantity.toFixed(2)}${unitText}`;
        }
        return `${item.quantity} ${unitText}`;
    };

    return (
        <div className={`fixed top-0 right-0 h-full w-full max-w-sm bg-white shadow-2xl transform transition-transform duration-300 ease-in-out z-[100] ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
            <div className="flex flex-col h-full">
                <div className="flex justify-between items-center p-4 border-b">
                    <h2 className="text-xl font-bold text-gray-800">{translations.cart_title}</h2>
                    <button onClick={onClose} className="text-gray-600 hover:text-gray-900 text-2xl font-bold">&times;</button>
                </div>

                <div className="flex-grow p-4 overflow-y-auto">
                    {cartItems.length === 0 ? (
                        <p className="text-center text-gray-500">{translations.cart_empty}</p>
                    ) : (
                        cartItems.map(item => {
                            const quantityStep = ['bundle', 'piece', 'pack'].includes(item.unit) ? 1 : 0.25;
                            return (
                                <div key={item.id} className="flex justify-between items-center mb-4">
                                    <div className="w-1/2">
                                        <h4 className="font-semibold text-sm">{item.names[translations.lang_code as keyof typeof item.names] || item.name}</h4>
                                        <p className="text-xs text-gray-600">₹{item.price.toFixed(2)} / {translations[`unit_${item.unit}`] || item.unit}</p>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <button onClick={() => onUpdateQuantity(item.id, -quantityStep)} className="h-6 w-6 rounded-full bg-gray-200 font-bold">-</button>
                                        <span className="w-20 text-center text-sm">{getQuantityDisplay(item)}</span>
                                        <button onClick={() => onUpdateQuantity(item.id, quantityStep)} className="h-6 w-6 rounded-full bg-gray-200 font-bold">+</button>
                                    </div>
                                    <button onClick={() => onRemoveItem(item.id)} className="text-red-500 hover:text-red-700 font-bold text-2xl">&times;</button>
                                </div>
                            );
                        })
                    )}
                </div>
                
                {cartItems.length > 0 && (
                    <div className="p-4 border-t">
                        <div className="flex justify-between items-center mb-4">
                            <span className="text-lg font-semibold text-gray-700">{translations.cart_subtotal}</span>
                            <span className="text-xl font-bold text-gray-900">₹{subtotal.toFixed(2)}</span>
                        </div>
                        <button onClick={onCheckout} className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition disabled:bg-gray-400">
                            {translations.checkout_btn}
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CartPanel;
